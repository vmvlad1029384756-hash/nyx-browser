# NYX Browser 1.0.0-dev.3.2

Active development build for the NYX Browser 1.0 line, based on the existing 0.3.0 Full project. This archive is a source/development package, **not a final release or signed installer**.

## Target platform
- Windows 10/11 x64
- Python 3.13 x64 for source runs and Windows packaging
- PySide6 + Qt WebEngine 6.10 or newer (required for native Manifest V3 extensions)

## Stage 2 — visual and extension overhaul
- Custom NYX application icon.
- Premium NYX Violet visual baseline with Emerald, Crimson, Azure, AMOLED Black and Midnight palettes.
- The desktop chrome now follows the published NYX site tokens: near-black `#090811`, layered `#141222` / `#1a172b` surfaces, Inter typography and violet `#a98bff` → `#7654df` accents.
- Redesigned browser chrome: compact address bar with only Downloads and Extensions on its right side.
- Sidebar is now an overlay drawer: expanding it does not resize or shift the page. Left/right placement, pinning, hover behavior and motion can be configured.
- Unified theme tokens across native controls, dialogs, the new-tab dashboard and NYX Arcade; the selected accent drives the clock glow, search focus, action dock, widgets, game HUD and hover states. Old saved custom colors no longer override a selected preset; custom themes have their own explicit selector.
- New scrollable settings pages and controls for interface animations, hover drawer, online search suggestions, status bar visibility and a fully editable custom theme.
- Added Qt WebEngine Manifest V3 extension manager and an official YouBusta / ЮБуст installer that fetches the package from the Chrome Web Store update service after the user requests installation.
- Added a separate HTTP/SOCKS5 Proxy Switcher with import, export, remove and saved profiles; supports `host:port`, `host:port:login:password` and URL formats.
- SQLite WAL/busy-timeout configuration and atomic settings writes.
- One-time pre-1.0 snapshot of `settings.json` and `nyx.db` before database initialization.
- Existing Chromium profile, cookies, cache and OS credential-vault passwords remain in their current locations.
- Fixed the duplicate-tab action in Google AI Mode.
- Sanitized generated download names against path traversal and Windows-invalid file names.
- Added a Windows x64 PyInstaller recipe and a per-user Inno Setup installer template.
- Added regression tests and a manual Windows QA checklist.

## Run from source on Windows
```powershell
py install 3.13
py -3.13 -m venv .venv
.venv\Scripts\python.exe -m pip install -r requirements.txt
.venv\Scripts\python.exe -m nyx
```

Or run `run.bat`; it installs Python 3.13 x64 if needed, creates an isolated `.venv`, and installs dependencies directly into that environment. Your other Python versions are left untouched.

## Build a Windows x64 package
1. Install Inno Setup 6.
2. Run `build_windows.bat`; it installs Python 3.13 x64 through the Python Install Manager if needed.
3. When PyInstaller finishes, compile `setup/NYX_Browser.iss` in Inno Setup Compiler.
4. Test the unpacked build and installer against `WINDOWS_QA_CHECKLIST.md` before distributing.

The installer template installs per-user under `%LOCALAPPDATA%\Programs\NYX Browser`. It does not remove `%LOCALAPPDATA%\NYX Browser` on uninstall.

## User data and upgrade safety
NYX keeps using `%LOCALAPPDATA%\NYX Browser` for settings, SQLite data and the Chromium profile. On the first 1.0 startup, the app creates a one-time snapshot of existing `settings.json` and `nyx.db` under `%LOCALAPPDATA%\NYX Browser\backups` before database initialization. SQLite's backup API is used for a consistent database snapshot. The Chromium profile/cache and Windows Credential Manager secrets are not copied, moved or deleted.

## Verification status
18 automated regression tests cover Python source parsing, the PWA manifest, profile preservation, theme isolation, CRX2/CRX3 package validation, proxy import formats, the toolbar and extension integration. Inline JavaScript in the desktop start page, games page and PWA pages passes Node syntax checks.

This environment does not have PySide6/Qt WebEngine installed, so GUI launch, native extension installation, Windows Credential Manager, WebEngine permissions, PyInstaller output, installer execution, codecs, Google sign-in and real website/video compatibility have **not** been certified here. See `WINDOWS_QA_CHECKLIST.md`.

## Compatibility commitments
YouBusta / ЮБуст can now be installed from the official Chrome Web Store update endpoint using Qt WebEngine 6.10+ Manifest V3 support; the package ID is checked before the extension is enabled. Its full runtime compatibility with NYX still requires real Windows testing; Qt WebEngine does not implement every Chrome extension API. If the extension installs but does not function correctly, keep it disabled and report the exact error. VK Video, YouTube, Google sign-in and third-party video sites must be tested on target Windows hardware. NYX does not claim to bypass network, regional, DNS, TLS or site-side restrictions.


### Windows: Python runtime / `.venv` creation

The launcher resolves the installed Python 3.13 x64 executable and invokes that exact `python.exe` to create `.venv`. If creation still fails, `run.bat` prints the executable path and a manual diagnostic command. Python 3.15 may remain installed alongside Python 3.13.


### dev.3 notes
The sidebar is now a slim edge drawer, Incognito has a visible toolbar action, YouBusta installation passes an unpacked directory to Qt WebEngine, and start-page shortcuts are semantic links. Mobile PWA layout is responsive; the desktop Qt WebEngine app itself is not a native phone browser. See CHANGELOG.md for limitations.


### dev.3.1 requirements hotfix
`run.bat` now resolves `requirements.txt` relative to its own location, prints the exact dependency-file path, and recreates the standard dependency list if the text file was omitted during extraction.


### dev.3.2 theme and widgets
The browser theme accent is injected into page selection/link styling and the existing dashboard/Arcade CSS. This is a best-effort page styling layer: sites using isolated shadow roots, canvas-rendered text, or their own high-priority styling may not be fully recolored. Added Pomodoro, budget tracker, and percentage calculator widgets. Windows GUI/WebEngine behavior still requires local Windows QA.
