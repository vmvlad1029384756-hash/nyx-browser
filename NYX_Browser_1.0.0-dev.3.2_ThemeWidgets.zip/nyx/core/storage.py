from __future__ import annotations
import json
import os
import sqlite3
from pathlib import Path
from datetime import datetime, timezone, timedelta
from typing import Any

APP_DIR = Path(os.environ.get('LOCALAPPDATA', str(Path.home()))) / 'NYX Browser'
APP_DIR.mkdir(parents=True, exist_ok=True)
CONFIG_FILE = APP_DIR / 'settings.json'
DB_FILE = APP_DIR / 'nyx.db'
DOWNLOADS_DIR = Path.home() / 'Downloads' / 'NYX Browser'
DOWNLOADS_DIR.mkdir(parents=True, exist_ok=True)
ADDONS_DIR = Path(__file__).resolve().parents[1] / 'addons'
ADDONS_DIR.mkdir(parents=True, exist_ok=True)

DEFAULT_SETTINGS: dict[str, Any] = {
    'search_engine': 'Google', 'theme': 'NYX Violet', 'sidebar_side': 'left', 'sidebar_pinned': False, 'dark_engine': True,
    'startup_home': True, 'enabled_addons': [], 'adblock': True,
    'proxy_enabled': False, 'proxy_type': 'HTTP', 'proxy_host': '', 'proxy_port': 8080,
    'proxy_username': '', 'proxy_profiles': [], 'proxy_password': '',
    'dark_lab': {}, 'focus_hide_status': True, 'chat_server': '', 'chat_nickname': '',
    'restore_session_on_startup': False, 'last_session_urls': [],
    'ask_download_location': True, 'download_dir': str(DOWNLOADS_DIR),
    'memory_saver_enabled': False, 'memory_saver_delay_minutes': 10,
    'custom_theme': {}, 'theme_name': 'NYX Original', 'native_extensions_enabled': [],
    'ui_animations': True, 'sidebar_hover_expand': True, 'online_suggestions': True, 'show_status_bar': True,
}


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec='seconds')


def load_settings() -> dict[str, Any]:
    data = dict(DEFAULT_SETTINGS)
    try:
        if CONFIG_FILE.exists():
            loaded = json.loads(CONFIG_FILE.read_text(encoding='utf-8'))
            if isinstance(loaded, dict): data.update(loaded)
        if data.get('theme') == 'Premium Green':
            data['theme'] = 'NYX Violet'
    except (OSError, json.JSONDecodeError):
        pass
    return data


def save_settings(settings: dict[str, Any]) -> None:
    APP_DIR.mkdir(parents=True, exist_ok=True)
    temp = CONFIG_FILE.with_suffix('.json.tmp')
    payload = json.dumps(settings, ensure_ascii=False, indent=2)
    with temp.open('w', encoding='utf-8', newline='\n') as stream:
        stream.write(payload)
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temp, CONFIG_FILE)


def connect_db() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_FILE, timeout=15)
    conn.row_factory = sqlite3.Row
    conn.execute('PRAGMA foreign_keys=ON')
    conn.execute('PRAGMA busy_timeout=15000')
    conn.execute('PRAGMA journal_mode=WAL')
    conn.execute('PRAGMA synchronous=NORMAL')
    return conn


def init_db() -> None:
    with connect_db() as db:
        db.executescript('''
        CREATE TABLE IF NOT EXISTS notes (domain TEXT PRIMARY KEY, note TEXT NOT NULL, updated_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS spaces (name TEXT PRIMARY KEY, urls TEXT NOT NULL, updated_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS sessions (id INTEGER PRIMARY KEY AUTOINCREMENT, label TEXT NOT NULL, urls TEXT NOT NULL, created_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS history (
            id INTEGER PRIMARY KEY AUTOINCREMENT, url TEXT NOT NULL, title TEXT NOT NULL DEFAULT '',
            visited_at TEXT NOT NULL, visit_type TEXT NOT NULL DEFAULT 'page'
        );
        CREATE INDEX IF NOT EXISTS idx_history_visited_at ON history(visited_at DESC);
        CREATE INDEX IF NOT EXISTS idx_history_url ON history(url);
        CREATE TABLE IF NOT EXISTS searches (
            id INTEGER PRIMARY KEY AUTOINCREMENT, query TEXT NOT NULL, engine TEXT NOT NULL DEFAULT '', searched_at TEXT NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_searches_time ON searches(searched_at DESC);
        CREATE TABLE IF NOT EXISTS bookmarks (
            id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, url TEXT NOT NULL,
            folder TEXT NOT NULL DEFAULT 'Без папки', created_at TEXT NOT NULL,
            UNIQUE(url, folder)
        );
        CREATE INDEX IF NOT EXISTS idx_bookmarks_folder ON bookmarks(folder COLLATE NOCASE);
        CREATE TABLE IF NOT EXISTS downloads (
            id INTEGER PRIMARY KEY AUTOINCREMENT, url TEXT NOT NULL, filename TEXT NOT NULL,
            path TEXT NOT NULL DEFAULT '', status TEXT NOT NULL DEFAULT 'Ожидание',
            received INTEGER NOT NULL DEFAULT 0, total INTEGER NOT NULL DEFAULT 0,
            created_at TEXT NOT NULL, finished_at TEXT NOT NULL DEFAULT ''
        );
        CREATE TABLE IF NOT EXISTS site_permissions (
            id INTEGER PRIMARY KEY AUTOINCREMENT, origin TEXT NOT NULL, feature TEXT NOT NULL,
            decision TEXT NOT NULL, updated_at TEXT NOT NULL, UNIQUE(origin, feature)
        );
        CREATE TABLE IF NOT EXISTS credentials (
            origin TEXT NOT NULL, username TEXT NOT NULL, title TEXT NOT NULL DEFAULT '',
            updated_at TEXT NOT NULL, PRIMARY KEY(origin, username)
        );
        ''')


def record_visit(url: str, title: str = '', private: bool = False) -> None:
    if private or not url.startswith(('http://', 'https://')): return
    with connect_db() as db:
        db.execute('INSERT INTO history(url,title,visited_at,visit_type) VALUES(?,?,?,?)',
                   (url, title or url, now_iso(), 'page'))


def record_search(query: str, engine: str = '', private: bool = False) -> None:
    query = (query or '').strip()
    if private or not query: return
    with connect_db() as db:
        db.execute('INSERT INTO searches(query,engine,searched_at) VALUES(?,?,?)', (query[:1000], engine, now_iso()))


def list_history(search: str = '', limit: int = 2000) -> list[dict[str, Any]]:
    term = f'%{search.strip()}%'
    with connect_db() as db:
        if search.strip():
            rows = db.execute('''SELECT id,url,title,visited_at,visit_type FROM history
                WHERE url LIKE ? OR title LIKE ? ORDER BY visited_at DESC LIMIT ?''', (term, term, limit)).fetchall()
            searches = db.execute('''SELECT id,query AS title,query AS url,searched_at AS visited_at,'search' AS visit_type
                FROM searches WHERE query LIKE ? ORDER BY searched_at DESC LIMIT ?''', (term, limit)).fetchall()
        else:
            rows = db.execute('SELECT id,url,title,visited_at,visit_type FROM history ORDER BY visited_at DESC LIMIT ?', (limit,)).fetchall()
            searches = db.execute("SELECT id,query AS title,query AS url,searched_at AS visited_at,'search' AS visit_type FROM searches ORDER BY searched_at DESC LIMIT ?", (limit,)).fetchall()
    merged = [dict(r) for r in rows] + [dict(r) for r in searches]
    merged.sort(key=lambda x: x.get('visited_at', ''), reverse=True)
    return merged[:limit]


def delete_history_entry(kind: str, entry_id: int) -> None:
    table = 'searches' if kind == 'search' else 'history'
    with connect_db() as db: db.execute(f'DELETE FROM {table} WHERE id=?', (int(entry_id),))


def clear_history(period: str = 'all') -> None:
    durations = {'hour': timedelta(hours=1), 'day': timedelta(days=1), 'week': timedelta(days=7), 'month': timedelta(days=30)}
    if period == 'all':
        with connect_db() as db:
            db.execute('DELETE FROM history')
            db.execute('DELETE FROM searches')
        return
    duration = durations.get(period)
    if not duration: return
    cutoff = (datetime.now(timezone.utc) - duration).isoformat(timespec='seconds')
    with connect_db() as db:
        db.execute('DELETE FROM history WHERE visited_at < ?', (cutoff,))
        db.execute('DELETE FROM searches WHERE searched_at < ?', (cutoff,))


def get_suggestions(prefix: str = '', limit: int = 16) -> list[str]:
    prefix = (prefix or '').strip()
    if not prefix: return []
    like = f'%{prefix}%'
    out: list[str] = []
    with connect_db() as db:
        for row in db.execute('SELECT query FROM searches WHERE query LIKE ? ORDER BY searched_at DESC LIMIT ?', (like, limit)):
            if row['query'] not in out: out.append(row['query'])
        for row in db.execute('SELECT url FROM history WHERE url LIKE ? OR title LIKE ? ORDER BY visited_at DESC LIMIT ?', (like, like, limit)):
            if row['url'] not in out: out.append(row['url'])
        for row in db.execute('SELECT url FROM bookmarks WHERE url LIKE ? OR title LIKE ? ORDER BY created_at DESC LIMIT ?', (like, like, limit)):
            if row['url'] not in out: out.append(row['url'])
    return out[:limit]


def add_bookmark(title: str, url: str, folder: str = 'Без папки') -> None:
    with connect_db() as db:
        db.execute('''INSERT INTO bookmarks(title,url,folder,created_at) VALUES(?,?,?,?)
            ON CONFLICT(url,folder) DO UPDATE SET title=excluded.title''',
            (title or url, url, folder or 'Без папки', now_iso()))


def list_bookmarks(search: str = '') -> list[dict[str, Any]]:
    with connect_db() as db:
        if search.strip():
            term = f'%{search.strip()}%'
            rows = db.execute('SELECT id,title,url,folder,created_at FROM bookmarks WHERE title LIKE ? OR url LIKE ? OR folder LIKE ? ORDER BY folder COLLATE NOCASE,title COLLATE NOCASE', (term, term, term)).fetchall()
        else:
            rows = db.execute('SELECT id,title,url,folder,created_at FROM bookmarks ORDER BY folder COLLATE NOCASE,title COLLATE NOCASE').fetchall()
        return [dict(r) for r in rows]


def delete_bookmark(bookmark_id: int) -> None:
    with connect_db() as db: db.execute('DELETE FROM bookmarks WHERE id=?', (int(bookmark_id),))


def update_bookmark(bookmark_id: int, title: str, folder: str = 'Без папки') -> None:
    with connect_db() as db:
        db.execute('UPDATE bookmarks SET title=?, folder=? WHERE id=?',
                   (title.strip() or 'Без названия', folder.strip() or 'Без папки', int(bookmark_id)))


def save_download(url: str, filename: str, path: str = '', status: str = 'Ожидание', received: int = 0, total: int = 0, download_id: int | None = None) -> int:
    with connect_db() as db:
        if download_id is not None:
            db.execute('UPDATE downloads SET path=?,status=?,received=?,total=?,finished_at=? WHERE id=?',
                       (path, status, int(received), int(total), now_iso() if status in ('Завершено','Ошибка','Отменено') else '', int(download_id)))
            return int(download_id)
        cur = db.execute('INSERT INTO downloads(url,filename,path,status,received,total,created_at) VALUES(?,?,?,?,?,?,?)',
                         (url, filename, path, status, int(received), int(total), now_iso()))
        return int(cur.lastrowid)


def list_downloads(limit: int = 500) -> list[dict[str, Any]]:
    with connect_db() as db:
        return [dict(r) for r in db.execute('SELECT * FROM downloads ORDER BY id DESC LIMIT ?', (limit,)).fetchall()]


def delete_download(download_id: int) -> None:
    with connect_db() as db: db.execute('DELETE FROM downloads WHERE id=?', (int(download_id),))


def save_site_permission(origin: str, feature: str, decision: str) -> None:
    with connect_db() as db:
        db.execute('''INSERT INTO site_permissions(origin,feature,decision,updated_at) VALUES(?,?,?,?)
            ON CONFLICT(origin,feature) DO UPDATE SET decision=excluded.decision,updated_at=excluded.updated_at''',
            (origin, feature, decision, now_iso()))


def get_site_permission(origin: str, feature: str) -> str | None:
    with connect_db() as db:
        row = db.execute('SELECT decision FROM site_permissions WHERE origin=? AND feature=?', (origin, feature)).fetchone()
        return str(row['decision']) if row else None


def list_site_permissions() -> list[dict[str, Any]]:
    with connect_db() as db:
        return [dict(r) for r in db.execute('SELECT * FROM site_permissions ORDER BY origin COLLATE NOCASE,feature').fetchall()]


def delete_site_permission(permission_id: int) -> None:
    with connect_db() as db: db.execute('DELETE FROM site_permissions WHERE id=?', (int(permission_id),))


def save_note(domain: str, note: str) -> None:
    with connect_db() as db:
        db.execute('''INSERT INTO notes(domain,note,updated_at) VALUES(?,?,?)
            ON CONFLICT(domain) DO UPDATE SET note=excluded.note, updated_at=excluded.updated_at''',
            (domain or 'new tab', note, now_iso()))


def get_note(domain: str) -> str:
    with connect_db() as db:
        row = db.execute('SELECT note FROM notes WHERE domain=?', (domain or 'new tab',)).fetchone()
        return str(row['note']) if row else ''


def list_notes() -> list[dict[str, str]]:
    with connect_db() as db:
        rows = db.execute('SELECT domain,note,updated_at FROM notes ORDER BY updated_at DESC').fetchall()
        return [dict(r) for r in rows]


def save_space(name: str, urls: list[str]) -> None:
    with connect_db() as db:
        db.execute('''INSERT INTO spaces(name,urls,updated_at) VALUES(?,?,?)
            ON CONFLICT(name) DO UPDATE SET urls=excluded.urls, updated_at=excluded.updated_at''',
            (name, json.dumps(urls, ensure_ascii=False), now_iso()))


def list_spaces() -> list[dict[str, Any]]:
    with connect_db() as db:
        rows = db.execute('SELECT name,urls,updated_at FROM spaces ORDER BY name COLLATE NOCASE').fetchall()
        return [{'name': r['name'], 'urls': json.loads(r['urls']), 'updated_at': r['updated_at']} for r in rows]


def delete_space(name: str) -> None:
    with connect_db() as db: db.execute('DELETE FROM spaces WHERE name=?', (name,))


def save_session(label: str, urls: list[str]) -> None:
    with connect_db() as db:
        db.execute('INSERT INTO sessions(label,urls,created_at) VALUES(?,?,?)',
                   (label, json.dumps(urls, ensure_ascii=False), now_iso()))


def list_sessions(limit: int = 50) -> list[dict[str, Any]]:
    with connect_db() as db:
        rows = db.execute('SELECT id,label,urls,created_at FROM sessions ORDER BY id DESC LIMIT ?', (limit,)).fetchall()
        return [{'id': r['id'], 'label': r['label'], 'urls': json.loads(r['urls']), 'created_at': r['created_at']} for r in rows]


def delete_session(session_id: int) -> None:
    with connect_db() as db: db.execute('DELETE FROM sessions WHERE id=?', (session_id,))
