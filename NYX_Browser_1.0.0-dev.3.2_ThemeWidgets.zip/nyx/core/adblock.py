from PySide6.QtWebEngineCore import QWebEngineUrlRequestInterceptor

BLOCKED_HOST_PARTS = (
    'doubleclick.net', 'googlesyndication.com', 'adservice.google.',
    'adnxs.com', 'taboola.com', 'outbrain.com', 'scorecardresearch.com',
    'quantserve.com', 'adform.net', 'criteo.com'
)

class NYXRequestInterceptor(QWebEngineUrlRequestInterceptor):
    def __init__(self, settings_provider, parent=None):
        super().__init__(parent)
        self.settings_provider = settings_provider

    def interceptRequest(self, info):
        settings = self.settings_provider()
        if not settings.get('adblock', True):
            return
        host = info.requestUrl().host().lower()
        if any(part in host for part in BLOCKED_HOST_PARTS):
            info.block(True)
