"""Small, strict CRX-to-ZIP reader used for official extension packages."""
from __future__ import annotations

from io import BytesIO
import zipfile


def extract_crx_zip(data: bytes) -> bytes:
    """Return the ZIP payload from a CRX2/CRX3 package after validating it."""
    if not isinstance(data, (bytes, bytearray)) or len(data) < 12 or data[:4] != b"Cr24":
        raise ValueError("Ответ не является корректным CRX-пакетом.")
    version = int.from_bytes(data[4:8], "little")
    if version == 3:
        header_size = int.from_bytes(data[8:12], "little")
        offset = 12 + header_size
        if offset > len(data):
            raise ValueError("Заголовок CRX3 повреждён.")
    elif version == 2:
        if len(data) < 16:
            raise ValueError("Заголовок CRX2 повреждён.")
        public_key_size = int.from_bytes(data[8:12], "little")
        signature_size = int.from_bytes(data[12:16], "little")
        offset = 16 + public_key_size + signature_size
        if offset > len(data):
            raise ValueError("Заголовок CRX2 повреждён.")
    else:
        raise ValueError(f"Неподдерживаемый формат CRX{version}.")

    payload = bytes(data[offset:])
    try:
        with zipfile.ZipFile(BytesIO(payload)) as archive:
            if "manifest.json" not in archive.namelist():
                raise ValueError("В пакете отсутствует manifest.json в корне архива.")
            bad_member = archive.testzip()
            if bad_member:
                raise ValueError(f"Повреждён файл расширения: {bad_member}")
    except zipfile.BadZipFile as exc:
        raise ValueError("ZIP-данные внутри CRX повреждены.") from exc
    return payload
