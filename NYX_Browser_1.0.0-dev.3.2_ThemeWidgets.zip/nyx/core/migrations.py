"""Safe, one-time data snapshot for the NYX 1.0 upgrade."""
from __future__ import annotations

import json
import sqlite3
import shutil
from datetime import datetime
from pathlib import Path

from nyx.core.storage import APP_DIR, CONFIG_FILE, DB_FILE

MARKER = APP_DIR / "v1_upgrade_snapshot.json"

def create_pre_v1_snapshot() -> Path | None:
    """Copy settings and SQLite DB once before the first 1.0 startup.

    Chromium profile/cache are deliberately not copied while Chromium may be
    running. They remain in-place and are never deleted or migrated here.
    Password secrets remain in the OS credential vault (keyring).
    """
    if MARKER.exists():
        return None
    existing = [p for p in (CONFIG_FILE, DB_FILE) if p.exists()]
    if not existing:
        MARKER.write_text(json.dumps({"created": datetime.now().isoformat(), "files": []}, indent=2), encoding="utf-8")
        return None
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    backup_dir = APP_DIR / "backups" / f"pre-v1.0-{stamp}"
    backup_dir.mkdir(parents=True, exist_ok=False)
    copied = []
    for source in existing:
        target = backup_dir / source.name
        if source == DB_FILE:
            with sqlite3.connect(source) as source_db, sqlite3.connect(target) as target_db:
                source_db.backup(target_db)
            shutil.copystat(source, target)
        else:
            shutil.copy2(source, target)
        copied.append({"name": source.name, "size": target.stat().st_size})
    MARKER.write_text(json.dumps({"created": datetime.now().isoformat(), "backup": str(backup_dir), "files": copied}, indent=2), encoding="utf-8")
    return backup_dir
