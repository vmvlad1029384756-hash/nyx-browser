from __future__ import annotations
import json
import re
from PySide6.QtWebEngineCore import QWebEngineScript
from nyx.core.storage import ADDONS_DIR


def _metadata_patterns(source: str, tag: str) -> list[str]:
    return re.findall(r"^\s*//\s*" + re.escape(tag) + r"\s+(.+?)\s*$", source, flags=re.MULTILINE)


def _wrap_with_match_rules(source: str) -> str:
    includes = _metadata_patterns(source, "@match")
    excludes = _metadata_patterns(source, "@exclude")
    if not includes and not excludes:
        return source
    rules = json.dumps({"include": includes, "exclude": excludes}, ensure_ascii=False)
    wrapper = r"""
(() => {
  const rules = __NYX_RULES__;
  const matches = (pattern, url) => {
    const escaped = pattern.split("*").map(part =>
      part.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
    ).join(".*");
    try { return new RegExp("^" + escaped + "$").test(url); } catch (_) { return false; }
  };
  const url = location.href;
  if (rules.include.length && !rules.include.some(p => matches(p, url))) return;
  if (rules.exclude.some(p => matches(p, url))) return;
  try {
    (() => {
__NYX_SOURCE__
    })();
  } catch (error) { console.error("NYX Add-on error:", error); }
})();
"""
    return wrapper.replace("__NYX_RULES__", rules).replace("__NYX_SOURCE__", source)


def install_user_scripts(profile, enabled_names: list[str] | None = None) -> list[str]:
    """Load trusted local JS add-ons with optional basic @match/@exclude globs."""
    enabled = set(enabled_names or [])
    loaded: list[str] = []
    collection = profile.scripts()
    for path in sorted(ADDONS_DIR.glob("*.js")):
        if enabled_names is not None and path.name not in enabled:
            continue
        try:
            source = path.read_text(encoding="utf-8")
            script = QWebEngineScript()
            script.setName("NYX Add-on: " + path.stem)
            script.setInjectionPoint(QWebEngineScript.InjectionPoint.DocumentReady)
            script.setWorldId(QWebEngineScript.ScriptWorldId.ApplicationWorld)
            script.setRunsOnSubFrames(False)
            script.setSourceCode(_wrap_with_match_rules(source))
            collection.insert(script)
            loaded.append(path.name)
        except (OSError, UnicodeError):
            continue
    return loaded


def list_user_scripts() -> list[str]:
    return [p.name for p in sorted(ADDONS_DIR.glob("*.js"))]
