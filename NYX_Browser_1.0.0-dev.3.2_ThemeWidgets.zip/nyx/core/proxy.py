from PySide6.QtNetwork import QNetworkProxy


def configure_proxy(settings: dict) -> None:
    """Configure the process-wide proxy before the first WebEngine profile is created."""
    if not settings.get('proxy_enabled'):
        QNetworkProxy.setApplicationProxy(QNetworkProxy(QNetworkProxy.ProxyType.NoProxy))
        return
    host = str(settings.get('proxy_host', '')).strip()
    port = int(settings.get('proxy_port') or 0)
    if not host or not (1 <= port <= 65535):
        QNetworkProxy.setApplicationProxy(QNetworkProxy(QNetworkProxy.ProxyType.NoProxy))
        return
    proxy_type = str(settings.get('proxy_type', 'HTTP')).upper()
    kind = QNetworkProxy.ProxyType.Socks5Proxy if proxy_type == 'SOCKS5' else QNetworkProxy.ProxyType.HttpProxy
    proxy = QNetworkProxy(kind, host, port)
    username = str(settings.get('proxy_username', '')).strip()
    password = str(settings.get('proxy_password', ''))
    if username:
        proxy.setUser(username)
    if password:
        proxy.setPassword(password)
    QNetworkProxy.setApplicationProxy(proxy)
