"""Password metadata in SQLite; secrets are stored in the OS credential vault via keyring."""
from __future__ import annotations
from urllib.parse import urlparse
from nyx.core.storage import connect_db, now_iso

SERVICE = 'NYX Browser'

def _key(origin: str, username: str) -> str:
    return f'{origin}|{username}'

def save_credential(url: str, username: str, password: str, title: str = '') -> None:
    import keyring
    origin = urlparse(url).netloc.lower()
    if not origin or not username or not password:
        raise ValueError('Нужны сайт, логин и пароль')
    keyring.set_password(SERVICE, _key(origin, username), password)
    with connect_db() as db:
        db.execute('''INSERT INTO credentials(origin,username,title,updated_at) VALUES(?,?,?,?)
          ON CONFLICT(origin,username) DO UPDATE SET title=excluded.title,updated_at=excluded.updated_at''',
          (origin, username, title or origin, now_iso()))

def list_credentials(origin: str = '') -> list[dict]:
    with connect_db() as db:
        if origin:
            rows = db.execute('SELECT origin,username,title,updated_at FROM credentials WHERE origin=? ORDER BY username', (origin.lower(),)).fetchall()
        else:
            rows = db.execute('SELECT origin,username,title,updated_at FROM credentials ORDER BY origin,username').fetchall()
        return [dict(r) for r in rows]

def get_password(origin: str, username: str) -> str | None:
    import keyring
    return keyring.get_password(SERVICE, _key(origin.lower(), username))

def delete_credential(origin: str, username: str) -> None:
    import keyring
    try: keyring.delete_password(SERVICE, _key(origin.lower(), username))
    except keyring.errors.PasswordDeleteError: pass
    with connect_db() as db:
        db.execute('DELETE FROM credentials WHERE origin=? AND username=?', (origin.lower(), username))
