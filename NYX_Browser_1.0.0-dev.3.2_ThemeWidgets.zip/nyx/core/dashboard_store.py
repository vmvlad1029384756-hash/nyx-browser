from __future__ import annotations

import json
import os
from pathlib import Path
from PySide6.QtCore import QObject, Slot
from nyx.core.storage import APP_DIR, get_suggestions, record_search

DASHBOARD_FILE = APP_DIR / "dashboard.json"
MAX_DASHBOARD_BYTES = 2 * 1024 * 1024


class DashboardStore(QObject):
    """Small QWebChannel bridge that persists the start-page layout outside file:// storage."""

    def __init__(self, parent=None, private_mode: bool = False):
        super().__init__(parent)
        self.private_mode = bool(private_mode)

    @Slot(str, result=str)
    def getSuggestions(self, prefix: str) -> str:
        if self.private_mode:
            return "[]"
        try:
            return json.dumps(get_suggestions(prefix, 12), ensure_ascii=False)
        except Exception:
            return "[]"

    @Slot(str, str)
    def recordSearch(self, query: str, engine: str) -> None:
        if self.private_mode:
            return
        try:
            record_search(query, engine, private=False)
        except Exception:
            return

    @Slot(result=str)
    def loadDashboard(self) -> str:
        try:
            if not DASHBOARD_FILE.exists():
                return ""
            raw = DASHBOARD_FILE.read_text(encoding="utf-8")
            if len(raw.encode("utf-8")) > MAX_DASHBOARD_BYTES:
                return ""
            value = json.loads(raw)
            if not isinstance(value, dict) or not isinstance(value.get("items"), list):
                return ""
            return raw
        except (OSError, json.JSONDecodeError):
            return ""

    @Slot(str)
    def saveDashboard(self, payload: str) -> None:
        if not payload or len(payload.encode("utf-8")) > MAX_DASHBOARD_BYTES:
            return
        try:
            value = json.loads(payload)
            if not isinstance(value, dict) or not isinstance(value.get("items"), list):
                return
            DASHBOARD_FILE.parent.mkdir(parents=True, exist_ok=True)
            temp = DASHBOARD_FILE.with_suffix(".json.tmp")
            temp.write_text(json.dumps(value, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")
            os.replace(temp, DASHBOARD_FILE)
        except (OSError, json.JSONDecodeError, TypeError):
            return
