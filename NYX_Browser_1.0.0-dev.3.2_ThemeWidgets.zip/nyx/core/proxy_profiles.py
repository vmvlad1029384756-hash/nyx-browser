"""Parsing helpers for common Simple Proxy Switcher text formats."""
from __future__ import annotations

from urllib.parse import unquote, urlsplit


def parse_proxy_line(raw: str) -> dict | None:
    line = (raw or '').strip()
    if not line or line.startswith('#'):
        return None

    # Simple Proxy Switcher commonly exports HOST:PORT:USERNAME:PASSWORD.
    if '://' not in line and '@' not in line:
        parts = line.split(':')
        if len(parts) == 4:
            host, port_text, username, password = parts
            try:
                port = int(port_text)
            except ValueError:
                port = 0
            if host and 1 <= port <= 65535:
                return {
                    'name': f'HTTP · {host}:{port}', 'type': 'HTTP', 'host': host,
                    'port': port, 'username': unquote(username), 'password': unquote(password),
                }

    candidate = line if '://' in line else 'http://' + line
    try:
        parsed = urlsplit(candidate)
        scheme = parsed.scheme.lower()
        if scheme not in ('http', 'https', 'socks5') or not parsed.hostname or not parsed.port:
            return None
        kind = 'SOCKS5' if scheme == 'socks5' else 'HTTP'
        return {
            'name': f'{kind} · {parsed.hostname}:{parsed.port}', 'type': kind,
            'host': parsed.hostname, 'port': parsed.port,
            'username': unquote(parsed.username or ''),
            'password': unquote(parsed.password or ''),
        }
    except ValueError:
        return None
