import sys
from PySide6.QtWidgets import QApplication
from PySide6.QtGui import QFont
from nyx.core.storage import load_settings, init_db
from nyx.core.migrations import create_pre_v1_snapshot
from nyx.core.proxy import configure_proxy
from nyx.ui.main_window import MainWindow, APP_STYLE

def main():
    create_pre_v1_snapshot()
    settings=load_settings()
    # Set proxy before creating the first WebEngine profile/page.
    configure_proxy(settings)
    init_db()
    app=QApplication(sys.argv)
    app.setApplicationName('NYX Browser')
    app.setApplicationVersion('1.0.0-dev.3.2')
    app.setOrganizationName('NYX')
    app.setFont(QFont('Segoe UI',10))
    app.setStyleSheet(APP_STYLE)
    window=MainWindow();window.show()
    sys.exit(app.exec())

if __name__=='__main__':
    main()
