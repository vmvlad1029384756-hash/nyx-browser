from __future__ import annotations
import json
import sys
import re
from pathlib import Path

from PySide6.QtCore import Qt, QUrl, QUrlQuery, Signal, QEvent, QTimer, QStringListModel, QPropertyAnimation, QEasingCurve, QSize
from PySide6.QtGui import QAction, QKeySequence, QIcon
from PySide6.QtWidgets import (
    QMainWindow, QToolBar, QLineEdit, QPushButton, QStatusBar,
    QMessageBox, QInputDialog, QDialog, QTextBrowser, QLabel,
    QMenu, QApplication, QWidget, QHBoxLayout, QVBoxLayout, QStackedWidget,
    QTabBar, QSizeGrip, QToolButton, QCompleter, QFileDialog, QStyle, QFrame
)
from PySide6.QtWebEngineCore import QWebEngineProfile, QWebEngineSettings
from PySide6.QtNetwork import QNetworkAccessManager, QNetworkRequest

from nyx.core.storage import (load_settings, save_settings, save_note, get_note, save_session,
    ADDONS_DIR, APP_DIR, DOWNLOADS_DIR, record_visit, record_search, get_suggestions,
    add_bookmark, list_bookmarks, list_downloads, save_download)
from nyx.core.proxy import configure_proxy
from nyx.core.extensions import install_user_scripts, list_user_scripts
from nyx.core.adblock import NYXRequestInterceptor
from nyx.ui.browser_tab import BrowserTab, PAGES_DIR
from nyx.ui.dialogs import (
    SettingsDialog, DarkLabDialog, NoteDialog, SpacesDialog, TimeMachineDialog,
    CommandPalette, ExtensionsDialog, PrivacyDialog
)
from nyx.ui.chat_dialog import ChatDialog
from nyx.ui.daily_dialogs import (HistoryDialog, BookmarksDialog, DownloadsDialog,
    ThemeEditorDialog, SitePermissionsDialog, BackupDialog)
from nyx.ui.password_dialog import PasswordDialog
from nyx.core.password_vault import list_credentials, get_password

APP_ICON = Path(__file__).resolve().parents[1] / 'assets' / 'nyx.ico'

APP_STYLE = """
QMainWindow,QWidget{background:#090811;color:#f5f2ff;font-family:'Inter','Segoe UI';font-size:10pt}
QMainWindow{border:1px solid #302a40}
QToolBar{background:#0e0c18;border:0;spacing:8px;padding:10px 14px;border-bottom:1px solid #302a40}
QToolButton,QPushButton{background:#141222;color:#eee9ff;border:1px solid #302a40;border-radius:12px;padding:8px 12px;min-height:20px}
QToolButton:hover,QPushButton:hover{background:#211c31;border-color:#a98bff;color:#fff}
QToolButton:pressed,QPushButton:pressed{background:#2b2242}
QLineEdit{background:#0c0b14;color:#f5f2ff;border:1px solid #302a40;border-radius:14px;padding:10px 15px;selection-background-color:#a98bff;selection-color:#160e2b}
QLineEdit:focus{border:1px solid #a98bff;background:#141222;padding:10px 15px}
QTabBar{background:#0e0c18}QTabBar::tab{background:#141222;color:#a29bb6;border:1px solid #302a40;padding:10px 17px;margin:4px 3px 0;min-width:115px;max-width:220px;border-top-left-radius:11px;border-top-right-radius:11px}
QTabBar::tab:selected{background:#211c31;color:#cbb9ff;border-color:#a98bff}
QTabBar::close-button{subcontrol-position:right;width:14px;height:14px;margin-right:5px;border-radius:7px}
QTabBar::close-button:hover{background:#583b3b}
QToolButton#tabCloseButton{background:transparent;color:#b8b0c9;border:0;border-radius:7px;padding:0;font-size:17pt;font-weight:500}
QToolButton#tabCloseButton:hover{background:#583b3b;color:#fff}
QStatusBar{background:#0e0c18;color:#a29bb6;border-top:1px solid #302a40}
QMenuBar{background:#0e0c18;color:#eee9ff;padding:4px}QMenuBar::item:selected{background:#211c31}
QMenu{background:#141222;color:#f5f2ff;border:1px solid #302a40}QMenu::item:selected{background:#211c31;color:#cbb9ff}
QAbstractItemView{background:#141222;color:#f5f2ff;selection-background-color:#211c31;selection-color:#cbb9ff;border:1px solid #302a40;outline:0}
QScrollBar:vertical{background:#0e0c18;width:10px;margin:0;border:0}QScrollBar::handle:vertical{background:#302a40;min-height:26px;border-radius:5px}QScrollBar::handle:vertical:hover{background:#a98bff}QScrollBar::add-line:vertical,QScrollBar::sub-line:vertical{height:0}
QScrollBar:horizontal{background:#0e0c18;height:10px;margin:0;border:0}QScrollBar::handle:horizontal{background:#302a40;min-width:26px;border-radius:5px}QScrollBar::handle:horizontal:hover{background:#a98bff}QScrollBar::add-line:horizontal,QScrollBar::sub-line:horizontal{width:0}
QToolTip{background:#141222;color:#f5f2ff;border:1px solid #302a40;padding:5px 8px;border-radius:7px}
#nyxTitleBar{background:#0e0c18;border-bottom:1px solid #302a40}
#titleLogo{background:qlineargradient(x1:0,y1:0,x2:1,y2:1,stop:0 #211c31,stop:1 #141222);color:#cbb9ff;border:1px solid #a98bff;border-radius:10px;font-size:15px;font-weight:900}
#titleText{font-size:12pt;font-weight:800;color:#f5f2ff}
#titleSubtitle{font-size:8pt;font-weight:700;letter-spacing:1px;color:#a29bb6;margin-left:5px}
#windowControlButton{background:transparent;border:0;border-radius:7px;padding:0;color:#b8b0c9;font-size:13pt;min-height:0}
#windowControlButton:hover{background:#211c31;color:#fff}
#windowCloseButton:hover{background:#c44747;color:white}
#newTabButton{background:#211c31;color:#cbb9ff;border:1px solid #302a40;border-radius:10px;font-size:18pt;font-weight:500;padding:0;min-height:0}
#newTabButton:hover{background:qlineargradient(x1:0,y1:0,x2:1,y2:1,stop:0 #a98bff,stop:1 #7654df);color:#160e2b;border-color:#a98bff}
#tabRow{background:#0e0c18;border-bottom:1px solid #302a40}
#browserPageStack{background:#090811}
#nyxSidebar{background:#0e0c18;border-right:1px solid #302a40}
#nyxSidebar[collapsed="true"]{background:transparent;border:0}
QToolButton#sidebarAction{background:transparent;border:1px solid transparent;border-radius:13px;text-align:left;padding:10px 14px;color:#a29bb6;min-height:42px;font-size:10pt;font-weight:650}
QToolButton#sidebarAction:hover{background:#1a172b;color:#f5f2ff;border-color:#302a40}
QToolButton#sidebarAction:checked{background:#211c31;color:#cbb9ff;border:1px solid #a98bff}
QToolButton#sidebarPin{background:#1a172b;border:1px solid #302a40;border-radius:11px;color:#cbb9ff;padding:7px 12px;font-size:14pt}
QToolButton#sidebarPin:hover{background:#211c31;border-color:#a98bff}
QLabel#sidebarBrand{background:qlineargradient(x1:0,y1:0,x2:1,y2:1,stop:0 #a98bff,stop:1 #7654df);color:#160e2b;border-radius:12px;font-size:17px;font-weight:950}
QFrame#sidebarDivider{color:#302a40}
QFrame#sidebarEdgeGrip{background:#a98bff;border-radius:2px}
QToolButton#toolbarActionButton{background:#141222;color:#a29bb6;border:1px solid #302a40;border-radius:12px;padding:0;font-size:17pt;font-weight:500}
QToolButton#toolbarActionButton:hover{background:#211c31;color:#cbb9ff;border-color:#a98bff}
"""

class BrowserTabHost(QWidget):
    """Chrome-like tab strip, add-tab control, navigation bar and page stack."""
    currentChanged = Signal(int)
    tabCloseRequested = Signal(int)
    newTabRequested = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.root = QVBoxLayout(self)
        self.root.setContentsMargins(6, 0, 6, 0)
        self.root.setSpacing(0)
        self.title_host = None
        self.nav_widget = None
        self.tab_row = QWidget(self)
        self.tab_row.setObjectName('tabRow')
        row = QHBoxLayout(self.tab_row)
        row.setContentsMargins(5, 5, 5, 0)
        row.setSpacing(5)
        self._bar = QTabBar(self.tab_row)
        self._bar.setDocumentMode(True)
        self._bar.setMovable(True)
        self._bar.setTabsClosable(True)
        self._bar.setExpanding(False)
        self._bar.setElideMode(Qt.TextElideMode.ElideRight)
        self._bar.setUsesScrollButtons(True)
        self._bar.currentChanged.connect(self._on_current_changed)
        self._bar.tabCloseRequested.connect(self.tabCloseRequested.emit)
        self._bar.tabMoved.connect(self._on_tab_moved)
        row.addWidget(self._bar, 0)
        self.new_button = QPushButton('+', self.tab_row)
        self.new_button.setObjectName('newTabButton')
        self.new_button.setFixedSize(34, 34)
        self.new_button.setToolTip('Новая вкладка · Ctrl+T')
        self.new_button.clicked.connect(self.newTabRequested.emit)
        row.addWidget(self.new_button, 0, Qt.AlignmentFlag.AlignVCenter)
        row.addStretch(1)
        self.root.addWidget(self.tab_row)
        self.stack = QStackedWidget(self)
        self.stack.setObjectName('browserPageStack')
        self.root.addWidget(self.stack, 1)

    def setTitleBar(self, widget):
        if self.title_host is not None:
            self.root.removeWidget(self.title_host)
            self.title_host.deleteLater()
        self.title_host = widget
        self.root.insertWidget(0, widget)

    def setNavigationWidget(self, widget):
        if self.nav_widget is not None:
            self.root.removeWidget(self.nav_widget)
        self.nav_widget = widget
        index = 2 if self.title_host is not None else 1
        self.root.insertWidget(index, widget)

    def tabBar(self): return self._bar
    def setMovable(self, value): self._bar.setMovable(value)
    def setTabsClosable(self, value): self._bar.setTabsClosable(value)
    def setDocumentMode(self, _value): pass
    def setTabPosition(self, _value): pass
    def setCornerWidget(self, *_args): pass
    def count(self): return self._bar.count()
    def currentIndex(self): return self._bar.currentIndex()
    def currentWidget(self): return self.stack.currentWidget()
    def widget(self, index): return self.stack.widget(index)
    def indexOf(self, widget): return self.stack.indexOf(widget)
    def setCurrentIndex(self, index): self._bar.setCurrentIndex(index)
    def setTabText(self, index, text): self._bar.setTabText(index, text)

    def _install_close_button(self, index: int) -> None:
        button = QToolButton(self._bar)
        button.setObjectName('tabCloseButton')
        button.setText('×')
        button.setAutoRaise(True)
        button.setCursor(Qt.CursorShape.PointingHandCursor)
        button.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        button.setFixedSize(22, 22)
        button.setToolTip('Закрыть вкладку')
        button.clicked.connect(lambda _checked=False, b=button: self._close_from_button(b))
        self._bar.setTabButton(index, QTabBar.ButtonPosition.RightSide, button)

    def _close_from_button(self, button) -> None:
        index = self._bar.tabAt(button.geometry().center())
        if index >= 0:
            self.tabCloseRequested.emit(index)

    def addTab(self, widget, label):
        self.stack.addWidget(widget)
        index = self._bar.addTab(label)
        self._install_close_button(index)
        self._bar.setCurrentIndex(index)
        return index

    def removeTab(self, index):
        if index < 0 or index >= self.count(): return
        widget = self.stack.widget(index)
        self.stack.removeWidget(widget)
        self._bar.removeTab(index)

    def _on_tab_moved(self, source, destination):
        widget = self.stack.widget(source)
        if widget is not None:
            self.stack.removeWidget(widget)
            self.stack.insertWidget(destination, widget)
            self.stack.setCurrentIndex(self._bar.currentIndex())

    def _on_current_changed(self, index):
        if index >= 0:
            self.stack.setCurrentIndex(index)
        self.currentChanged.emit(index)

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton and not self.window().isMaximized():
            p = event.position().toPoint(); m = 7; edges = Qt.Edge(0)
            if p.x() <= m: edges |= Qt.Edge.LeftEdge
            elif p.x() >= self.width()-m: edges |= Qt.Edge.RightEdge
            if p.y() <= m: edges |= Qt.Edge.TopEdge
            elif p.y() >= self.height()-m: edges |= Qt.Edge.BottomEdge
            if edges:
                handle = self.window().windowHandle()
                if handle: handle.startSystemResize(edges)
                event.accept(); return
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event):
        if not self.window().isMaximized():
            p=event.position().toPoint(); m=7
            left=p.x()<=m; right=p.x()>=self.width()-m; top=p.y()<=m; bottom=p.y()>=self.height()-m
            if (left and top) or (right and bottom): self.setCursor(Qt.CursorShape.SizeFDiagCursor)
            elif (right and top) or (left and bottom): self.setCursor(Qt.CursorShape.SizeBDiagCursor)
            elif left or right: self.setCursor(Qt.CursorShape.SizeHorCursor)
            elif top or bottom: self.setCursor(Qt.CursorShape.SizeVerCursor)
            else: self.setCursor(Qt.CursorShape.ArrowCursor)
        super().mouseMoveEvent(event)

class WindowTitleBar(QWidget):
    """Custom dark title strip with native system move and window controls."""
    def __init__(self, window):
        super().__init__(window)
        self.window = window
        self.setObjectName('nyxTitleBar')
        self.setFixedHeight(40)
        layout = QHBoxLayout(self)
        layout.setContentsMargins(13, 0, 8, 0)
        layout.setSpacing(9)
        logo = QLabel('N', self); logo.setObjectName('titleLogo')
        logo.setFixedSize(25, 25); logo.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.title_label = QLabel('NYX Browser', self); self.title_label.setObjectName('titleText')
        self.subtitle = QLabel('PRODUCTIVITY EDITION', self); self.subtitle.setObjectName('titleSubtitle')
        layout.addWidget(logo); layout.addWidget(self.title_label); layout.addWidget(self.subtitle)
        layout.addStretch(1)
        self.min_btn = self._window_button('—', 'Свернуть', self.window.showMinimized)
        self.max_btn = self._window_button('□', 'Развернуть', self.toggle_maximize)
        self.close_btn = self._window_button('×', 'Закрыть', self.window.close)
        self.close_btn.setObjectName('windowCloseButton')
        layout.addWidget(self.min_btn); layout.addWidget(self.max_btn); layout.addWidget(self.close_btn)

    def _window_button(self, text, tooltip, callback):
        button = QPushButton(text, self)
        button.setObjectName('windowControlButton')
        button.setFixedSize(38, 29)
        button.setToolTip(tooltip)
        button.clicked.connect(callback)
        return button

    def toggle_maximize(self):
        if self.window.isMaximized(): self.window.showNormal()
        else: self.window.showMaximized()
        self.max_btn.setText('❐' if self.window.isMaximized() else '□')

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            point = event.position().toPoint()
            handle = self.window.windowHandle()
            if handle and not self.window.isMaximized() and point.y() <= 6:
                edges = Qt.Edge.TopEdge
                if point.x() <= 7: edges |= Qt.Edge.LeftEdge
                elif point.x() >= self.width() - 7: edges |= Qt.Edge.RightEdge
                handle.startSystemResize(edges)
            elif handle:
                handle.startSystemMove()
        super().mousePressEvent(event)

    def mouseDoubleClickEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self.toggle_maximize()
        super().mouseDoubleClickEvent(event)


class BrowserSidebar(QWidget):
    """Low-profile, Opera-GX-inspired overlay drawer; collapsed state is only a slim edge tab."""
    actionRequested = Signal(str)
    pinChanged = Signal(bool)

    ITEMS = [
        ("home", "Главная", "⌂"), ("bookmarks", "Закладки", "☆"),
        ("history", "История", "◷"), ("downloads", "Загрузки", "↓"),
        ("passwords", "Пароли", "▣"), ("extensions", "Расширения", "◇"),
        ("proxy", "Proxy Switcher", "⇄"), ("games", "NYX Arcade", "▸"),
        ("privacy", "Приватность", "◈"), ("settings", "Настройки", "⚙"),
    ]

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("nyxSidebar")
        self._pinned = False
        self._expanded = False
        self._buttons = []
        self._drawer_side = 'left'
        self.setMouseTracking(True)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(2, 14, 2, 14)
        layout.setSpacing(7)
        self.brand = QLabel('N', self); self.brand.setObjectName('sidebarBrand')
        self.brand.setAlignment(Qt.AlignmentFlag.AlignCenter); self.brand.setFixedHeight(38)
        layout.addWidget(self.brand)
        self.pin_button = QToolButton(self); self.pin_button.setObjectName('sidebarPin')
        self.pin_button.setText('⌖'); self.pin_button.setToolTip('Закрепить панель')
        self.pin_button.setCheckable(True); self.pin_button.clicked.connect(self._toggle_pin)
        layout.addWidget(self.pin_button, 0, Qt.AlignmentFlag.AlignHCenter)
        line = QFrame(self); line.setFrameShape(QFrame.Shape.HLine); line.setObjectName('sidebarDivider')
        layout.addWidget(line)
        for key, label, glyph in self.ITEMS:
            button = QToolButton(self); button.setObjectName('sidebarAction')
            button.setText(glyph); button.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextOnly)
            button.setCursor(Qt.CursorShape.PointingHandCursor)
            button.setCheckable(True); button.setFixedHeight(44)
            button.setToolTip(label)
            button.clicked.connect(lambda _checked=False, k=key: self.actionRequested.emit(k))
            layout.addWidget(button); self._buttons.append(button)
        layout.addStretch(1)
        self.edge_grip = QFrame(self); self.edge_grip.setObjectName('sidebarEdgeGrip')
        self.edge_grip.setFixedSize(4, 58)
        layout.addWidget(self.edge_grip, 0, Qt.AlignmentFlag.AlignHCenter)
        self.brand.hide(); self.pin_button.hide(); line.hide()
        for button in self._buttons: button.hide()
        self.setProperty('collapsed', True)
        self._drawer_anim = QPropertyAnimation(self, b"geometry", self)
        self._drawer_anim.setDuration(190)
        self._drawer_anim.setEasingCurve(QEasingCurve.Type.OutCubic)

    def enterEvent(self, event):
        mw = self.window()
        if not self._pinned and getattr(mw, 'settings', {}).get('sidebar_hover_expand', True):
            self.set_expanded(True)
        super().enterEvent(event)

    def leaveEvent(self, event):
        if not self._pinned:
            self.set_expanded(False)
        super().leaveEvent(event)

    def mousePressEvent(self, event):
        if not self._expanded and event.button() == Qt.MouseButton.LeftButton:
            self.set_expanded(True)
            event.accept(); return
        super().mousePressEvent(event)

    def _toggle_pin(self, checked):
        self._pinned = bool(checked)
        self.pinChanged.emit(self._pinned)
        self.pin_button.setText('⌖' if checked else '◇')
        self.pin_button.setToolTip('Открепить панель' if checked else 'Закрепить панель')
        self.set_expanded(checked or self.underMouse())

    def set_expanded(self, expanded):
        expanded = bool(expanded or self._pinned)
        if expanded == self._expanded: return
        self._expanded = expanded
        self.layout().setContentsMargins(10, 14, 10, 14) if expanded else self.layout().setContentsMargins(2, 14, 2, 14)
        self.setProperty('collapsed', not expanded)
        self.edge_grip.setVisible(not expanded)
        self.style().unpolish(self); self.style().polish(self)
        width = 252 if expanded else 8
        self.brand.setVisible(expanded); self.pin_button.setVisible(expanded)
        self.findChild(QFrame, 'sidebarDivider').setVisible(expanded)
        for button, (_, label, glyph) in zip(self._buttons, self.ITEMS):
            button.setText((glyph + '    ' + label) if expanded else '')
            button.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextOnly)
            button.setVisible(expanded)
        mw = self.window()
        self._drawer_anim.setDuration(190 if getattr(mw, 'settings', {}).get('ui_animations', True) else 0)
        self._drawer_anim.stop()
        current = self.geometry()
        target = current.adjusted(current.width()-width, 0, 0, 0) if self._drawer_side == 'right' else current.adjusted(0, 0, width-current.width(), 0)
        self._drawer_anim.setStartValue(current); self._drawer_anim.setEndValue(target); self._drawer_anim.start()

    def set_pinned(self, pinned):
        self._pinned = bool(pinned)
        self.pin_button.setChecked(self._pinned)
        self.set_expanded(self._pinned)

    def select(self, key):
        for button, (item_key, _label, _glyph) in zip(self._buttons, self.ITEMS):
            button.setChecked(item_key == key)


class MainWindow(QMainWindow):
    _private_windows = []

    def __init__(self, private_mode: bool = False):
        super().__init__()
        self.private_mode = bool(private_mode)
        self.settings=load_settings()
        self.setWindowTitle('NYX Browser — Инкогнито' if self.private_mode else 'NYX Browser 1.0.0-dev.3.2')
        self.setWindowIcon(QIcon(str(APP_ICON)))
        self.setWindowFlags(Qt.WindowType.Window | Qt.WindowType.FramelessWindowHint)
        self.resize(1480,930); self.setMinimumSize(900,620)
        if self.private_mode:
            # A profile constructed with only a parent is off-the-record: cookies/cache live in memory.
            self.profile = QWebEngineProfile(self)
            self.profile.setPersistentCookiesPolicy(QWebEngineProfile.PersistentCookiesPolicy.NoPersistentCookies)
        else:
            self.profile = QWebEngineProfile('NYX Browser', self)
            profile_dir = APP_DIR / 'web_profile'
            cache_dir = APP_DIR / 'web_cache'
            profile_dir.mkdir(parents=True, exist_ok=True); cache_dir.mkdir(parents=True, exist_ok=True)
            self.profile.setPersistentStoragePath(str(profile_dir))
            self.profile.setCachePath(str(cache_dir))
            self.profile.setPersistentCookiesPolicy(QWebEngineProfile.PersistentCookiesPolicy.ForcePersistentCookies)
        self.profile.settings().setAttribute(QWebEngineSettings.WebAttribute.LocalStorageEnabled, True)
        # Modern media players rely on the browser's standard fullscreen API.
        self.profile.settings().setAttribute(QWebEngineSettings.WebAttribute.FullScreenSupportEnabled, True)
        self.profile.settings().setAttribute(QWebEngineSettings.WebAttribute.PlaybackRequiresUserGesture, False)
        self.profile.settings().setAttribute(QWebEngineSettings.WebAttribute.JavascriptEnabled, True)
        self.profile.settings().setAttribute(QWebEngineSettings.WebAttribute.LocalContentCanAccessRemoteUrls, True)
        self.interceptor=NYXRequestInterceptor(lambda:self.settings,self.profile)
        self.profile.setUrlRequestInterceptor(self.interceptor)
        self.refresh_addons()
        self.active_downloads = {}
        self.profile.downloadRequested.connect(self.handle_download_request)

        self.tabs=BrowserTabHost(self)
        self.tabs.tabCloseRequested.connect(self.close_tab)
        self.tabs.currentChanged.connect(self.on_current_tab_changed)
        self.tabs.newTabRequested.connect(self.new_tab)
        self.title_bar=WindowTitleBar(self)
        if self.private_mode:
            self.title_bar.title_label.setText('NYX Browser · Инкогнито')
            self.title_bar.subtitle.setText('PRIVATE SESSION')
        self.tabs.setTitleBar(self.title_bar)

        self.toolbar=QToolBar('NYX Navigation'); self.toolbar.setMovable(False); self.toolbar.setFloatable(False)
        self.toolbar.setIconSize(self.toolbar.iconSize())
        self.back_btn=self._button('‹','Назад',self.go_back); self.forward_btn=self._button('›','Вперёд',self.go_forward)
        self.reload_btn=self._button('↻','Обновить',self.reload_page); self.home_btn=self._button('⌂','Главная',self.go_home)
        for b in (self.back_btn,self.forward_btn,self.reload_btn,self.home_btn): b.setFixedWidth(40); self.toolbar.addWidget(b)
        self.address=QLineEdit(); self.address.setPlaceholderText('Поиск или адрес сайта'); self.address.setClearButtonEnabled(True)
        self.address.returnPressed.connect(self.navigate_from_address); self.toolbar.addWidget(self.address)
        self.suggestion_model = QStringListModel(self)
        self.suggestion_timer = QTimer(self); self.suggestion_timer.setSingleShot(True); self.suggestion_timer.setInterval(220)
        self.suggestion_timer.timeout.connect(self.fetch_online_suggestions)
        self.suggestion_network = QNetworkAccessManager(self)
        self._suggestion_prefix = ''
        self.address_completer = QCompleter(self.suggestion_model, self)
        self.address_completer.setCaseSensitivity(Qt.CaseSensitivity.CaseInsensitive)
        self.address_completer.setFilterMode(Qt.MatchFlag.MatchContains)
        self.address_completer.setCompletionMode(QCompleter.CompletionMode.PopupCompletion)
        self.address.setCompleter(self.address_completer)
        self.address.textEdited.connect(self.update_address_suggestions)
        self.address.textEdited.connect(lambda _text: self.suggestion_timer.start())
        self.address_completer.activated[str].connect(self.use_address_suggestion)
        self.toolbar.addSeparator()
        self.downloads_btn=self._button('↓','Загрузки · Ctrl+J',self.open_downloads); self.downloads_btn.setObjectName('toolbarActionButton'); self.toolbar.addWidget(self.downloads_btn)
        self.extensions_btn=self._button('◈','Расширения',self.open_extensions); self.extensions_btn.setObjectName('toolbarActionButton'); self.toolbar.addWidget(self.extensions_btn)
        self.incognito_btn=self._button('◉','Новое окно инкогнито · Ctrl+Shift+N',self.open_incognito_window); self.incognito_btn.setObjectName('toolbarActionButton'); self.toolbar.addWidget(self.incognito_btn)
        self.downloads_btn.setFixedSize(40,40); self.extensions_btn.setFixedSize(40,40); self.incognito_btn.setFixedSize(40,40)
        self.tabs.setNavigationWidget(self.toolbar)
        self.sidebar = BrowserSidebar(self)
        self.sidebar.actionRequested.connect(self._sidebar_action)
        self.sidebar.pinChanged.connect(self._sidebar_pin_changed)
        self.sidebar.select('home')
        self.workspace = QWidget(self)
        workspace_layout = QHBoxLayout(self.workspace)
        workspace_layout.setContentsMargins(0, 0, 0, 0); workspace_layout.setSpacing(0)
        self.workspace_layout = workspace_layout
        workspace_layout.addWidget(self.tabs, 1)
        self.sidebar.setParent(self.tabs)
        self.sidebar.set_pinned(bool(self.settings.get('sidebar_pinned', False)))
        self._apply_sidebar_position()
        self.setCentralWidget(self.workspace)
        self.status=QStatusBar(); self.setStatusBar(self.status); self.status.showMessage('NYX Browser 1.0.0-dev.3 · Ready'); self.status.addPermanentWidget(QSizeGrip(self))
        self.menuBar().hide()
        self.apply_theme()
        self.create_shortcuts(); self.focus_mode=False
        self._startup_tab_pending = True
        self._memory_saver_not_supported_notified = False
        self._last_active_at = {}
        self.memory_timer = QTimer(self); self.memory_timer.setInterval(30000); self.memory_timer.timeout.connect(self.apply_memory_saver); self.memory_timer.start()
        self.checkpoint_timer = QTimer(self); self.checkpoint_timer.setSingleShot(True); self.checkpoint_timer.setInterval(700); self.checkpoint_timer.timeout.connect(self.write_session_checkpoint)
        if not self.private_mode and self.settings.get('restore_session_on_startup'):
            saved = [u for u in self.settings.get('last_session_urls', []) if isinstance(u, str)]
            if saved: self.restore_urls(saved)
            else: self.new_tab()
        else:
            self.new_tab()
        QTimer.singleShot(0, self.restore_native_extensions)

    def restore_native_extensions(self):
        if self.private_mode or not hasattr(self.profile, 'extensionManager'): return
        try:
            manager = self.profile.extensionManager()
            enabled_ids = set(self.settings.get('native_extensions_enabled') or [])
            def enable_saved(info):
                if info.id() in enabled_ids and not info.isEnabled():
                    manager.setExtensionEnabled(info, True)
            for info in manager.extensions(): enable_saved(info)
            manager.loadFinished.connect(enable_saved)
            manager.installFinished.connect(enable_saved)
        except Exception as exc:
            if hasattr(self, 'status'): self.status.showMessage(f'Не удалось восстановить расширения: {exc}', 7000)

    def _apply_sidebar_position(self):
        if not hasattr(self, 'sidebar') or not hasattr(self, 'tabs'): return
        self.sidebar._drawer_side = 'right' if self.settings.get('sidebar_side', 'left') == 'right' else 'left'
        self._position_sidebar()

    def _position_sidebar(self):
        if not hasattr(self, 'sidebar') or not hasattr(self, 'tabs'): return
        top = self.title_bar.height() + self.tabs.tab_row.height() + (self.toolbar.sizeHint().height() if hasattr(self, 'toolbar') else 0)
        top = min(top, max(0, self.tabs.height() - 80))
        height = max(80, self.tabs.height() - top)
        width = 252 if self.sidebar._expanded else 8
        x = self.tabs.width() - width if self.sidebar._drawer_side == 'right' else 0
        self.sidebar.setGeometry(x, top, width, height)
        self.sidebar.raise_()

    def resizeEvent(self, event):
        super().resizeEvent(event)
        QTimer.singleShot(0, self._position_sidebar)

    def _sidebar_pin_changed(self, pinned):
        self.settings['sidebar_pinned'] = bool(pinned)
        if not self.private_mode:
            persisted = dict(self.settings); persisted.pop('proxy_password', None)
            save_settings(persisted)

    def _sidebar_action(self, key):
        actions = {
            'home': self.go_home, 'history': self.open_history,
            'bookmarks': self.open_bookmarks, 'downloads': self.open_downloads,
            'passwords': self.open_password_manager, 'extensions': self.open_extensions,
            'games': self.open_games, 'privacy': self.open_privacy, 'settings': self.open_settings, 'proxy': lambda: self.open_settings(2),
        }
        action = actions.get(key)
        if action: action()
        if hasattr(self, 'sidebar'): self.sidebar.select(key)

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton and not self.isMaximized():
            edges = self._resize_edges(event.position().toPoint())
            if edges:
                handle = self.windowHandle()
                if handle: handle.startSystemResize(edges)
                event.accept(); return
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event):
        if not self.isMaximized():
            edges = self._resize_edges(event.position().toPoint())
            cursors = {
                Qt.Edge.LeftEdge | Qt.Edge.TopEdge: Qt.CursorShape.SizeFDiagCursor,
                Qt.Edge.RightEdge | Qt.Edge.BottomEdge: Qt.CursorShape.SizeFDiagCursor,
                Qt.Edge.RightEdge | Qt.Edge.TopEdge: Qt.CursorShape.SizeBDiagCursor,
                Qt.Edge.LeftEdge | Qt.Edge.BottomEdge: Qt.CursorShape.SizeBDiagCursor,
                Qt.Edge.LeftEdge: Qt.CursorShape.SizeHorCursor,
                Qt.Edge.RightEdge: Qt.CursorShape.SizeHorCursor,
                Qt.Edge.TopEdge: Qt.CursorShape.SizeVerCursor,
                Qt.Edge.BottomEdge: Qt.CursorShape.SizeVerCursor,
            }
            self.setCursor(cursors.get(edges, Qt.CursorShape.ArrowCursor))
        super().mouseMoveEvent(event)

    def _resize_edges(self, point):
        margin = 7; edges = Qt.Edge(0)
        if point.x() <= margin: edges |= Qt.Edge.LeftEdge
        elif point.x() >= self.width() - margin: edges |= Qt.Edge.RightEdge
        if point.y() <= margin: edges |= Qt.Edge.TopEdge
        elif point.y() >= self.height() - margin: edges |= Qt.Edge.BottomEdge
        return edges

    def _button(self,text,tooltip,callback):
        icons = {
            '‹': QStyle.StandardPixmap.SP_ArrowBack,
            '›': QStyle.StandardPixmap.SP_ArrowForward,
            '↻': QStyle.StandardPixmap.SP_BrowserReload,
            '⌂': QStyle.StandardPixmap.SP_DirHomeIcon,
            '◷': QStyle.StandardPixmap.SP_FileDialogDetailedView,
            '☆': QStyle.StandardPixmap.SP_DialogSaveButton,
            '↓': QStyle.StandardPixmap.SP_ArrowDown,
            '◉': QStyle.StandardPixmap.SP_ComputerIcon,
            '✦ AI': QStyle.StandardPixmap.SP_DialogHelpButton,
            '🎮': QStyle.StandardPixmap.SP_MediaPlay,
            '⚙': QStyle.StandardPixmap.SP_FileDialogContentsView,
            '⋯': QStyle.StandardPixmap.SP_TitleBarMenuButton,
            '🔐': QStyle.StandardPixmap.SP_DialogApplyButton,
            '文': QStyle.StandardPixmap.SP_FileDialogInfoView,
        }
        b=QPushButton(); b.setToolTip(tooltip); b.setCursor(Qt.CursorShape.PointingHandCursor)
        pixmap = icons.get(text)
        if pixmap is not None:
            b.setIcon(self.style().standardIcon(pixmap)); b.setIconSize(QSize(18, 18))
            if text == '✦ AI': b.setText('AI')
        else: b.setText(text)
        b.clicked.connect(callback); return b

    def create_menus(self):
        bar=self.menuBar(); nyx=bar.addMenu('NYX')
        groups=[('Новое окно инкогнито · Ctrl+Shift+N','open_incognito_window'),('Командный центр','command_palette'),('Настройки','open_settings'),('Рабочие пространства','open_spaces'),('Разделить экран','toggle_multiview'),('Заметки для сайта','open_memory'),('Dark Lab','open_dark_lab'),('Privacy Radar','open_privacy'),('Time Machine','open_time_machine'),('Deep Focus','toggle_focus'),('Intelligence','open_intelligence'),('Мини-плеер','open_float'),('Режим чтения','open_reader'),('NYX Arcade','open_games'),('Расширения','open_extensions'),('Мессенджер','open_messenger')]
        for label,method in groups:
            action=QAction(label,self); action.triggered.connect(getattr(self,method)); nyx.addAction(action)
        view=bar.addMenu('Вид'); view.addAction('Увеличить масштаб',self.zoom_in); view.addAction('Уменьшить масштаб',self.zoom_out); view.addAction('Сбросить масштаб',self.zoom_reset); view.addSeparator(); view.addAction('Перезагрузить страницу',self.reload_page); view.addAction('Домашняя страница',self.go_home); view.addSeparator(); view.addAction('Перевести страницу',self.translate_page); view.addAction('Менеджер паролей',self.open_password_manager); view.addAction('Автозаполнить логин',self.autofill_login); view.addAction('Сохранить логин',self.save_current_login)
        help_menu=bar.addMenu('Справка'); help_menu.addAction('О NYX Browser',self.show_about)

    def show_tools_menu(self):
        menu=QMenu(self)
        for label,method in [('◷ История · Ctrl+H',self.open_history),('☆ Закладки',self.open_bookmarks),('↓ Загрузки · Ctrl+J',self.open_downloads),('Менеджер паролей',self.open_password_manager),('⌨ Автозаполнить логин',self.autofill_login),('＋ Сохранить логин',self.save_current_login),('Перевести страницу',self.translate_page),('◉ Новое окно инкогнито',self.open_incognito_window),('⇧ Резервная копия',self.open_backup_manager),('⌘ Command Center',self.command_palette),('⚙ Настройки',self.open_settings),('▦ Spaces',self.open_spaces),('◫ Multiview',self.toggle_multiview),('✎ Memory',self.open_memory),('◐ Dark Lab',self.open_dark_lab),('◈ Privacy Radar',self.open_privacy),('↶ Time Machine',self.open_time_machine),('◎ Deep Focus',self.toggle_focus),('✦ Intelligence',self.open_intelligence),('▶ Float Player',self.open_float),('▤ Reader Mode',self.open_reader),('NYX Arcade',self.open_games),('＋ Add-ons',self.open_extensions),('☏ Messenger',self.open_messenger)]:
            a=menu.addAction(label); a.triggered.connect(method)
        menu.exec(self.extensions_btn.mapToGlobal(self.extensions_btn.rect().bottomLeft()))

    def create_shortcuts(self):
        mapping=[('Ctrl+=',self.zoom_in),('Ctrl++',self.zoom_in),('Ctrl+-',self.zoom_out),('Ctrl+0',self.zoom_reset),('Ctrl+T',self.new_tab),('Ctrl+W',self.close_current_tab),('Ctrl+L',self.focus_address),('Alt+Left',self.go_back),('Alt+Right',self.go_forward),('Ctrl+R',self.reload_page),('Alt+Home',self.go_home),('Ctrl+Space',self.command_palette),('Ctrl+Shift+F',self.toggle_focus),('Ctrl+Shift+M',self.open_memory),('Ctrl+Shift+G',self.open_games),('Ctrl+Shift+P',self.open_settings),('Ctrl+H',self.open_history),('Ctrl+J',self.open_downloads),('Ctrl+Shift+O',self.open_bookmarks),('Ctrl+Shift+N',self.open_incognito_window),('Ctrl+D',self.add_current_bookmark),('Ctrl+Shift+L',self.autofill_login),('Ctrl+Shift+S',self.save_current_login)]
        for key,fn in mapping:
            a=QAction(self); a.setShortcut(QKeySequence(key)); a.setShortcutContext(Qt.ShortcutContext.WindowShortcut); a.triggered.connect(fn); self.addAction(a)
        esc=QAction(self); esc.setShortcut(QKeySequence('Escape')); esc.triggered.connect(self.leave_focus); self.addAction(esc)

    def current_tab(self):
        w=self.tabs.currentWidget(); return w if isinstance(w,BrowserTab) else None
    def current_view(self):
        tab=self.current_tab(); return tab.active_view if tab else None

    def new_tab(self,url:QUrl|None=None):
        tab=BrowserTab(profile=self.profile, private_mode=self.private_mode)
        if self._startup_tab_pending and not self.settings.get('startup_home', True) and url is None:
            tab.view.setUrl(QUrl('about:blank'))
        self._startup_tab_pending = False
        index=self.tabs.addTab(tab,'Новая вкладка'); self.tabs.setCurrentIndex(index)
        tab.titleChanged.connect(lambda view,title,t=tab:self.update_tab_title(t,view,title))
        tab.urlChanged.connect(lambda view,u,t=tab:self.update_address(t,view,u))
        tab.loadChanged.connect(lambda view,ok:self.on_page_load(view,ok))
        tab.urlChanged.connect(lambda *_: self.schedule_session_checkpoint())
        if url: tab.navigate(url)
        self._last_active_at[id(tab)] = __import__('time').monotonic()
        self.schedule_session_checkpoint()
        self.focus_address()

    def on_page_load(self,view,ok):
        self.status.showMessage('Страница загружена' if ok else 'Загрузка не завершена — проверьте адрес, сеть, прокси или консоль сайта', 8000)
        self.update_navigation_state()
        if ok:
            current_url = view.url().toString()
            if not self.private_mode:
                record_visit(current_url, view.title(), private=False)
            self.schedule_session_checkpoint()
            self.apply_dark_override(view)
            self.sync_home_settings(view)

    def update_address_suggestions(self, text: str):
        if self.private_mode or not text.strip():
            self.suggestion_model.setStringList([]); return
        try:
            local = get_suggestions(text, 10) if not self.private_mode else []
            self.suggestion_model.setStringList(local)
        except Exception: self.suggestion_model.setStringList([])

    def use_address_suggestion(self, text: str):
        self.address.setText(text)
        self.navigate_from_address()

    def fetch_online_suggestions(self):
        """Fetch Google search suggestions asynchronously; local history remains available offline."""
        if not self.settings.get('online_suggestions', True): return
        text = self.address.text().strip()
        if len(text) < 2:
            return
        self._suggestion_prefix = text
        url = QUrl('https://suggestqueries.google.com/complete/search')
        query = QUrlQuery(); query.addQueryItem('client', 'firefox'); query.addQueryItem('q', text)
        url.setQuery(query)
        request = QNetworkRequest(url)
        request.setHeader(QNetworkRequest.KnownHeaders.UserAgentHeader, 'NYX Browser')
        reply = self.suggestion_network.get(request)
        reply.finished.connect(lambda r=reply, q=text: self._online_suggestions_finished(r, q))

    def _online_suggestions_finished(self, reply, query):
        try:
            if reply.error(): return
            if self.address.text().strip() != query: return
            payload = json.loads(bytes(reply.readAll()).decode('utf-8'))
            online = payload[1] if isinstance(payload, list) and len(payload) > 1 else []
            local = get_suggestions(query, 10) if not self.private_mode else []
            combined = []
            for item in list(online) + list(local):
                if isinstance(item, str) and item not in combined: combined.append(item)
            self.suggestion_model.setStringList(combined[:12])
            if combined and self.address.hasFocus(): self.address_completer.complete()
        except Exception:
            pass
        finally:
            reply.deleteLater()

    def open_password_manager(self):
        view = self.current_view()
        if self.private_mode:
            QMessageBox.information(self, 'Инкогнито', 'Менеджер паролей недоступен в приватном окне.')
            return
        dlg = PasswordDialog(view.url().toString() if view else '', view.title() if view else '', self)
        dlg.exec()

    def save_current_login(self):
        view = self.current_view()
        if not view or self.private_mode: return
        dlg = PasswordDialog(view.url().toString(), view.title(), self)
        dlg.add_entry(); dlg.exec()

    def autofill_login(self):
        view = self.current_view()
        if not view or self.private_mode: return
        from urllib.parse import urlparse
        origin = urlparse(view.url().toString()).netloc.lower()
        entries = list_credentials(origin)
        if not entries:
            QMessageBox.information(self, 'Автозаполнение', 'Для этого сайта ещё нет сохранённых логинов.')
            return
        labels = [f"{x['username']} — {x['origin']}" for x in entries]
        choice, ok = QInputDialog.getItem(self, 'Автозаполнение', 'Выбери аккаунт:', labels, 0, False)
        if not ok: return
        entry = entries[labels.index(choice)]
        try: password = get_password(origin, entry['username'])
        except Exception as exc:
            QMessageBox.warning(self, 'Хранилище паролей', f'Не удалось получить пароль из системного хранилища: {exc}')
            return
        if not password:
            QMessageBox.warning(self, 'Автозаполнение', 'Пароль не найден в системном хранилище.')
            return
        payload = json.dumps({'u': entry['username'], 'p': password})
        js = """(d)=>{const u=document.querySelector('input[autocomplete=username],input[type=email],input[name*=user i],input[name*=login i]');const p=document.querySelector('input[type=password]');if(!u||!p)return 'FIELDS_NOT_FOUND';const set=(e,v)=>{const s=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set;s.call(e,v);e.dispatchEvent(new Event('input',{bubbles:true}));e.dispatchEvent(new Event('change',{bubbles:true}));};set(u,d.u);set(p,d.p);return 'FILLED';}"""
        view.page().runJavaScript(f"({js})({payload})", lambda result: self.status.showMessage('Данные заполнены' if result == 'FILLED' else 'Не удалось определить поля входа на странице', 5000))

    def translate_page(self):
        view = self.current_view()
        if not view: return
        url = view.url()
        if url.scheme() not in ('http', 'https'):
            QMessageBox.information(self, 'Перевод', 'Эту внутреннюю страницу нельзя перевести.')
            return
        translated = QUrl('https://translate.google.com/translate')
        query = QUrlQuery(); query.addQueryItem('sl', 'auto'); query.addQueryItem('tl', 'ru'); query.addQueryItem('u', url.toString())
        translated.setQuery(query)
        self.new_tab(translated)

    def sync_home_settings(self, view):
        try:
            url = view.url()
            if url.isLocalFile() and url.toLocalFile().lower().endswith(('home.html', 'games.html')):
                engine = json.dumps(self.settings.get('search_engine', 'Google'))
                theme = self.settings.get('theme', 'NYX Violet')
                presets = {
                    'NYX Violet': {'background':'#090811','panel':'#141222','surface':'#1a172b','border':'#302a40','accent':'#a98bff','accent2':'#7654df','muted':'#a29bb6','hover':'#211c31','soft':'#cbb9ff','ink':'#160e2b','text':'#f5f2ff'},
                    'NYX Emerald': {'background':'#080b09','panel':'#101712','surface':'#18221b','border':'#304238','accent':'#65e6a0','accent2':'#269b5d','muted':'#849288','hover':'#203127','soft':'#a7efc0','ink':'#06130b','text':'#eff5f0'},
                    'NYX Crimson': {'background':'#10090e','panel':'#1b1118','surface':'#281923','border':'#51303f','accent':'#fb7185','accent2':'#d94665','muted':'#b3939e','hover':'#351d2a','soft':'#ffd0d9','ink':'#210b12','text':'#fff1f4'},
                    'NYX Azure': {'background':'#080d14','panel':'#101824','surface':'#18263a','border':'#304b6b','accent':'#60a5fa','accent2':'#357fe4','muted':'#8297b3','hover':'#1f3550','soft':'#bfdbfe','ink':'#071426','text':'#eff6ff'},
                    'AMOLED Black': {'background':'#000000','panel':'#08080b','surface':'#111116','border':'#302b3a','accent':'#a98bff','accent2':'#7654df','muted':'#938ba8','hover':'#211c2c','soft':'#d8caff','ink':'#100b1c','text':'#f2efff'},
                    'Midnight': {'background':'#080b14','panel':'#111626','surface':'#1b2235','border':'#35405c','accent':'#a78bfa','accent2':'#6550bd','muted':'#939bb3','hover':'#27324c','soft':'#d8caff','ink':'#0c1020','text':'#eff2ff'},
                }
                palette = dict(presets.get(theme, presets['NYX Violet']))
                custom = self.settings.get('custom_theme', {}) or {}
                if theme == 'Пользовательская' and custom.get('apply_to_home', True): palette.update({k:v for k,v in custom.items() if k in ('background','panel','surface','border','accent','accent2','muted','text','font_family','radius')})
                view.page().runJavaScript(f"window.NYX_SEARCH_ENGINE = {engine}; window.NYX_THEME = {json.dumps(palette)}; if(window.applyNyxTheme) window.applyNyxTheme();")
        except Exception:
            pass

    def update_tab_title(self,tab,view,title):
        i=self.tabs.indexOf(tab)
        if i>=0 and view is tab.view: self.tabs.setTabText(i,(title.strip() if title else 'Новая вкладка')[:24])

    def update_address(self,tab,view,url):
        if tab is self.current_tab() and view is tab.active_view:
            self.address.setText('' if url.isLocalFile() else url.toString()); self.update_navigation_state()

    def on_current_tab_changed(self,_index):
        view=self.current_view()
        if view: self.address.setText('' if view.url().isLocalFile() else view.url().toString())
        tab=self.current_tab()
        if tab: self._last_active_at[id(tab)] = __import__('time').monotonic()
        self.restore_active_tab_lifecycle()
        self.update_navigation_state()

    def navigate_from_address(self):
        raw=self.address.text().strip()
        if not raw:return
        part=raw.split('/')[0]; is_url='.' in part and ' ' not in raw
        if is_url:
            url=QUrl.fromUserInput(raw if '://' in raw else 'https://'+raw)
        else:
            engine=self.settings.get('search_engine','Google')
            engines={'Google':'https://www.google.com/search?q=','DuckDuckGo':'https://duckduckgo.com/?q=','Bing':'https://www.bing.com/search?q=','Brave Search':'https://search.brave.com/search?q='}
            base=engines.get(engine,engines['Google'])
            url=QUrl(base+QUrl.toPercentEncoding(raw).data().decode('ascii'))
            record_search(raw, engine, private=self.private_mode)
        if self.current_tab(): self.current_tab().navigate(url)

    def go_back(self):
        v=self.current_view()
        if v:v.back()
    def go_forward(self):
        v=self.current_view()
        if v:v.forward()
    def reload_page(self):
        v=self.current_view()
        if v:v.reload()
    def go_home(self):
        t=self.current_tab()
        if t:t.load_home()

    def zoom_in(self):
        view = self.current_view()
        if view: view.setZoomFactor(min(5.0, view.zoomFactor() + 0.1))

    def zoom_out(self):
        view = self.current_view()
        if view: view.setZoomFactor(max(0.25, view.zoomFactor() - 0.1))

    def zoom_reset(self):
        view = self.current_view()
        if view: view.setZoomFactor(1.0)
    def close_tab(self,index):
        if index<0 or index>=self.tabs.count():return
        if self.tabs.count()==1:
            old=self.tabs.widget(index); self.tabs.removeTab(index); old.deleteLater(); self.new_tab(); return
        old=self.tabs.widget(index); self.tabs.removeTab(index); old.deleteLater(); self.schedule_session_checkpoint()
    def close_current_tab(self):self.close_tab(self.tabs.currentIndex())
    def focus_address(self):self.address.setFocus();self.address.selectAll()
    def update_navigation_state(self):
        v=self.current_view()
        if not v:self.back_btn.setEnabled(False);self.forward_btn.setEnabled(False);return
        h=v.history();self.back_btn.setEnabled(h.canGoBack());self.forward_btn.setEnabled(h.canGoForward())

    def collect_urls(self):
        urls=[]
        for i in range(self.tabs.count()):
            t=self.tabs.widget(i)
            if isinstance(t,BrowserTab):
                for v in t.all_views():
                    u=v.url().toString()
                    if u and not u.startswith('file:'): urls.append(u)
        return urls
    def restore_urls(self,urls):
        for i in reversed(range(self.tabs.count())):
            w=self.tabs.widget(i);self.tabs.removeTab(i);w.deleteLater()
        if not urls:self.new_tab();return
        for url in urls:
            if url == 'nyx://home': self.new_tab(QUrl.fromLocalFile(str(PAGES_DIR/'home.html')))
            elif url == 'nyx://games': self.new_tab(QUrl.fromLocalFile(str(PAGES_DIR/'games.html')))
            elif url == 'about:blank': self.new_tab(QUrl('about:blank'))
            else: self.new_tab(QUrl.fromUserInput(url))
        self.schedule_session_checkpoint()

    def open_url(self, url: str):
        if not url: return
        if self.current_tab(): self.current_tab().navigate(QUrl.fromUserInput(url))
        else: self.new_tab(QUrl.fromUserInput(url))

    def open_history(self):
        if self.private_mode:
            QMessageBox.information(self, 'Инкогнито', 'История не записывается в приватном окне.')
            return
        HistoryDialog(self.open_url, self).exec()

    def add_current_bookmark(self):
        view = self.current_view()
        if not view: return
        url = view.url().toString()
        if not url.startswith(('http://','https://')):
            self.status.showMessage('Эту внутреннюю страницу нельзя добавить в закладки.', 4000); return
        from PySide6.QtWidgets import QInputDialog
        folder, ok = QInputDialog.getText(self, 'Добавить закладку', 'Папка:', text='Без папки')
        if not ok: return
        add_bookmark(view.title() or url, url, folder.strip() or 'Без папки')
        self.status.showMessage('Закладка сохранена.', 3500)

    def open_bookmarks(self):
        view = self.current_view()
        current = {'title': view.title(), 'url': view.url().toString()} if view else {}
        BookmarksDialog(self.open_url, current, self).exec()

    def open_downloads(self):
        DownloadsDialog(self).exec()

    def open_backup_manager(self):
        BackupDialog(self).exec()

    def open_incognito_window(self):
        private = MainWindow(private_mode=True)
        private.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose, True)
        MainWindow._private_windows.append(private)
        private.destroyed.connect(lambda *_: MainWindow._private_windows.remove(private) if private in MainWindow._private_windows else None)
        private.show()
        private.focus_address()

    def handle_download_request(self, download):
        try:
            suggested = Path(download.downloadFileName() or 'download').name
            suggested = re.sub(r'[<>:"/\\|?*\x00-\x1f]', '_', suggested).strip(' .') or 'download'
            reserved = {'CON', 'PRN', 'AUX', 'NUL'} | {f'COM{i}' for i in range(1, 10)} | {f'LPT{i}' for i in range(1, 10)}
            if suggested.upper().split('.')[0] in reserved:
                suggested = '_' + suggested
            base_dir = Path(self.settings.get('download_dir') or DOWNLOADS_DIR)
            base_dir.mkdir(parents=True, exist_ok=True)
            if self.settings.get('ask_download_location', True):
                target, _ = QFileDialog.getSaveFileName(self, 'Сохранить файл', str(base_dir / suggested), 'Все файлы (*)')
                if not target:
                    download.cancel(); return
                target_path = Path(target)
            else:
                target_path = base_dir / suggested
                stem, suffix = target_path.stem, target_path.suffix
                counter = 1
                while target_path.exists():
                    target_path = base_dir / f'{stem} ({counter}){suffix}'; counter += 1
            target_path.parent.mkdir(parents=True, exist_ok=True)
            download.setDownloadDirectory(str(target_path.parent))
            download.setDownloadFileName(target_path.name)
            url = download.url().toString()
            download.accept()
            download_id = None
            if not self.private_mode:
                download_id = save_download(url, target_path.name, str(target_path), 'Загружается', 0, max(0, int(download.totalBytes())))
            self.active_downloads[id(download)] = download
            progress_state = {'last_saved': 0, 'last_status': None}
            def update_download(*_args):
                state_obj = download.state()
                state_name = getattr(state_obj, 'name', str(state_obj).split('.')[-1])
                mapping = {'DownloadRequested':'Ожидание','DownloadInProgress':'Загружается','DownloadCompleted':'Завершено','DownloadCancelled':'Отменено','DownloadInterrupted':'Ошибка'}
                status = mapping.get(state_name, state_name)
                received = max(0, int(download.receivedBytes()))
                total = max(0, int(download.totalBytes()))
                terminal = status in ('Завершено','Отменено','Ошибка')
                if download_id is not None and (terminal or status != progress_state['last_status'] or received - progress_state['last_saved'] >= 512 * 1024):
                    save_download(url, target_path.name, str(target_path), status, received, total, download_id)
                    progress_state['last_saved'] = received
                    progress_state['last_status'] = status
                if terminal:
                    self.active_downloads.pop(id(download), None)
                    self.status.showMessage(f'Загрузка {status.lower()}: {target_path.name}', 6000)
                else:
                    self.status.showMessage(f'Загрузка: {target_path.name} · {received/1048576:.1f} MB', 3000)
            download.receivedBytesChanged.connect(update_download)
            download.totalBytesChanged.connect(update_download)
            download.stateChanged.connect(update_download)
            update_download()
        except Exception as exc:
            try: download.cancel()
            except Exception: pass
            QMessageBox.warning(self, 'Ошибка загрузки', str(exc))

    def schedule_session_checkpoint(self):
        if not self.private_mode and self.settings.get('restore_session_on_startup', False) and hasattr(self, 'checkpoint_timer'):
            self.checkpoint_timer.start()

    def _session_entries(self):
        entries = []
        for i in range(self.tabs.count()):
            tab = self.tabs.widget(i)
            if not isinstance(tab, BrowserTab): continue
            for view in tab.all_views():
                url = view.url()
                if url.isLocalFile():
                    local = Path(url.toLocalFile()).name.lower()
                    if local == 'home.html':
                        entries.append('nyx://home')
                    elif local == 'games.html':
                        entries.append('nyx://games')
                    elif local == 'offline.html':
                        retry_url = QUrlQuery(url).queryItemValue('retry')
                        if retry_url.startswith(('http://', 'https://')):
                            entries.append(retry_url)
                elif url.toString() == 'about:blank': entries.append('about:blank')
                elif url.scheme() in ('http', 'https'):
                    entries.append(url.toString())
        return entries

    def write_session_checkpoint(self):
        if self.private_mode or not self.settings.get('restore_session_on_startup', False): return
        self.settings['last_session_urls'] = self._session_entries()
        try:
            persisted = dict(self.settings); persisted.pop('proxy_password', None)
            save_settings(persisted)
        except OSError as exc:
            self.status.showMessage(f'Не удалось сохранить сессию: {exc}', 5000)

    def restore_active_tab_lifecycle(self):
        tab = self.current_tab()
        if not tab: return
        for view in tab.all_views():
            page = view.page()
            enum = getattr(type(page), 'LifecycleState', None) or getattr(page, 'LifecycleState', None)
            if enum and hasattr(page, 'setLifecycleState'):
                try: page.setLifecycleState(enum.Active)
                except Exception: pass

    def apply_memory_saver(self):
        if not self.settings.get('memory_saver_enabled', False): return
        current = self.current_tab()
        now = __import__('time').monotonic()
        delay = max(1, int(self.settings.get('memory_saver_delay_minutes', 10))) * 60
        supported = False
        for i in range(self.tabs.count()):
            tab = self.tabs.widget(i)
            if not isinstance(tab, BrowserTab) or tab is current: continue
            last = self._last_active_at.get(id(tab), now)
            if now - last < delay: continue
            for view in tab.all_views():
                page = view.page()
                enum = getattr(type(page), 'LifecycleState', None) or getattr(page, 'LifecycleState', None)
                if not enum or not hasattr(page, 'setLifecycleState'): continue
                supported = True
                try:
                    recommended = page.recommendedState() if hasattr(page, 'recommendedState') else enum.Frozen
                    recommended_name = getattr(recommended, 'name', str(recommended).split('.')[-1])
                    if recommended_name in ('Frozen', 'Discarded'):
                        page.setLifecycleState(enum.Frozen)
                except Exception:
                    pass
        if not supported and not self._memory_saver_not_supported_notified:
            self._memory_saver_not_supported_notified = True
            self.status.showMessage('Экономия памяти требует версии Qt WebEngine с Page Lifecycle API (обычно Qt 6.8+).', 7000)

    def closeEvent(self, event):
        if not self.private_mode and self.settings.get('restore_session_on_startup', False):
            self.write_session_checkpoint()
        elif not self.private_mode:
            self.settings['last_session_urls'] = []
            try:
                persisted = dict(self.settings); persisted.pop('proxy_password', None); save_settings(persisted)
            except OSError: pass
        super().closeEvent(event)

    def open_settings(self, initial_page=0):
        dlg=SettingsDialog(self.settings,self.profile,self)
        if hasattr(dlg, 'nav'): dlg.nav.setCurrentRow(max(0, min(dlg.nav.count()-1, int(initial_page))))
        if dlg.exec():
            self.settings=dlg.values()
            if not self.settings.get('restore_session_on_startup'):
                self.settings['last_session_urls'] = []
            else:
                self.schedule_session_checkpoint()
            # Do not persist proxy password in plaintext. It is kept only in memory.
            persisted=dict(self.settings); persisted.pop('proxy_password',None)
            save_settings(persisted); self.refresh_addons(); self.apply_theme()
            self._apply_sidebar_position()
            self.sidebar.set_pinned(bool(self.settings.get('sidebar_pinned', False)))
            self.status.setVisible(bool(self.settings.get('show_status_bar', True)))
            self._position_sidebar()
            for i in range(self.tabs.count()):
                tab=self.tabs.widget(i)
                if isinstance(tab,BrowserTab):
                    for v in tab.all_views(): self.sync_home_settings(v)
            self.status.showMessage('Настройки сохранены. Поиск и оформление обновлены; прокси применится после перезапуска.')

    def apply_theme(self):
        app=QApplication.instance()
        if not app:return
        theme=self.settings.get('theme','NYX Violet')
        palettes = {
            'NYX Violet': {'bg':'#090811','panel':'#141222','panel_alt':'#0e0c18','surface':'#1a172b','surface_alt':'#141222','border':'#302a40','border_alt':'#a98bff','accent':'#a98bff','accent2':'#7654df','soft':'#cbb9ff','hover':'#211c31','pressed':'#2b2242','muted':'#a29bb6','muted_alt':'#b8b0c9','text':'#f5f2ff','text_alt':'#eee9ff','ink':'#160e2b','sidebar_hover':'#1a172b','sidebar_selected':'#211c31','sidebar_muted':'#a29bb6','sidebar_soft':'#cbb9ff','line':'#302a40'},
            'NYX Emerald': {'bg':'#080b09','panel':'#101712','panel_alt':'#0d130f','surface':'#18221b','surface_alt':'#141b16','border':'#304238','border_alt':'#65e6a0','accent':'#65e6a0','accent2':'#269b5d','soft':'#a7efc0','hover':'#203127','pressed':'#2a4031','muted':'#849288','muted_alt':'#9baa9f','text':'#eff5f0','text_alt':'#e8f3eb','ink':'#06130b','sidebar_hover':'#1a281e','sidebar_selected':'#1b2920','sidebar_muted':'#718278','sidebar_soft':'#85efad','line':'#202e25'},
            'NYX Crimson': {'bg':'#10090e','panel':'#1b1118','panel_alt':'#160d13','surface':'#281923','surface_alt':'#21131b','border':'#51303f','border_alt':'#fb7185','accent':'#fb7185','accent2':'#d94665','soft':'#ffd0d9','hover':'#351d2a','pressed':'#482336','muted':'#b3939e','muted_alt':'#c6a6b0','text':'#fff1f4','text_alt':'#ffe7ed','ink':'#210b12','sidebar_hover':'#2a1721','sidebar_selected':'#351d2a','sidebar_muted':'#aa8794','sidebar_soft':'#ffd0d9','line':'#38202c'},
            'NYX Azure': {'bg':'#080d14','panel':'#101824','panel_alt':'#0d1420','surface':'#18263a','surface_alt':'#131f30','border':'#304b6b','border_alt':'#60a5fa','accent':'#60a5fa','accent2':'#357fe4','soft':'#bfdbfe','hover':'#1f3550','pressed':'#294566','muted':'#8297b3','muted_alt':'#9ab0cc','text':'#eff6ff','text_alt':'#e5f0ff','ink':'#071426','sidebar_hover':'#172a40','sidebar_selected':'#1f3550','sidebar_muted':'#8197b5','sidebar_soft':'#bfdbfe','line':'#202f43'},
            'AMOLED Black': {'bg':'#000000','panel':'#08080b','panel_alt':'#050507','surface':'#111116','surface_alt':'#0b0b10','border':'#302b3a','border_alt':'#a98bff','accent':'#a98bff','accent2':'#7654df','soft':'#d8caff','hover':'#211c2c','pressed':'#30263f','muted':'#938ba8','muted_alt':'#a9a1bc','text':'#f2efff','text_alt':'#eee9ff','ink':'#100b1c','sidebar_hover':'#191522','sidebar_selected':'#211c2c','sidebar_muted':'#8e86a2','sidebar_soft':'#c4b0ff','line':'#1b1723'},
            'Midnight': {'bg':'#080b14','panel':'#111626','panel_alt':'#0d1120','surface':'#1b2235','surface_alt':'#151c2d','border':'#35405c','border_alt':'#a78bfa','accent':'#a78bfa','accent2':'#6550bd','soft':'#d8caff','hover':'#27324c','pressed':'#34415f','muted':'#939bb3','muted_alt':'#a9b1c9','text':'#eff2ff','text_alt':'#e8edff','ink':'#0c1020','sidebar_hover':'#1b263d','sidebar_selected':'#27324c','sidebar_muted':'#8791ac','sidebar_soft':'#d8caff','line':'#202943'},
        }
        palette = dict(palettes.get(theme, palettes['NYX Violet']))
        style=APP_STYLE
        base = {
            '#090811':'bg','#141222':'panel','#0e0c18':'panel_alt','#1a172b':'surface','#302a40':'border',
            '#a98bff':'accent','#7654df':'accent2','#cbb9ff':'soft','#211c31':'hover','#2b2242':'pressed',
            '#a29bb6':'muted','#b8b0c9':'muted_alt','#f5f2ff':'text','#eee9ff':'text_alt','#160e2b':'ink'
        }
        for old, key in base.items(): style=style.replace(old, palette[key])
        custom=self.settings.get('custom_theme',{}) or {}
        if theme != 'Пользовательская': custom = {}
        custom_keys = {'background':'bg','panel':'panel','surface':'surface','border':'border','accent':'accent','accent2':'accent2','muted':'muted','text':'text'}
        for custom_key, palette_key in custom_keys.items():
            value = custom.get(custom_key)
            if re.fullmatch(r'#[0-9a-fA-F]{6}', str(value or '')):
                old = palette[palette_key]
                style = style.replace(old, str(value))
                palette[palette_key] = str(value)
        radius=custom.get('radius')
        if isinstance(radius,int): style=re.sub(r'border-radius:\s*\d+px',f'border-radius:{max(0,min(28,radius))}px',style)
        font=custom.get('font_family')
        if font and all(ch not in font for ch in "\r\n;{}'"): style=style.replace("font-family:'Inter','Segoe UI'",f"font-family:'{font}','Segoe UI'")
        app.setProperty('nyxTheme', theme)
        app.setProperty('nyxPalette', palette)
        app.setProperty('nyxAccent', palette['accent'])
        app.setProperty('nyxSoftAccent', palette['soft'])
        app.setProperty('nyxAccent2', palette['accent2'])
        app.setStyleSheet(style)
        if hasattr(self, 'sidebar') and self.sidebar.layout().count() > 1:
            separator = self.sidebar.layout().itemAt(1).widget()
            if separator is not None: separator.setStyleSheet('color:' + palette['line'])
        self._apply_windows_caption()
        for i in range(self.tabs.count()):
            tab=self.tabs.widget(i)
            if isinstance(tab,BrowserTab):
                for v in tab.all_views():
                    self.sync_home_settings(v)
                    self.apply_theme_accent_to_view(v, palette)
        # Rebuild the document-start style injector with the newly selected accent.
        self.refresh_addons()

    def apply_theme_accent_to_view(self, view, palette):
        accent = json.dumps(palette.get('accent', '#a98bff'))
        ink = json.dumps(palette.get('ink', '#160e2b'))
        js = f"""(()=>{{const a={accent},i={ink},id='nyx-theme-accent';let s=document.getElementById(id);if(!s){{s=document.createElement('style');s.id=id;(document.head||document.documentElement).appendChild(s)}}s.textContent=`::selection,*::selection,input::selection,textarea::selection,[contenteditable='true']::selection{{background:${{a}}!important;color:${{i}}!important}}a:not([role='button']):not(.button):not(button){{color:${{a}}!important}}:focus-visible{{outline-color:${{a}}!important}}`;document.documentElement.style.setProperty('--nyx-accent',a);if(window.__NYX_APPLY_ACCENT__)window.__NYX_APPLY_ACCENT__({{accent:a,ink:i}})}})();"""
        try: view.page().runJavaScript(js)
        except Exception: pass

    def refresh_addons(self):
        try:
            scripts=self.profile.scripts()
            scripts.clear()
            if self.settings.get('dark_engine',True):
                from nyx.engine.dark_engine import install_dark_engine
                app = QApplication.instance()
                palette = app.property('nyxPalette') if app else None
                install_dark_engine(self.profile, palette if isinstance(palette, dict) else None)
            install_user_scripts(self.profile,self.settings.get('enabled_addons',[]))
        except Exception as exc:
            if hasattr(self,'status'): self.status.showMessage(f'Add-ons: {exc}')

    def open_extensions(self):
        dlg=ExtensionsDialog(self.settings.get('enabled_addons',[]),self.profile,self,self.settings.get('native_extensions_enabled',[]))
        if dlg.exec():
            self.settings['enabled_addons']=dlg.selected_addons()
            self.settings['native_extensions_enabled']=dlg.selected_native_extensions()
            save_settings({k:v for k,v in self.settings.items() if k!='proxy_password'})
            self.refresh_addons()
            for i in range(self.tabs.count()):
                tab=self.tabs.widget(i)
                if isinstance(tab,BrowserTab):
                    for v in tab.all_views():v.reload()

    def open_spaces(self):
        dlg=SpacesDialog(self); dlg.exec()
        if dlg.result()==QDialog.DialogCode.Accepted:
            urls=dlg.selected_urls()
            if urls:self.restore_urls(urls)

    def open_time_machine(self):
        dlg=TimeMachineDialog(self); dlg.exec()
        if dlg.result()==QDialog.DialogCode.Accepted:
            urls=dlg.selected_urls()
            if urls:self.restore_urls(urls)

    def open_memory(self):
        view=self.current_view(); domain=view.url().host() if view else 'new tab'
        dlg=NoteDialog(domain,self)
        if dlg.exec():dlg.save();self.status.showMessage(f'Заметка сохранена: {domain}')

    def open_dark_lab(self):
        view=self.current_view()
        if not view:return
        host=view.url().host() or 'default'
        all_overrides=self.settings.setdefault('dark_lab',{})
        dlg=DarkLabDialog(all_overrides.get(host,{}),self)
        if dlg.exec():
            all_overrides[host]=dlg.values();save_settings({k:v for k,v in self.settings.items() if k!='proxy_password'});self.apply_dark_override(view)

    def apply_dark_override(self,view):
        host=view.url().host() or 'default';values=self.settings.get('dark_lab',{}).get(host)
        if not values:return
        intensity=max(0,min(100,int(values.get('intensity',72))))
        dim='true' if values.get('dim_images') else 'false'
        app=QApplication.instance(); palette=app.property('nyxPalette') if app else {}
        accent=(palette or {}).get('accent','#a98bff'); ink=(palette or {}).get('ink','#160e2b')
        script=f'''(()=>{{const id='nyx-darklab-user';let s=document.getElementById(id);if(!s){{s=document.createElement('style');s.id=id;(document.head||document.documentElement).appendChild(s)}}const level={intensity}/100;const bg=['#202027','#17171e','#101016'][Math.min(2,Math.floor(level*3))];s.textContent=`html,body{{background-color:${{bg}}!important;color:#e8e9ef!important}} ::selection,*::selection{{background:{accent}!important;color:{ink}!important}}`;if({dim}){{document.querySelectorAll('img,video').forEach(e=>e.style.filter='brightness(.86)')}}}})();'''
        view.page().runJavaScript(script)

    def open_privacy(self):PrivacyDialog(self.profile,self).exec()

    def toggle_multiview(self):
        tab=self.current_tab()
        if not tab:return
        if tab.secondary_view:
            tab.toggle_multiview();self.status.showMessage('Multiview выключен');return
        url,ok=QInputDialog.getText(self,'NYX MULTIVIEW','Адрес для второй панели:',text='https://www.google.com')
        if ok:
            if url and '://' not in url:url='https://'+url
            tab.toggle_multiview(QUrl.fromUserInput(url));self.status.showMessage('Multiview включён · нажми на нужную панель для переключения адресной строки')

    def toggle_focus(self):
        self.focus_mode=not self.focus_mode
        self.toolbar.setVisible(not self.focus_mode);self.tabs.tabBar().setVisible(not self.focus_mode);self.tabs.new_button.setVisible(not self.focus_mode);self.title_bar.setVisible(not self.focus_mode)
        self.menuBar().hide()
        if self.settings.get('focus_hide_status',True):self.statusBar().setVisible(not self.focus_mode)
        self.statusBar().showMessage('Deep Focus · Esc чтобы выйти',0) if self.focus_mode else self.statusBar().showMessage('Обычный режим')
    def leave_focus(self):
        if self.focus_mode:self.toggle_focus()

    def command_palette(self):
        dlg=CommandPalette(self)
        if dlg.exec():
            key=dlg.selected_command()
            actions={'new_tab':self.new_tab,'history':self.open_history,'bookmarks':self.open_bookmarks,'downloads':self.open_downloads,'incognito':self.open_incognito_window,'backup':self.open_backup_manager,'settings':self.open_settings,'reader':self.open_reader,'spaces':self.open_spaces,'multiview':self.toggle_multiview,'memory':self.open_memory,'darklab':self.open_dark_lab,'privacy':self.open_privacy,'timemachine':self.open_time_machine,'focus':self.toggle_focus,'games':self.open_games,'intelligence':self.open_intelligence,'float':self.open_float,'extensions':self.open_extensions,'messenger':self.open_messenger}
            if key in actions:actions[key]()

    def open_ai_mode(self):
        self.new_tab(QUrl('https://www.google.com/ai'))

    def open_games(self):
        self.new_tab(QUrl.fromLocalFile(str(PAGES_DIR/'games.html')))

    def open_float(self):
        view=self.current_view()
        if not view:return
        js="""(()=>{const v=[...document.querySelectorAll('video')].find(x=>x.readyState>=1&&x.videoWidth>0);if(!v)return 'NO_VIDEO';if(document.pictureInPictureElement){document.exitPictureInPicture();return 'EXIT_REQUESTED'}v.requestPictureInPicture().catch(()=>{});return 'REQUESTED'})()"""
        view.page().runJavaScript(js,lambda result:self.status.showMessage('Запрос Picture-in-Picture отправлен' if result=='REQUESTED' else ('Закрытие PiP запрошено' if result=='EXIT_REQUESTED' else 'На странице не найдено готовое видео'),5000))

    def open_reader(self):
        view=self.current_view()
        if not view:return
        js="JSON.stringify({title:document.title,text:(document.querySelector('article')||document.querySelector('main')||document.body).innerText.slice(0,60000)})"
        def show(raw):
            try:data=json.loads(raw or '{}')
            except Exception:data={'title':view.title(),'text':'Не удалось извлечь текст страницы.'}
            dlg=QDialog(self);dlg.setWindowTitle('NYX CLEAN VIEW');dlg.resize(760,700);lay=QVBoxLayout(dlg)
            lay.addWidget(QLabel(data.get('title','Режим чтения')));browser=QTextBrowser();browser.setPlainText(data.get('text',''));lay.addWidget(browser);dlg.exec()
        view.page().runJavaScript(js,show)

    def open_intelligence(self):
        view=self.current_view()
        if not view:return
        prompt,ok=QInputDialog.getText(self,'NYX INTELLIGENCE','Что попросить ChatGPT сделать с этой страницей?',text='Кратко перескажи эту страницу и выдели главное.')
        if not ok or not prompt.strip():return
        js="JSON.stringify({title:document.title,url:location.href,text:(document.querySelector('article')||document.querySelector('main')||document.body).innerText.slice(0,35000)})"
        def open_chat(raw):
            try:data=json.loads(raw or '{}')
            except Exception:data={'title':'','url':view.url().toString(),'text':''}
            payload=f"{prompt}\n\nСтраница: {data.get('title','')}\nURL: {data.get('url','')}\n\nСодержимое:\n{data.get('text','')}"
            QApplication.clipboard().setText(payload)
            self.new_tab(QUrl('https://chatgpt.com'))
            QMessageBox.information(self,'NYX INTELLIGENCE','Контекст страницы и запрос скопированы в буфер обмена. В ChatGPT нажми Ctrl+V.\n\nЭто работает через сайт ChatGPT и не требует API-ключа.')
        view.page().runJavaScript(js,open_chat)

    def open_messenger(self):
        dlg=ChatDialog(self.settings,self);dlg.exec()
        persisted=dict(self.settings);persisted.pop('proxy_password',None);save_settings(persisted)

    def changeEvent(self, event):
        super().changeEvent(event)
        if hasattr(self, 'title_bar') and event.type() == QEvent.Type.WindowStateChange:
            self.title_bar.max_btn.setText('❐' if self.isMaximized() else '□')

    def _apply_windows_caption(self):
        if sys.platform != 'win32': return
        try:
            import ctypes
            hwnd = int(self.winId())
            dwm = ctypes.WinDLL('dwmapi')
            def attr(number, value):
                data = ctypes.c_int(value)
                dwm.DwmSetWindowAttribute(ctypes.c_void_p(hwnd), number, ctypes.byref(data), ctypes.sizeof(data))
            attr(20, 1)  # DWMWA_USE_IMMERSIVE_DARK_MODE
            palette = QApplication.instance().property('nyxPalette') or {}
            def colorref(value, fallback):
                raw = str(value or fallback).lstrip('#')
                if len(raw) != 6: raw = fallback.lstrip('#')
                red, green, blue = (int(raw[i:i+2], 16) for i in (0, 2, 4))
                return (blue << 16) | (green << 8) | red
            attr(35, colorref(palette.get('panel_alt'), '#0e0c18'))
            attr(36, colorref(palette.get('text'), '#f5f2ff'))
            attr(34, colorref(palette.get('border'), '#302a40'))
        except Exception:
            pass

    def showEvent(self, event):
        super().showEvent(event)
        self._apply_windows_caption()

    def show_about(self):
        QMessageBox.about(self,'NYX Browser 1.0.0-dev.3.2','NYX Browser 1.0.0-dev.3.2\nDevelopment build — not a final release.\n\nChromium · Privacy · Password Vault · Extensions · NYX Arcade')
