from __future__ import annotations
from pathlib import Path
from PySide6.QtCore import QUrl, Signal, Qt
from PySide6.QtWidgets import QWidget, QVBoxLayout, QSplitter, QInputDialog, QLineEdit, QMessageBox, QCheckBox
from PySide6.QtWebEngineWidgets import QWebEngineView
from PySide6.QtWebEngineCore import QWebEnginePage
from PySide6.QtWebChannel import QWebChannel
from nyx.core.dashboard_store import DashboardStore
from nyx.core.storage import get_site_permission, save_site_permission

PAGES_DIR = Path(__file__).resolve().parents[1] / 'pages'
HOME_FILE = PAGES_DIR / 'home.html'
OFFLINE_FILE = PAGES_DIR / 'offline.html'

class FocusWebView(QWebEngineView):
    focused = Signal(object)
    def mousePressEvent(self,event):
        self.focused.emit(self)
        super().mousePressEvent(event)
    def focusInEvent(self,event):
        self.focused.emit(self)
        super().focusInEvent(event)

class BrowserTab(QWidget):
    urlChanged = Signal(object, object)
    titleChanged = Signal(object, str)
    loadChanged = Signal(object, bool)

    def __init__(self, profile=None, parent=None, private_mode: bool = False):
        super().__init__(parent)
        self.profile = profile
        self.private_mode = bool(private_mode)
        self.splitter=QSplitter(Qt.Orientation.Horizontal,self)
        self.layout_root=QVBoxLayout(self); self.layout_root.setContentsMargins(0,0,0,0); self.layout_root.setSpacing(0)
        self.layout_root.addWidget(self.splitter)
        self.view=self._new_view()
        self.splitter.addWidget(self.view)
        self.secondary_view=None
        self.active_view=self.view
        self.view.focused.connect(self.set_active_view)
        self.view.urlChanged.connect(lambda url,v=self.view:self.urlChanged.emit(v,url))
        self.view.titleChanged.connect(lambda title,v=self.view:self.titleChanged.emit(v,title))
        self.view.loadFinished.connect(lambda ok,v=self.view:self._on_load_finished(v,ok))
        self.view.loadStarted.connect(lambda v=self.view:self.loadChanged.emit(v,False))
        self.load_home()

    def _new_view(self):
        view=FocusWebView(self)
        if self.profile is not None:
            page = QWebEnginePage(self.profile, view)
            view.setPage(page)
            channel = QWebChannel(page)
            channel.registerObject('nyxDashboard', DashboardStore(page, self.private_mode))
            view.urlChanged.connect(lambda url, p=page, ch=channel: p.setWebChannel(ch if (url.isLocalFile() and Path(url.toLocalFile()).name.lower() == 'home.html') else None))
        page=view.page()
        page.proxyAuthenticationRequired.connect(self._proxy_authentication)
        # Keep renderer crashes visible to the UI instead of silently losing the tab.
        if hasattr(page, 'renderProcessTerminated'):
            page.renderProcessTerminated.connect(
                lambda status, code, v=view: self._on_renderer_terminated(v, status, code)
            )
        if hasattr(page,'permissionRequested'):
            page.permissionRequested.connect(self._permission_requested)
        elif hasattr(page,'featurePermissionRequested'):
            page.featurePermissionRequested.connect(lambda origin,feature,p=page:self._legacy_permission_requested(p,origin,feature))
        return view

    def _proxy_authentication(self,url,authenticator,proxy_host=''):
        username,ok=QInputDialog.getText(self,'Авторизация прокси',f'Логин для прокси {proxy_host or url.host()}:')
        if not ok: return
        password,ok=QInputDialog.getText(self,'Авторизация прокси','Пароль:',QLineEdit.EchoMode.Password)
        if ok:
            authenticator.setUser(username); authenticator.setPassword(password)

    def _permission_decision(self, origin: str, feature: str) -> bool:
        remembered = None if self.private_mode else get_site_permission(origin, feature)
        if remembered in ('allow', 'deny'):
            return remembered == 'allow'
        box = QMessageBox(self)
        box.setWindowTitle('Разрешение сайта')
        box.setText(f'{origin} запрашивает доступ: {feature}.')
        box.setInformativeText('Разрешать доступ этому сайту?')
        box.setIcon(QMessageBox.Icon.Question)
        box.setStandardButtons(QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        box.button(QMessageBox.StandardButton.Yes).setText('Разрешить')
        box.button(QMessageBox.StandardButton.No).setText('Запретить')
        remember = QCheckBox('Запомнить решение для этого сайта')
        remember.setEnabled(not self.private_mode)
        box.setCheckBox(remember)
        allowed = box.exec() == QMessageBox.StandardButton.Yes
        if remember.isChecked() and not self.private_mode:
            save_site_permission(origin, feature, 'allow' if allowed else 'deny')
        return allowed

    def _permission_requested(self, permission):
        origin = permission.origin().toString()
        feature = str(permission.permissionType()).split('.')[-1]
        if self._permission_decision(origin, feature): permission.grant()
        else: permission.deny()

    def _legacy_permission_requested(self, page, origin, feature):
        label = str(feature).split('.')[-1]
        allowed = self._permission_decision(origin.toString(), label)
        policy = QWebEnginePage.PermissionPolicy.PermissionGrantedByUser if allowed else QWebEnginePage.PermissionPolicy.PermissionDeniedByUser
        page.setFeaturePermission(origin, feature, policy)

    def _on_load_finished(self, view, ok):
        # Do not replace a failed remote navigation with offline.html. That hid the
        # original URL and made TLS, DNS, proxy and media failures impossible to
        # diagnose (and could create misleading retry loops).
        self.loadChanged.emit(view, bool(ok))

    def _on_renderer_terminated(self, view, status, exit_code):
        # Chromium's renderer can terminate independently of the Python process.
        self.loadChanged.emit(view, False)

    def set_active_view(self,view):
        if view in self.all_views():
            self.active_view=view
            self.urlChanged.emit(view,view.url())

    def all_views(self):
        return [self.view] + ([self.secondary_view] if self.secondary_view else [])

    def toggle_multiview(self,url:QUrl|None=None):
        if self.secondary_view:
            old=self.secondary_view; self.splitter.widget(1).setParent(None); old.deleteLater(); self.secondary_view=None; self.active_view=self.view
            return False
        self.secondary_view=self._new_view()
        self.secondary_view.focused.connect(self.set_active_view)
        self.secondary_view.urlChanged.connect(lambda u,v=self.secondary_view:self.urlChanged.emit(v,u))
        self.secondary_view.titleChanged.connect(lambda t,v=self.secondary_view:self.titleChanged.emit(v,t))
        self.secondary_view.loadFinished.connect(lambda ok,v=self.secondary_view:self._on_load_finished(v,ok))
        self.secondary_view.loadStarted.connect(lambda v=self.secondary_view:self.loadChanged.emit(v,False))
        self.splitter.addWidget(self.secondary_view)
        self.splitter.setSizes([1,1])
        if url: self.secondary_view.setUrl(url)
        else: self.secondary_view.load(QUrl('https://www.google.com'))
        self.active_view=self.secondary_view
        return True

    def load_home(self):
        self.view.load(QUrl.fromLocalFile(str(HOME_FILE)))

    def navigate(self,url:QUrl):
        self.active_view.setUrl(url)
