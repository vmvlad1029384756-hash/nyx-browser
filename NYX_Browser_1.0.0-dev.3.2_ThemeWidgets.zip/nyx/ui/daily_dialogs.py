from __future__ import annotations

import json
import os
import shutil
import sqlite3
import tempfile
import zipfile
from datetime import datetime
from pathlib import Path
from urllib.parse import urlsplit

from PySide6.QtCore import Qt, QUrl, QTimer
from PySide6.QtGui import QDesktopServices, QFontDatabase, QFont
from PySide6.QtWidgets import (QApplication, 
    QDialog, QVBoxLayout, QHBoxLayout, QFormLayout, QLabel, QLineEdit,
    QPushButton, QTableWidget, QTableWidgetItem, QHeaderView, QComboBox,
    QMessageBox, QFileDialog, QColorDialog, QFontComboBox, QSpinBox, QInputDialog,
    QCheckBox, QDialogButtonBox, QWidget
)

from nyx.core.storage import (
    APP_DIR, CONFIG_FILE, DB_FILE, DOWNLOADS_DIR,
    list_history, delete_history_entry, clear_history,
    list_bookmarks, add_bookmark, delete_bookmark, update_bookmark,
    list_downloads, delete_download, list_site_permissions, delete_site_permission,
)

STYLE = """
QDialog{background:#0a0e0b;color:#eef5ef;font-family:'Inter','Segoe UI';font-size:10pt}
QLabel{color:#dce7df}
QLineEdit,QComboBox,QSpinBox,QTableWidget{background:#121a15;color:#eef5ef;border:1px solid #2b3a30;border-radius:9px;padding:8px;selection-background-color:#65e6a0;selection-color:#08100b}
QHeaderView::section{background:#1a281e;color:#b9c9bd;padding:8px;border:0;border-bottom:1px solid #34473a}
QTableWidget{gridline-color:#27362c}
QPushButton{background:#18241c;color:#e8f4eb;border:1px solid #304238;border-radius:9px;padding:8px 13px;min-height:20px}
QPushButton:hover{border-color:#65e6a0;background:#203327}
QPushButton[primary="true"]{background:#65e6a0;color:#07130c;font-weight:700;border-color:#65e6a0}
"""

def format_local_time(value: str) -> str:
    try:
        parsed = datetime.fromisoformat(value.replace('Z', '+00:00'))
        if parsed.tzinfo is not None:
            parsed = parsed.astimezone()
        return parsed.strftime('%d.%m.%Y %H:%M:%S')
    except (TypeError, ValueError):
        return str(value or '')[:19].replace('T', ' ')


class DailyDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        app = QApplication.instance()
        palette = app.property('nyxPalette') if app else {}
        palette = palette if isinstance(palette, dict) else {}
        style = STYLE
        tokens = {'#0a0e0b': palette.get('bg','#090811'), '#121a15': palette.get('surface_alt','#1a172b'), '#2b3a30': palette.get('border','#302a40'), '#65e6a0': palette.get('accent','#a98bff'), '#1a281e': palette.get('hover','#211c31'), '#34473a': palette.get('border_alt','#a98bff'), '#203327': palette.get('hover','#211c31'), '#07130c': palette.get('ink','#160e2b'), '#eef5ef': palette.get('text','#f5f2ff'), '#dce7df': palette.get('text_alt','#eee9ff'), '#08100b': palette.get('ink','#160e2b'), '#b9c9bd': palette.get('muted_alt','#b8b0c9'), '#27362c': palette.get('line','#302a40'), '#18241c': palette.get('surface','#1a172b'), '#e8f4eb': palette.get('text_alt','#eee9ff'), '#304238': palette.get('border','#302a40')}
        for old, value in tokens.items(): style = style.replace(old, str(value))
        self.setStyleSheet(style)

    @staticmethod
    def _table(headers: list[str]) -> QTableWidget:
        table = QTableWidget(0, len(headers))
        table.setHorizontalHeaderLabels(headers)
        table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        table.setSelectionMode(QTableWidget.SelectionMode.SingleSelection)
        table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        table.verticalHeader().setVisible(False)
        table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        return table

class HistoryDialog(DailyDialog):
    def __init__(self, on_open, parent=None):
        super().__init__(parent)
        self.on_open = on_open
        self.setWindowTitle('История NYX')
        self.resize(900, 590)
        root = QVBoxLayout(self)
        root.addWidget(QLabel('Посещённые страницы и поисковые запросы'))
        self.search = QLineEdit(); self.search.setPlaceholderText('Поиск по названию, адресу или запросу…')
        root.addWidget(self.search)
        self.table = self._table(['Тип', 'Название / запрос', 'Адрес', 'Дата и время'])
        root.addWidget(self.table, 1)
        row = QHBoxLayout()
        self.open_btn = QPushButton('Открыть'); self.delete_btn = QPushButton('Удалить запись')
        self.clear_btn = QPushButton('Очистить историю'); close_btn = QPushButton('Закрыть')
        for b in (self.open_btn, self.delete_btn, self.clear_btn): row.addWidget(b)
        row.addStretch(1); row.addWidget(close_btn); root.addLayout(row)
        self.search.textChanged.connect(self.refresh)
        self.open_btn.clicked.connect(self.open_selected)
        self.table.cellDoubleClicked.connect(lambda *_: self.open_selected())
        self.delete_btn.clicked.connect(self.delete_selected)
        self.clear_btn.clicked.connect(self.clear_all)
        close_btn.clicked.connect(self.reject)
        self.refresh()

    def refresh(self):
        rows = list_history(self.search.text())
        self.table.setRowCount(len(rows))
        for r, item in enumerate(rows):
            kind = 'Поиск' if item['visit_type'] == 'search' else 'Сайт'
            vals = [kind, item.get('title', ''), item.get('url', ''), format_local_time(item.get('visited_at', ''))]
            for c, value in enumerate(vals):
                cell = QTableWidgetItem(str(value)); cell.setData(Qt.ItemDataRole.UserRole, (item['visit_type'], item['id'], item.get('url', '')))
                self.table.setItem(r, c, cell)

    def _selected(self):
        row = self.table.currentRow()
        if row < 0: return None
        item = self.table.item(row, 0)
        return item.data(Qt.ItemDataRole.UserRole) if item else None

    def open_selected(self):
        data = self._selected()
        if data:
            kind, _id, value = data
            if kind == 'search':
                from nyx.core.storage import load_settings
                engines = {'Google':'https://www.google.com/search?q=', 'DuckDuckGo':'https://duckduckgo.com/?q=', 'Bing':'https://www.bing.com/search?q=', 'Brave Search':'https://search.brave.com/search?q='}
                from urllib.parse import quote
                value = engines.get(load_settings().get('search_engine', 'Google'), engines['Google']) + quote(value)
            self.on_open(value)

    def delete_selected(self):
        data = self._selected()
        if data:
            delete_history_entry(data[0], data[1]); self.refresh()

    def clear_all(self):
        box = QMessageBox(self); box.setWindowTitle('Очистить историю'); box.setText('Какой период очистить?')
        hour = box.addButton('Последний час', QMessageBox.ButtonRole.ActionRole)
        day = box.addButton('Последние 24 часа', QMessageBox.ButtonRole.ActionRole)
        week = box.addButton('Неделя', QMessageBox.ButtonRole.ActionRole)
        all_btn = box.addButton('Всё время', QMessageBox.ButtonRole.DestructiveRole)
        box.addButton('Отмена', QMessageBox.ButtonRole.RejectRole); box.exec()
        clicked = box.clickedButton()
        if clicked == hour: clear_history('hour')
        elif clicked == day: clear_history('day')
        elif clicked == week: clear_history('week')
        elif clicked == all_btn: clear_history('all')
        self.refresh()

class BookmarksDialog(DailyDialog):
    def __init__(self, on_open, current=None, parent=None):
        super().__init__(parent)
        self.on_open = on_open
        self.current = current or {}
        self.setWindowTitle('Закладки NYX')
        self.resize(820, 540)
        root = QVBoxLayout(self)
        self.search = QLineEdit(); self.search.setPlaceholderText('Найти закладку или папку…'); root.addWidget(self.search)
        self.table = self._table(['Название', 'Адрес', 'Папка', 'Добавлено']); root.addWidget(self.table, 1)
        row = QHBoxLayout()
        self.add_btn = QPushButton('Добавить текущую страницу'); self.open_btn = QPushButton('Открыть')
        self.edit_btn = QPushButton('Изменить'); self.delete_btn = QPushButton('Удалить')
        self.export_btn = QPushButton('Экспорт JSON'); self.import_btn = QPushButton('Импорт JSON')
        for b in (self.add_btn, self.open_btn, self.edit_btn, self.delete_btn, self.export_btn, self.import_btn): row.addWidget(b)
        root.addLayout(row)
        self.search.textChanged.connect(self.refresh)
        self.add_btn.clicked.connect(self.add_current); self.open_btn.clicked.connect(self.open_selected)
        self.table.cellDoubleClicked.connect(lambda *_: self.open_selected())
        self.edit_btn.clicked.connect(self.edit_selected)
        self.delete_btn.clicked.connect(self.delete_selected); self.export_btn.clicked.connect(self.export_json); self.import_btn.clicked.connect(self.import_json)
        self.refresh()

    def refresh(self):
        rows = list_bookmarks(self.search.text()); self.table.setRowCount(len(rows))
        for r, item in enumerate(rows):
            vals = [item['title'], item['url'], item['folder'], format_local_time(item['created_at'])]
            for c, value in enumerate(vals):
                cell = QTableWidgetItem(str(value)); cell.setData(Qt.ItemDataRole.UserRole, item['id']); self.table.setItem(r,c,cell)

    def selected_id(self):
        row=self.table.currentRow(); return self.table.item(row,0).data(Qt.ItemDataRole.UserRole) if row>=0 else None

    def add_current(self):
        if not self.current.get('url'): return
        from PySide6.QtWidgets import QInputDialog
        folder, ok = QInputDialog.getText(self, 'Папка закладок', 'Название папки:', text='Без папки')
        if ok: add_bookmark(self.current.get('title') or self.current['url'], self.current['url'], folder.strip() or 'Без папки'); self.refresh()

    def open_selected(self):
        row=self.table.currentRow()
        if row>=0: self.on_open(self.table.item(row,1).text())

    def edit_selected(self):
        bid = self.selected_id()
        row = self.table.currentRow()
        if bid is None or row < 0:
            return
        title, ok = QInputDialog.getText(self, 'Изменить закладку', 'Название:', text=self.table.item(row, 0).text())
        if not ok:
            return
        folder, ok = QInputDialog.getText(self, 'Изменить закладку', 'Папка:', text=self.table.item(row, 2).text())
        if not ok:
            return
        try:
            update_bookmark(bid, title, folder)
            self.refresh()
        except sqlite3.IntegrityError:
            QMessageBox.warning(self, 'Закладки', 'В этой папке уже есть такая ссылка.')

    def delete_selected(self):
        bid=self.selected_id()
        if bid is not None: delete_bookmark(bid); self.refresh()

    def export_json(self):
        path,_=QFileDialog.getSaveFileName(self,'Экспорт закладок','nyx_bookmarks.json','JSON (*.json)')
        if path: Path(path).write_text(json.dumps(list_bookmarks(),ensure_ascii=False,indent=2),encoding='utf-8')

    def import_json(self):
        path,_=QFileDialog.getOpenFileName(self,'Импорт закладок','','JSON (*.json)')
        if not path:return
        try:
            values=json.loads(Path(path).read_text(encoding='utf-8'))
            if not isinstance(values,list): raise ValueError('Ожидался список закладок')
            for x in values:
                if isinstance(x,dict) and str(x.get('url','')).startswith(('http://','https://')):
                    add_bookmark(str(x.get('title') or x['url']),str(x['url']),str(x.get('folder') or 'Импорт'))
            self.refresh()
        except Exception as exc: QMessageBox.warning(self,'Импорт не выполнен',str(exc))

class DownloadsDialog(DailyDialog):
    def __init__(self, parent=None):
        super().__init__(parent); self.setWindowTitle('Загрузки NYX'); self.resize(900,520)
        root=QVBoxLayout(self); self.table=self._table(['Файл','Статус','Размер','Путь','Дата']); root.addWidget(self.table,1)
        row=QHBoxLayout(); self.open_btn=QPushButton('Открыть файл'); self.folder_btn=QPushButton('Открыть папку'); self.remove_btn=QPushButton('Убрать из списка'); close=QPushButton('Закрыть')
        for b in (self.open_btn,self.folder_btn,self.remove_btn): row.addWidget(b)
        row.addStretch(1); row.addWidget(close); root.addLayout(row)
        self.open_btn.clicked.connect(self.open_file); self.folder_btn.clicked.connect(self.open_folder); self.remove_btn.clicked.connect(self.remove); close.clicked.connect(self.reject)
        self.refresh(); self.refresh_timer=QTimer(self); self.refresh_timer.setInterval(1200); self.refresh_timer.timeout.connect(self.refresh); self.refresh_timer.start()
    def refresh(self):
        rows=list_downloads();self.table.setRowCount(len(rows))
        for r,x in enumerate(rows):
            size=f"{x['received']/1048576:.1f} / {x['total']/1048576:.1f} MB" if x['total'] else f"{x['received']/1048576:.1f} MB"
            vals=[x['filename'],x['status'],size,x['path'],format_local_time(x['created_at'])]
            for c,v in enumerate(vals):
                cell=QTableWidgetItem(str(v));cell.setData(Qt.ItemDataRole.UserRole,x['id']);self.table.setItem(r,c,cell)
    def selected(self):
        r=self.table.currentRow()
        if r<0:return None
        did=self.table.item(r,0).data(Qt.ItemDataRole.UserRole)
        return next((x for x in list_downloads() if x['id']==did),None)
    def open_file(self):
        x=self.selected()
        if x and Path(x['path']).exists(): QDesktopServices.openUrl(QUrl.fromLocalFile(x['path']))
        elif x: QMessageBox.information(self,'Загрузки','Файл пока не найден или загрузка не завершена.')
    def open_folder(self):
        x=self.selected(); path=Path(x['path']).parent if x and x['path'] else DOWNLOADS_DIR
        path.mkdir(parents=True,exist_ok=True); QDesktopServices.openUrl(QUrl.fromLocalFile(str(path)))
    def remove(self):
        x=self.selected()
        if x: delete_download(x['id']); self.refresh()

class ThemeEditorDialog(DailyDialog):
    FIELDS = [('background','Фон окна','#090811'),('panel','Панели','#141222'),('surface','Карточки','#1a172b'),('text','Текст','#f5f2ff'),('muted','Вторичный текст','#a29bb6'),('accent','Главный акцент','#a98bff'),('accent2','Второй акцент','#7654df'),('border','Границы','#302a40')]
    def __init__(self, current: dict | None=None, parent=None):
        super().__init__(parent); self.setWindowTitle('Редактор темы NYX'); self.resize(650,600)
        self.values=dict(current or {}); self.buttons={}
        root=QVBoxLayout(self); root.addWidget(QLabel('Настрой цвета, шрифт и форму элементов. Изменения сохраняются как пользовательская тема.'))
        form=QFormLayout()
        for key,label,default in self.FIELDS:
            b=QPushButton(self.values.get(key,default)); b.setStyleSheet(f'background:{self.values.get(key,default)};color:#ffffff;border:1px solid #65736a;border-radius:8px;padding:8px')
            b.clicked.connect(lambda _=False,k=key,df=default:self.pick_color(k,df));self.buttons[key]=b;form.addRow(label,b)
        root.addLayout(form)
        self.font=QFontComboBox();self.font.setCurrentFont(QFontDatabase.systemFont(QFontDatabase.SystemFont.GeneralFont));self.font.setCurrentFont(self.font.currentFont())
        if self.values.get('font_family'): self.font.setCurrentFont(QFont(self.values['font_family']))
        root.addWidget(QLabel('Шрифт'));root.addWidget(self.font)
        self.radius=QSpinBox();self.radius.setRange(0,28);self.radius.setSuffix(' px');self.radius.setValue(int(self.values.get('radius',10)))
        root.addWidget(QLabel('Скругление углов'));root.addWidget(self.radius)
        self.live=QCheckBox('Применять тему к окнам браузера и стартовой странице');self.live.setChecked(self.values.get('apply_to_home',True));root.addWidget(self.live)
        root.addStretch(1)
        io_row=QHBoxLayout(); export_btn=QPushButton('Экспорт темы'); import_btn=QPushButton('Импорт темы')
        io_row.addWidget(export_btn);io_row.addWidget(import_btn);io_row.addStretch(1);root.addLayout(io_row)
        export_btn.clicked.connect(self.export_theme);import_btn.clicked.connect(self.import_theme)
        buttons=QDialogButtonBox(QDialogButtonBox.StandardButton.Save|QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(self.accept);buttons.rejected.connect(self.reject);root.addWidget(buttons)
    def pick_color(self,key,default):
        from PySide6.QtGui import QColor
        color=QColorDialog.getColor(QColor(self.values.get(key,default)),self,'Выбрать цвет')
        if color.isValid():
            self.values[key]=color.name();self.buttons[key].setText(color.name());self.buttons[key].setStyleSheet(f'background:{color.name()};color:#ffffff;border:1px solid #65736a;border-radius:8px;padding:8px')
    def export_theme(self):
        path,_=QFileDialog.getSaveFileName(self,'Экспорт темы','NYX_Theme.json','JSON (*.json)')
        if path: Path(path).write_text(json.dumps(self.result_values(),ensure_ascii=False,indent=2),encoding='utf-8')
    def import_theme(self):
        path,_=QFileDialog.getOpenFileName(self,'Импорт темы','','JSON (*.json)')
        if not path:return
        try:
            data=json.loads(Path(path).read_text(encoding='utf-8'))
            allowed={x[0] for x in self.FIELDS}|{'font_family','radius','apply_to_home'}
            if not isinstance(data,dict) or not set(data).issubset(allowed):raise ValueError('Файл не является темой NYX.')
            self.values=data
            for key,button in self.buttons.items():
                color=data.get(key,dict((x[0],x[2]) for x in self.FIELDS).get(key))
                button.setText(color);button.setStyleSheet(f'background:{color};color:#ffffff;border:1px solid #65736a;border-radius:8px;padding:8px')
            if data.get('font_family'):self.font.setCurrentFont(QFont(data['font_family']))
            self.radius.setValue(int(data.get('radius',10)));self.live.setChecked(bool(data.get('apply_to_home',True)))
        except Exception as exc:QMessageBox.warning(self,'Импорт темы',str(exc))
    def result_values(self):
        self.values.update({'font_family':self.font.currentFont().family(),'radius':self.radius.value(),'apply_to_home':self.live.isChecked()})
        return self.values

class SitePermissionsDialog(DailyDialog):
    def __init__(self,on_forget=None,parent=None):
        super().__init__(parent);self.on_forget=on_forget;self.setWindowTitle('Разрешения сайтов');self.resize(760,480)
        root=QVBoxLayout(self);root.addWidget(QLabel('Сохранённые решения NYX для доступа к камере, микрофону, геолокации и другим возможностям.'))
        self.table=self._table(['Сайт','Возможность','Решение','Изменено']);root.addWidget(self.table,1)
        row=QHBoxLayout();self.remove_btn=QPushButton('Удалить решение');close=QPushButton('Закрыть');row.addWidget(self.remove_btn);row.addStretch(1);row.addWidget(close);root.addLayout(row)
        self.remove_btn.clicked.connect(self.remove_selected);close.clicked.connect(self.reject);self.refresh()
    def refresh(self):
        rows=list_site_permissions();self.table.setRowCount(len(rows))
        for r,x in enumerate(rows):
            vals=[x['origin'],x['feature'],'Разрешено' if x['decision']=='allow' else 'Запрещено',format_local_time(x['updated_at'])]
            for c,v in enumerate(vals):
                cell=QTableWidgetItem(str(v));cell.setData(Qt.ItemDataRole.UserRole,x['id']);self.table.setItem(r,c,cell)
    def remove_selected(self):
        r=self.table.currentRow()
        if r>=0:
            origin=self.table.item(r,0).text();feature=self.table.item(r,1).text();pid=self.table.item(r,0).data(Qt.ItemDataRole.UserRole)
            if self.on_forget:self.on_forget(origin,feature)
            delete_site_permission(pid);self.refresh()

class BackupDialog(DailyDialog):
    def __init__(self,parent=None):
        super().__init__(parent);self.setWindowTitle('Резервное копирование NYX');self.resize(560,300)
        root=QVBoxLayout(self)
        root.addWidget(QLabel('Экспорт включает настройки, историю, закладки, заметки, рабочие пространства, профильную раскладку и список загрузок. Содержимое скачанных файлов и cookies не включается.'))
        export=QPushButton('Создать резервную копию ZIP');restore=QPushButton('Восстановить из ZIP')
        root.addWidget(export);root.addWidget(restore);root.addStretch(1)
        close=QDialogButtonBox(QDialogButtonBox.StandardButton.Close);close.rejected.connect(self.reject);root.addWidget(close)
        export.clicked.connect(self.export_backup);restore.clicked.connect(self.restore_backup)
    def export_backup(self):
        path,_=QFileDialog.getSaveFileName(self,'Сохранить резервную копию','NYX_Backup.zip','ZIP (*.zip)')
        if not path:return
        try:
            APP_DIR.mkdir(parents=True,exist_ok=True)
            with tempfile.TemporaryDirectory() as td:
                db_copy=Path(td)/'nyx.db'
                src=sqlite3.connect(DB_FILE);dst=sqlite3.connect(db_copy)
                try:src.backup(dst)
                finally:dst.close();src.close()
                with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED) as z:
                    if CONFIG_FILE.exists():z.write(CONFIG_FILE,'settings.json')
                    z.write(db_copy,'nyx.db')
                    dashboard=APP_DIR/'dashboard.json'
                    if dashboard.exists():z.write(dashboard,'dashboard.json')
            QMessageBox.information(self,'Резервная копия','Архив создан успешно.')
        except Exception as exc:QMessageBox.critical(self,'Ошибка резервного копирования',str(exc))
    def restore_backup(self):
        path,_=QFileDialog.getOpenFileName(self,'Выбрать резервную копию','','ZIP (*.zip)')
        if not path:return
        answer=QMessageBox.question(self,'Восстановить данные','Текущие настройки и база данных будут заменены. Перед восстановлением текущая база сохранится в отдельной копии. Продолжить?')
        if answer!=QMessageBox.StandardButton.Yes:return
        try:
            with zipfile.ZipFile(path) as z:
                allowed={'settings.json','nyx.db','dashboard.json'}
                names=set(z.namelist())
                if not names.issubset(allowed) or 'nyx.db' not in names:raise ValueError('Архив не похож на резервную копию NYX.')
                with tempfile.TemporaryDirectory() as td:
                    temp=Path(td)
                    for name in names:
                        info=z.getinfo(name)
                        if info.file_size > 100*1024*1024:raise ValueError('Слишком большой файл в архиве.')
                        data=z.read(name)
                        if name == 'settings.json' and not isinstance(json.loads(data.decode('utf-8')), dict): raise ValueError('Файл настроек в архиве повреждён.')
                        if name == 'dashboard.json':
                            dashboard_data=json.loads(data.decode('utf-8'))
                            if not isinstance(dashboard_data,dict) or not isinstance(dashboard_data.get('items'),list): raise ValueError('Файл раскладки в архиве повреждён.')
                        (temp/name).write_bytes(data)
                    check=sqlite3.connect(temp/'nyx.db')
                    try:
                        result=check.execute('PRAGMA quick_check').fetchone()[0]
                        if result!='ok':raise ValueError('База данных резервной копии повреждена.')
                    finally:check.close()
                    APP_DIR.mkdir(parents=True,exist_ok=True)
                    if DB_FILE.exists():shutil.copy2(DB_FILE,APP_DIR/'nyx_before_restore.db')
                    shutil.copy2(temp/'nyx.db',DB_FILE)
                    if 'settings.json' in names:shutil.copy2(temp/'settings.json',CONFIG_FILE)
                    if 'dashboard.json' in names:shutil.copy2(temp/'dashboard.json',APP_DIR/'dashboard.json')
            QMessageBox.information(self,'Восстановление','Данные восстановлены. Перезапусти NYX Browser, чтобы все настройки применились.')
        except Exception as exc:QMessageBox.critical(self,'Ошибка восстановления',str(exc))
