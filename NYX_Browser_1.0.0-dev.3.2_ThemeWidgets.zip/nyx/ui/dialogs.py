from __future__ import annotations
from pathlib import Path
from io import BytesIO
import json
import re
import zipfile
import shutil

from PySide6.QtCore import Qt, QUrl
from PySide6.QtNetwork import QNetworkAccessManager, QNetworkRequest
from PySide6.QtGui import QDesktopServices, QKeySequence, QShortcut
from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QFormLayout, QLabel, QLineEdit,
    QComboBox, QCheckBox, QPushButton, QTabWidget, QSpinBox, QMessageBox,
    QSlider, QListWidget, QListWidgetItem, QFileDialog, QPlainTextEdit,
    QInputDialog, QDialogButtonBox, QWidget, QStackedWidget, QFrame, QScrollArea, QApplication
)
from PySide6.QtWebEngineCore import QWebEngineProfile

from nyx.core.storage import (
    ADDONS_DIR, APP_DIR, get_note, save_note, list_notes, save_space,
    list_spaces, delete_space, save_session, list_sessions, delete_session
)
from nyx.core.extensions import list_user_scripts
from nyx.core.crx import extract_crx_zip
from nyx.core.proxy_profiles import parse_proxy_line
from nyx.ui.daily_dialogs import ThemeEditorDialog, SitePermissionsDialog

DIALOG_STYLE = """
QDialog { background:#090811; color:#f5f2ff; }
QLabel { color:#f5f2ff; }
QLineEdit, QPlainTextEdit, QComboBox, QSpinBox, QListWidget {
 background:#141222; color:#f5f2ff; border:1px solid #302a40;
 border-radius:11px; padding:9px; selection-background-color:#a98bff;
 selection-color:#160e2b; min-height:20px;
}
QLineEdit:focus, QPlainTextEdit:focus, QComboBox:focus { border:1px solid #a98bff; }
QPushButton { background:#1a172b; color:#eee9ff; border:1px solid #302a40;
 border-radius:11px; padding:9px 15px; min-height:20px; }
QPushButton:hover { border-color:#a98bff; background:#211c31; }
QPushButton:pressed { background:#2b2242; }
QPushButton[primary="true"] { background:qlineargradient(x1:0,y1:0,x2:1,y2:1,stop:0 #a98bff,stop:1 #7654df); color:#160e2b; border-color:#a98bff; font-weight:700; }
QTabWidget::pane { border:1px solid #302a40; border-radius:11px; }
QTabBar::tab { background:#141222; padding:9px 14px; border:1px solid #302a40; }
QTabBar::tab:selected { color:#cbb9ff; background:#211c31; }
QCheckBox { spacing:9px; color:#eee9ff; padding:5px 2px; }
QCheckBox::indicator { width:18px; height:18px; border:1px solid #302a40; border-radius:5px; background:#141222; }
QCheckBox::indicator:checked { background:#a98bff; border-color:#a98bff; }
QSlider::groove:horizontal { height:6px; background:#302a40; border-radius:3px; }
QSlider::handle:horizontal { width:16px; margin:-5px 0; background:#a98bff; border-radius:8px; }
QListWidget#settingsNav { background:#0e0c18; border:1px solid #302a40; border-radius:14px; padding:7px; }
QListWidget#settingsNav::item { color:#a29bb6; padding:13px 12px; border-radius:9px; margin:2px 0; }
QListWidget#settingsNav::item:selected { color:#cbb9ff; background:#211c31; border:1px solid #a98bff; }
QFrame#settingsPage { background:#141222; border:1px solid #302a40; border-radius:15px; }
QLabel#pageTitle { color:#f5f2ff; font-size:17px; font-weight:700; }
QLabel#pageHint { color:#a29bb6; font-size:11px; }
"""

class BaseDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        app = QApplication.instance()
        theme_palette = app.property('nyxPalette') if app else None
        theme_palette = theme_palette if isinstance(theme_palette, dict) else {}
        mapping = {
            '#090811': theme_palette.get('bg', '#090811'),
            '#141222': theme_palette.get('panel', '#141222'),
            '#1a172b': theme_palette.get('surface', '#1a172b'),
            '#302a40': theme_palette.get('border', '#302a40'),
            '#a98bff': theme_palette.get('accent', '#a98bff'),
            '#7654df': theme_palette.get('accent2', '#7654df'),
            '#cbb9ff': theme_palette.get('soft', '#cbb9ff'),
            '#160e2b': theme_palette.get('ink', '#160e2b'),
            '#211c31': theme_palette.get('hover', '#211c31'),
            '#2b2242': theme_palette.get('pressed', '#2b2242'),
            '#a29bb6': theme_palette.get('muted', '#a29bb6'),
            '#b8b0c9': theme_palette.get('muted_alt', '#b8b0c9'),
            '#f5f2ff': theme_palette.get('text', '#f5f2ff'),
            '#eee9ff': theme_palette.get('text_alt', '#eee9ff'),
        }
        palette = DIALOG_STYLE
        for old, value in mapping.items(): palette = palette.replace(old, str(value))
        self.setStyleSheet(palette)

class SettingsDialog(BaseDialog):
    def __init__(self, settings: dict, profile: QWebEngineProfile | None = None, parent=None):
        super().__init__(parent)
        self.profile = profile or QWebEngineProfile.defaultProfile()
        self.setWindowTitle('Настройки NYX')
        self.resize(900, 620)
        self.setMinimumSize(780, 540)
        self.settings = dict(settings)

        outer = QVBoxLayout(self)
        outer.setContentsMargins(22, 20, 22, 18)
        outer.setSpacing(14)
        header = QVBoxLayout()
        title = QLabel('Настройки')
        title.setObjectName('pageTitle')
        subtitle = QLabel('Настрой NYX под себя. Изменения сохраняются в профиле браузера.')
        subtitle.setObjectName('pageHint')
        header.addWidget(title)
        header.addWidget(subtitle)
        outer.addLayout(header)

        body = QHBoxLayout()
        body.setSpacing(14)
        self.nav = QListWidget()
        self.nav.setObjectName('settingsNav')
        self.nav.setFixedWidth(190)
        self.stack = QStackedWidget()
        body.addWidget(self.nav)
        body.addWidget(self.stack, 1)
        outer.addLayout(body, 1)

        def add_page(name, page):
            self.nav.addItem(QListWidgetItem(name))
            scroll = QScrollArea(); scroll.setWidgetResizable(True); scroll.setFrameShape(QFrame.Shape.NoFrame)
            scroll.setWidget(page)
            self.stack.addWidget(scroll)

        # GENERAL
        general = QWidget()
        g = QVBoxLayout(general); g.setContentsMargins(22,20,22,18); g.setSpacing(14)
        g.addWidget(self._page_heading('Основные', 'Поиск, внешний вид и поведение браузера.'))
        form = QFormLayout(); form.setVerticalSpacing(14); form.setHorizontalSpacing(18)
        self.search = QComboBox(); self.search.addItems(['Google', 'DuckDuckGo', 'Bing', 'Brave Search'])
        self.search.setCurrentText(settings.get('search_engine', 'Google'))
        self.theme = QComboBox(); self.theme.addItems(['NYX Violet', 'NYX Emerald', 'NYX Crimson', 'NYX Azure', 'AMOLED Black', 'Midnight', 'Пользовательская'])
        self.theme.setCurrentText(settings.get('theme', 'NYX Violet'))
        form.addRow('Поисковая система', self.search)
        form.addRow('Тема браузера', self.theme)
        self.sidebar_side = QComboBox(); self.sidebar_side.addItems(['Слева', 'Справа'])
        self.sidebar_side.setCurrentIndex(1 if settings.get('sidebar_side') == 'right' else 0)
        form.addRow('Боковая панель', self.sidebar_side)
        g.addLayout(form)
        self.dark = QCheckBox('Принудительно затемнять сайты'); self.dark.setChecked(settings.get('dark_engine', True))
        self.adblock = QCheckBox('Блокировать известные рекламные и трекинговые домены'); self.adblock.setChecked(settings.get('adblock', True))
        self.startup = QCheckBox('Открывать главную страницу при запуске'); self.startup.setChecked(settings.get('startup_home', True))
        self.restore_session = QCheckBox('Восстанавливать все вкладки при следующем запуске')
        self.restore_session.setToolTip('Если включено, NYX сохраняет открытые вкладки и восстанавливает их после обычного закрытия или неожиданного завершения программы. Приватные окна не сохраняются.')
        self.restore_session.setChecked(bool(settings.get('restore_session_on_startup', False)))
        self.memory_saver = QCheckBox('Замораживать неактивные вкладки для экономии памяти')
        self.memory_saver.setChecked(bool(settings.get('memory_saver_enabled', False)))
        self.ui_animations = QCheckBox('Плавные анимации интерфейса')
        self.ui_animations.setChecked(bool(settings.get('ui_animations', True)))
        self.sidebar_hover_expand = QCheckBox('Раскрывать боковую панель при наведении')
        self.sidebar_hover_expand.setChecked(bool(settings.get('sidebar_hover_expand', True)))
        self.online_suggestions = QCheckBox('Показывать онлайн-подсказки поиска')
        self.online_suggestions.setChecked(bool(settings.get('online_suggestions', True)))
        self.show_status_bar = QCheckBox('Показывать строку состояния внизу')
        self.show_status_bar.setChecked(bool(settings.get('show_status_bar', True)))
        self.memory_delay = QSpinBox(); self.memory_delay.setRange(1, 240); self.memory_delay.setSuffix(' мин'); self.memory_delay.setValue(int(settings.get('memory_saver_delay_minutes', 10)))
        g.addWidget(self.dark); g.addWidget(self.adblock); g.addWidget(self.startup); g.addWidget(self.restore_session)
        restore_hint = QLabel('При следующем запуске восстановятся обычные вкладки и рабочее пространство. Инкогнито в резерв сеанса не попадает.')
        restore_hint.setWordWrap(True); restore_hint.setObjectName('pageHint')
        g.addWidget(restore_hint)
        g.addWidget(self.memory_saver)
        g.addWidget(self.ui_animations); g.addWidget(self.sidebar_hover_expand)
        g.addWidget(self.online_suggestions); g.addWidget(self.show_status_bar)
        memory_row = QHBoxLayout(); memory_row.addWidget(QLabel('Неактивность перед заморозкой')); memory_row.addWidget(self.memory_delay); memory_row.addStretch(1); g.addLayout(memory_row)
        self.theme_editor_btn = QPushButton('Открыть редактор темы…')
        self.theme_editor_btn.clicked.connect(self.open_theme_editor)
        g.addWidget(self.theme_editor_btn)
        g.addStretch(1)
        add_page('✦  Основные', general)

        # DOWNLOADS
        downloads = QWidget(); dl = QVBoxLayout(downloads); dl.setContentsMargins(22,20,22,18); dl.setSpacing(12)
        dl.addWidget(self._page_heading('Загрузки', 'Выбери папку и поведение при скачивании файлов.'))
        self.ask_download_location = QCheckBox('Каждый раз спрашивать, куда сохранить файл')
        self.ask_download_location.setChecked(bool(settings.get('ask_download_location', True)))
        self.download_dir = QLineEdit(settings.get('download_dir', str(Path.home() / 'Downloads' / 'NYX Browser')))
        browse_download = QPushButton('Обзор…')
        browse_download.clicked.connect(self.choose_download_dir)
        dl.addWidget(self.ask_download_location)
        download_row = QHBoxLayout(); download_row.addWidget(self.download_dir, 1); download_row.addWidget(browse_download); dl.addLayout(download_row)
        self.download_manager_btn = QPushButton('Открыть менеджер загрузок')
        if parent is not None and hasattr(parent, 'open_downloads'):
            self.download_manager_btn.clicked.connect(parent.open_downloads)
        dl.addWidget(self.download_manager_btn)
        dl.addStretch(1)
        add_page('↓  Загрузки', downloads)

        # PROXY
        proxy = QWidget(); pg = QVBoxLayout(proxy); pg.setContentsMargins(22,20,22,18); pg.setSpacing(12)
        pg.addWidget(self._page_heading('Proxy Switcher', 'Встроенный переключатель HTTP / SOCKS5 прокси в стиле Simple Proxy Switcher. Сохраняй несколько серверов, импортируй список и переключайся между профилями. Прокси-серверы не поставляются вместе с NYX — добавь адрес своего провайдера.'))
        pform = QFormLayout(); pform.setVerticalSpacing(12); pform.setHorizontalSpacing(18)
        self.proxy_enabled = QCheckBox('Использовать прокси'); self.proxy_enabled.setChecked(settings.get('proxy_enabled', False))
        self.proxy_type = QComboBox(); self.proxy_type.addItems(['HTTP', 'SOCKS5']); self.proxy_type.setCurrentText(settings.get('proxy_type', 'HTTP'))
        self.proxy_host = QLineEdit(settings.get('proxy_host', '')); self.proxy_host.setPlaceholderText('Например, 127.0.0.1')
        self.proxy_port = QSpinBox(); self.proxy_port.setRange(1,65535); self.proxy_port.setValue(int(settings.get('proxy_port',8080)))
        self.proxy_user = QLineEdit(settings.get('proxy_username', '')); self.proxy_user.setPlaceholderText('Необязательно')
        self.proxy_password = QLineEdit(); self.proxy_password.setEchoMode(QLineEdit.EchoMode.Password); self.proxy_password.setPlaceholderText('Пароль на время текущего запуска')
        pform.addRow(self.proxy_enabled); pform.addRow('Тип', self.proxy_type); pform.addRow('Хост / IP', self.proxy_host)
        pform.addRow('Порт', self.proxy_port); pform.addRow('Логин', self.proxy_user); pform.addRow('Пароль', self.proxy_password)
        pg.addLayout(pform)
        self.proxy_profiles = list(settings.get('proxy_profiles', []))
        self.proxy_presets = QComboBox(); self.refresh_proxy_presets(); self.proxy_presets.currentIndexChanged.connect(self.apply_proxy_preset)
        preset_row = QHBoxLayout(); import_btn = QPushButton('Импорт'); save_btn = QPushButton('Сохранить'); delete_btn = QPushButton('Удалить'); export_btn = QPushButton('Экспорт')
        preset_row.addWidget(self.proxy_presets,1); preset_row.addWidget(import_btn); preset_row.addWidget(save_btn); preset_row.addWidget(delete_btn); preset_row.addWidget(export_btn); pg.addLayout(preset_row)
        import_btn.clicked.connect(self.import_proxy_file); save_btn.clicked.connect(self.save_proxy_preset); delete_btn.clicked.connect(self.delete_proxy_preset); export_btn.clicked.connect(self.export_proxy_profiles)
        hint = QLabel('Формат импорта: http://host:port, socks5://host:port или host:port:login:password — один прокси на строку. Прокси применяется к сетевым запросам браузера; для надёжного переключения уже открытых вкладок перезапусти NYX после сохранения.')
        hint.setWordWrap(True); hint.setObjectName('pageHint'); pg.addWidget(hint); pg.addStretch(1)
        add_page('⇄  Proxy Switcher', proxy)

        # PRIVACY
        privacy = QWidget(); pv = QVBoxLayout(privacy); pv.setContentsMargins(22,20,22,18); pv.setSpacing(12)
        pv.addWidget(self._page_heading('Приватность', 'Управляй локальными данными браузера.'))
        pv.addWidget(QLabel('Удаление cookies может завершить вход на сайтах. История и сохранённые ярлыки не удаляются.'))
        self.clear_cookies_btn = QPushButton('Удалить все cookies')
        self.clear_cache_btn = QPushButton('Очистить кэш сайтов')
        self.clear_cookies_btn.clicked.connect(self.clear_cookies); self.clear_cache_btn.clicked.connect(self.clear_cache)
        pv.addWidget(self.clear_cookies_btn); pv.addWidget(self.clear_cache_btn)
        self.permissions_btn = QPushButton('Управление разрешениями сайтов…')
        self.permissions_btn.clicked.connect(self.open_site_permissions)
        pv.addWidget(self.permissions_btn); pv.addStretch(1)
        add_page('⬡  Приватность', privacy)

        self.nav.currentRowChanged.connect(self.stack.setCurrentIndex)
        self.nav.setCurrentRow(0)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel)
        buttons.button(QDialogButtonBox.StandardButton.Save).setProperty('primary', True)
        buttons.accepted.connect(self.accept); buttons.rejected.connect(self.reject)
        outer.addWidget(buttons)

    def choose_download_dir(self):
        path = QFileDialog.getExistingDirectory(self, 'Папка загрузок', self.download_dir.text())
        if path: self.download_dir.setText(path)

    def open_theme_editor(self):
        dlg = ThemeEditorDialog(self.settings.get('custom_theme', {}), self)
        if dlg.exec():
            self.settings['custom_theme'] = dlg.result_values()
            self.theme.setCurrentText('Пользовательская')

    def open_site_permissions(self):
        def forget_native(origin, feature):
            try:
                from PySide6.QtWebEngineCore import QWebEnginePermission
                if hasattr(self.profile, 'queryPermission'):
                    kind = getattr(QWebEnginePermission.PermissionType, feature, None)
                    if kind is not None:
                        permission = self.profile.queryPermission(QUrl(origin), kind)
                        if permission.isValid(): permission.reset()
            except Exception:
                pass
        SitePermissionsDialog(forget_native, self).exec()

    def _page_heading(self, title, hint):
        box = QWidget(); layout = QVBoxLayout(box); layout.setContentsMargins(0,0,0,8); layout.setSpacing(4)
        t = QLabel(title); t.setObjectName('pageTitle')
        h = QLabel(hint); h.setObjectName('pageHint')
        layout.addWidget(t); layout.addWidget(h)
        return box

    def clear_cookies(self):
        answer = QMessageBox.question(self, 'Очистить cookies?', 'Это может завершить вход на сайтах. Продолжить?')
        if answer == QMessageBox.StandardButton.Yes:
            self.profile.cookieStore().deleteAllCookies()
            QMessageBox.information(self, 'NYX', 'Команда удаления cookies отправлена.')

    def clear_cache(self):
        self.profile.clearHttpCache()
        QMessageBox.information(self, 'NYX', 'Очистка HTTP-кэша запущена.')

    def refresh_proxy_presets(self):
        self.proxy_presets.blockSignals(True); self.proxy_presets.clear()
        self.proxy_presets.addItem('Выбрать сохранённый профиль…', None)
        for profile in self.proxy_profiles:
            label = profile.get('name') or f"{profile.get('type', 'HTTP')} · {profile.get('host', '')}:{profile.get('port', '')}"
            self.proxy_presets.addItem(label, profile)
        self.proxy_presets.blockSignals(False)

    def apply_proxy_preset(self, index):
        profile = self.proxy_presets.itemData(index)
        if not isinstance(profile, dict): return
        self.proxy_enabled.setChecked(True); self.proxy_type.setCurrentText(profile.get('type', 'HTTP'))
        self.proxy_host.setText(profile.get('host', '')); self.proxy_port.setValue(int(profile.get('port', 8080)))
        self.proxy_user.setText(profile.get('username', '')); self.proxy_password.clear()

    def _current_proxy_profile(self):
        host = self.proxy_host.text().strip()
        if not host: return None
        kind = self.proxy_type.currentText(); port = self.proxy_port.value(); username = self.proxy_user.text().strip()
        return {'name': f'{kind} · {host}:{port}', 'type': kind, 'host': host, 'port': port, 'username': username}

    def save_proxy_preset(self):
        profile = self._current_proxy_profile()
        if not profile:
            QMessageBox.warning(self, 'NYX Proxy', 'Сначала укажи адрес прокси.'); return
        self.proxy_profiles = [p for p in self.proxy_profiles if not (p.get('host') == profile['host'] and int(p.get('port', 0)) == profile['port'] and p.get('type') == profile['type'])]
        self.proxy_profiles.append(profile); self.refresh_proxy_presets(); self.proxy_presets.setCurrentIndex(self.proxy_presets.count() - 1)

    def import_proxy_file(self):
        path, _ = QFileDialog.getOpenFileName(self, 'Импортировать список прокси', '', 'Text files (*.txt);;All files (*)')
        if not path: return
        added = 0
        try: lines = Path(path).read_text(encoding='utf-8-sig').splitlines()
        except (OSError, UnicodeError) as exc:
            QMessageBox.critical(self, 'NYX Proxy', f'Не удалось прочитать файл: {exc}'); return
        last_password = ''
        for raw in lines:
            parsed = parse_proxy_line(raw)
            if not parsed: continue
            profile = {k: parsed[k] for k in ('name', 'type', 'host', 'port', 'username')}
            self.proxy_profiles = [p for p in self.proxy_profiles if not (p.get('host') == profile['host'] and int(p.get('port', 0)) == profile['port'] and p.get('type') == profile['type'])]
            self.proxy_profiles.append(profile); added += 1
            last_password = parsed.get('password', '')
        self.refresh_proxy_presets()
        if added:
            self.proxy_presets.setCurrentIndex(self.proxy_presets.count() - 1)
            self.proxy_password.setText(last_password)
        QMessageBox.information(self, 'Proxy Switcher', f'Импортировано прокси: {added}. Логины сохраняются в профиле; пароль для выбранного сервера остаётся только в памяти текущего сеанса и не записывается в файл настроек.')

    def delete_proxy_preset(self):
        index = self.proxy_presets.currentIndex()
        profile = self.proxy_presets.itemData(index)
        if not isinstance(profile, dict): return
        self.proxy_profiles = [p for p in self.proxy_profiles if not (p.get('host') == profile.get('host') and int(p.get('port', 0)) == int(profile.get('port', 0)) and p.get('type') == profile.get('type'))]
        self.refresh_proxy_presets()
        self.proxy_password.clear()

    def export_proxy_profiles(self):
        if not self.proxy_profiles:
            QMessageBox.information(self, 'Proxy Switcher', 'Список профилей пуст.')
            return
        path, _ = QFileDialog.getSaveFileName(self, 'Экспорт прокси', 'nyx-proxies.txt', 'Text files (*.txt)')
        if not path: return
        lines = []
        for profile in self.proxy_profiles:
            scheme = 'socks5' if profile.get('type') == 'SOCKS5' else 'http'
            lines.append(f"{scheme}://{profile.get('host')}:{int(profile.get('port', 8080))}")
        Path(path).write_text('\n'.join(lines) + '\n', encoding='utf-8')
        QMessageBox.information(self, 'Proxy Switcher', 'Профили экспортированы. Пароли намеренно не включены в экспорт.')

    def values(self) -> dict:
        self.settings.update({'search_engine': self.search.currentText(), 'theme': self.theme.currentText(), 'sidebar_side': 'right' if self.sidebar_side.currentIndex() == 1 else 'left', 'dark_engine': self.dark.isChecked(), 'adblock': self.adblock.isChecked(), 'startup_home': self.startup.isChecked(), 'restore_session_on_startup': self.restore_session.isChecked(), 'memory_saver_enabled': self.memory_saver.isChecked(), 'memory_saver_delay_minutes': self.memory_delay.value(), 'ui_animations': self.ui_animations.isChecked(), 'sidebar_hover_expand': self.sidebar_hover_expand.isChecked(), 'online_suggestions': self.online_suggestions.isChecked(), 'show_status_bar': self.show_status_bar.isChecked(), 'ask_download_location': self.ask_download_location.isChecked(), 'download_dir': self.download_dir.text().strip(), 'proxy_enabled': self.proxy_enabled.isChecked(), 'proxy_type': self.proxy_type.currentText(), 'proxy_host': self.proxy_host.text().strip(), 'proxy_port': self.proxy_port.value(), 'proxy_username': self.proxy_user.text().strip(), 'proxy_password': self.proxy_password.text(), 'proxy_profiles': self.proxy_profiles})
        return self.settings

class DarkLabDialog(BaseDialog):
    def __init__(self, current: dict | None = None, parent=None):
        super().__init__(parent); self.setWindowTitle('NYX DARK LAB'); self.setMinimumWidth(440)
        current = current or {}
        layout = QVBoxLayout(self)
        layout.addWidget(QLabel('Настрой яркость и тон фона для текущего сайта. Изменения можно сохранить отдельно для домена.'))
        self.intensity = QSlider(Qt.Orientation.Horizontal); self.intensity.setRange(0,100); self.intensity.setValue(int(current.get('intensity',72)))
        self.label = QLabel(f"Интенсивность затемнения: {self.intensity.value()}%")
        self.intensity.valueChanged.connect(lambda v: self.label.setText(f'Интенсивность затемнения: {v}%'))
        self.images = QCheckBox('Немного приглушать изображения'); self.images.setChecked(bool(current.get('dim_images',False)))
        layout.addWidget(self.label); layout.addWidget(self.intensity); layout.addWidget(self.images)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(self.accept); buttons.rejected.connect(self.reject); layout.addWidget(buttons)
    def values(self): return {'intensity': self.intensity.value(), 'dim_images': self.images.isChecked()}

class NoteDialog(BaseDialog):
    def __init__(self, domain: str, parent=None):
        super().__init__(parent); self.domain=domain or 'new tab'; self.setWindowTitle('NYX MEMORY'); self.resize(520,380)
        layout=QVBoxLayout(self); layout.addWidget(QLabel(f'Заметка для: {self.domain}'))
        self.text=QPlainTextEdit(); self.text.setPlaceholderText('Сохрани здесь важную мысль, ссылку или напоминание по этому сайту…')
        self.text.setPlainText(get_note(self.domain)); layout.addWidget(self.text)
        buttons=QDialogButtonBox(QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(self.accept); buttons.rejected.connect(self.reject); layout.addWidget(buttons)
    def save(self): save_note(self.domain, self.text.toPlainText())

class SpacesDialog(BaseDialog):
    def __init__(self, parent=None):
        super().__init__(parent); self.setWindowTitle('NYX SPACES'); self.resize(520,400)
        layout=QVBoxLayout(self); layout.addWidget(QLabel('Рабочие пространства сохраняют набор вкладок. Выбери пространство и загрузи его.'))
        self.list=QListWidget(); layout.addWidget(self.list); self.refresh()
        row=QHBoxLayout(); self.create_btn=QPushButton('＋ Создать / сохранить'); self.load_btn=QPushButton('Открыть'); self.delete_btn=QPushButton('Удалить')
        row.addWidget(self.create_btn); row.addWidget(self.load_btn); row.addWidget(self.delete_btn); layout.addLayout(row)
        self.create_btn.clicked.connect(self.create_space); self.load_btn.clicked.connect(self.accept); self.delete_btn.clicked.connect(self.remove_space)
        buttons=QDialogButtonBox(QDialogButtonBox.StandardButton.Close); buttons.rejected.connect(self.reject); layout.addWidget(buttons)
    def refresh(self):
        self.list.clear()
        for s in list_spaces():
            item=QListWidgetItem(f"{s['name']}  ·  {len(s['urls'])} вкладок")
            item.setData(Qt.ItemDataRole.UserRole,s); self.list.addItem(item)
    def create_space(self):
        name,ok=QInputDialog.getText(self,'Новое пространство','Название:')
        if ok and name.strip():
            urls=self.parent().collect_urls() if self.parent() else []
            save_space(name.strip(),urls); self.refresh()
    def remove_space(self):
        item=self.list.currentItem()
        if item:
            data=item.data(Qt.ItemDataRole.UserRole); delete_space(data['name']); self.refresh()
    def selected_urls(self):
        item=self.list.currentItem()
        return item.data(Qt.ItemDataRole.UserRole)['urls'] if item else []

class TimeMachineDialog(BaseDialog):
    def __init__(self, parent=None):
        super().__init__(parent); self.setWindowTitle('NYX TIME MACHINE'); self.resize(570,410)
        layout=QVBoxLayout(self); layout.addWidget(QLabel('Контрольные точки браузера. Сохраняй текущие вкладки и возвращайся к ним позже.'))
        self.list=QListWidget(); layout.addWidget(self.list); self.refresh()
        row=QHBoxLayout(); self.save_btn=QPushButton('Сохранить сейчас'); self.restore_btn=QPushButton('Восстановить'); self.delete_btn=QPushButton('Удалить')
        row.addWidget(self.save_btn); row.addWidget(self.restore_btn); row.addWidget(self.delete_btn); layout.addLayout(row)
        self.save_btn.clicked.connect(self.save_now); self.restore_btn.clicked.connect(self.accept); self.delete_btn.clicked.connect(self.remove_snapshot)
        buttons=QDialogButtonBox(QDialogButtonBox.StandardButton.Close); buttons.rejected.connect(self.reject); layout.addWidget(buttons)
    def refresh(self):
        self.list.clear()
        for s in list_sessions():
            item=QListWidgetItem(f"{s['label']}  ·  {len(s['urls'])} вкладок  ·  {s['created_at'][:19].replace('T',' ')}")
            item.setData(Qt.ItemDataRole.UserRole,s); self.list.addItem(item)
    def save_now(self):
        urls=self.parent().collect_urls() if self.parent() else []
        save_session('Сессия',urls); self.refresh()
    def remove_snapshot(self):
        item=self.list.currentItem()
        if item: delete_session(item.data(Qt.ItemDataRole.UserRole)['id']); self.refresh()
    def selected_urls(self):
        item=self.list.currentItem()
        return item.data(Qt.ItemDataRole.UserRole)['urls'] if item else []

class CommandPalette(BaseDialog):
    COMMANDS = [
        ('Новая вкладка', 'new_tab'), ('История', 'history'), ('Закладки', 'bookmarks'), ('Загрузки', 'downloads'), ('Новое окно инкогнито', 'incognito'), ('Резервное копирование', 'backup'), ('Настройки', 'settings'), ('Режим чтения', 'reader'), ('Рабочие пространства', 'spaces'),
        ('Разделить экран', 'multiview'), ('Заметка для текущего сайта', 'memory'),
        ('NYX DARK LAB', 'darklab'), ('Privacy Radar', 'privacy'), ('Time Machine', 'timemachine'),
        ('Deep Focus', 'focus'), ('NYX Arcade — игры', 'games'), ('NYX Intelligence', 'intelligence'),
        ('Мини-плеер', 'float'), ('Расширения', 'extensions'), ('Мессенджер', 'messenger')
    ]
    def __init__(self,parent=None):
        super().__init__(parent); self.setWindowTitle('NYX COMMAND CENTER'); self.setFixedSize(540,470)
        layout=QVBoxLayout(self); self.query=QLineEdit(); self.query.setPlaceholderText('Найти команду…'); layout.addWidget(self.query)
        self.list=QListWidget(); layout.addWidget(self.list)
        for label,key in self.COMMANDS:
            item=QListWidgetItem(label); item.setData(Qt.ItemDataRole.UserRole,key); self.list.addItem(item)
        self.query.textChanged.connect(self.filter_items); self.query.returnPressed.connect(self.accept)
        self.list.itemDoubleClicked.connect(lambda _i:self.accept()); self.list.setCurrentRow(0)
        QShortcut(QKeySequence('Escape'),self).activated.connect(self.reject)
        self.query.setFocus()
    def filter_items(self,text):
        q=text.casefold()
        for i in range(self.list.count()):
            it=self.list.item(i); it.setHidden(q not in it.text().casefold())
        for i in range(self.list.count()):
            if not self.list.item(i).isHidden(): self.list.setCurrentRow(i); break
    def selected_command(self):
        item=self.list.currentItem(); return item.data(Qt.ItemDataRole.UserRole) if item else None

class ExtensionsDialog(BaseDialog):
    YOUBUSTA_ID = 'jddgbeighonaipjikdnfdpiefhoomlae'
    YOUBUSTA_CRX_URL = 'https://clients2.google.com/service/update2/crx?response=redirect&prodversion={version}&acceptformat=crx2,crx3&x=id%3Djddgbeighonaipjikdnfdpiefhoomlae%26uc'

    def __init__(self, enabled: list[str], profile=None, parent=None, enabled_native: list[str] | None = None):
        super().__init__(parent)
        self.setWindowTitle('Расширения NYX')
        self.resize(720, 650)
        self.enabled = set(enabled)
        self.enabled_native = set(enabled_native or [])
        self.profile = profile
        self.native_manager = None
        self.private_profile = bool(profile is not None and hasattr(profile, 'isOffTheRecord') and profile.isOffTheRecord())
        self.network = QNetworkAccessManager(self)
        self._download_reply = None
        self._expect_youbusta = False
        if profile is not None and not self.private_profile and hasattr(profile, 'extensionManager'):
            try:
                self.native_manager = profile.extensionManager()
                self.native_manager.installFinished.connect(self._native_install_finished)
                self.native_manager.uninstallFinished.connect(self._native_uninstall_finished)
            except Exception:
                self.native_manager = None

        layout = QVBoxLayout(self)
        heading = QLabel('Расширения и дополнения')
        heading.setObjectName('pageTitle')
        hint = QLabel('NYX поддерживает JavaScript-дополнения и совместимые расширения Manifest V3. Совместимость зависит от API, которые использует конкретное расширение.')
        hint.setWordWrap(True); hint.setObjectName('pageHint')
        layout.addWidget(heading); layout.addWidget(hint)

        youbusta = QFrame(); youbusta.setObjectName('settingsPage')
        y = QVBoxLayout(youbusta); y.setContentsMargins(16,14,16,14); y.setSpacing(8)
        ytitle = QLabel('YouBusta / ЮБуст')
        ytitle.setStyleSheet('font-size:15px;font-weight:800')
        ydesc = QLabel('Официальное расширение для YouTube. NYX скачает пакет непосредственно с сервера обновлений Chrome Web Store и установит его в профиль браузера.')
        ydesc.setWordWrap(True); ydesc.setObjectName('pageHint')
        y.addWidget(ytitle); y.addWidget(ydesc)
        yrow = QHBoxLayout()
        self.youbusta_btn = QPushButton('Установить YouBusta')
        self.youbusta_btn.setProperty('primary', True)
        self.youbusta_btn.clicked.connect(self.install_youbusta)
        self.store_btn = QPushButton('Официальная страница')
        self.store_btn.clicked.connect(lambda: QDesktopServices.openUrl(QUrl('https://chromewebstore.google.com/detail/jddgbeighonaipjikdnfdpiefhoomlae')))
        yrow.addWidget(self.youbusta_btn); yrow.addWidget(self.store_btn); yrow.addStretch(1)
        y.addLayout(yrow)
        if self.native_manager is None:
            self.youbusta_btn.setEnabled(False)
            ydesc.setText(ydesc.text() + ' Для установки требуется PySide6 / Qt WebEngine 6.10 или новее и постоянный профиль (не инкогнито).')
        elif self.private_profile:
            self.youbusta_btn.setEnabled(False)
            ydesc.setText(ydesc.text() + ' Установка недоступна в режиме инкогнито.')
        layout.addWidget(youbusta)

        native_label = QLabel('Расширения Chromium / Manifest V3')
        native_label.setStyleSheet('font-weight:750')
        layout.addWidget(native_label)
        self.native_list = QListWidget()
        self.native_list.setMinimumHeight(120)
        layout.addWidget(self.native_list, 1)
        self.refresh_native_extensions()
        native_row = QHBoxLayout()
        self.install_zip_btn = QPushButton('Установить из ZIP / папки')
        self.install_zip_btn.clicked.connect(self.install_native_from_file)
        self.remove_native_btn = QPushButton('Удалить выбранное')
        self.remove_native_btn.clicked.connect(self.uninstall_selected_native_extension)
        native_row.addWidget(self.install_zip_btn); native_row.addWidget(self.remove_native_btn)
        native_row.addStretch(1)
        layout.addLayout(native_row)
        if self.native_manager is None:
            self.install_zip_btn.setEnabled(False); self.remove_native_btn.setEnabled(False)
            self.native_list.addItem('Установка расширений недоступна в этом профиле. В обычном окне нужен Qt WebEngine 6.10+.') if self.private_profile else self.native_list.addItem('Нативный менеджер расширений доступен в Qt WebEngine 6.10+')

        scripts_label = QLabel('Локальные JavaScript-дополнения')
        scripts_label.setStyleSheet('font-weight:750')
        layout.addWidget(scripts_label)
        self.list = QListWidget(); layout.addWidget(self.list, 1); self.refresh()
        row = QHBoxLayout(); add = QPushButton('Добавить .js'); folder = QPushButton('Открыть папку')
        row.addWidget(add); row.addWidget(folder); row.addStretch(1); layout.addLayout(row)
        add.clicked.connect(self.add_file)
        folder.clicked.connect(lambda: __import__('os').startfile(str(ADDONS_DIR)))
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(self.accept); buttons.rejected.connect(self.reject); layout.addWidget(buttons)

    def refresh(self):
        self.list.clear()
        for name in list_user_scripts():
            it = QListWidgetItem(name); it.setFlags(it.flags() | Qt.ItemFlag.ItemIsUserCheckable)
            it.setCheckState(Qt.CheckState.Checked if name in self.enabled else Qt.CheckState.Unchecked)
            self.list.addItem(it)

    def refresh_native_extensions(self):
        self.native_list.clear()
        if self.native_manager is None: return
        try:
            for info in self.native_manager.extensions():
                if hasattr(info, 'isInstalled') and not info.isInstalled():
                    continue
                name = info.name() or 'Без названия'
                state = 'Включено' if info.isEnabled() else 'Выключено'
                item = QListWidgetItem(f'{name}  ·  {state}')
                item.setData(Qt.ItemDataRole.UserRole, info.id())
                item.setFlags(item.flags() | Qt.ItemFlag.ItemIsUserCheckable)
                item.setCheckState(Qt.CheckState.Checked if info.id() in self.enabled_native else Qt.CheckState.Unchecked)
                self.native_list.addItem(item)
        except Exception as exc:
            self.native_list.addItem(f'Не удалось прочитать список расширений: {exc}')

    def apply_native_extension_states(self):
        if self.native_manager is None: return
        selected = {}
        for i in range(self.native_list.count()):
            item = self.native_list.item(i); extension_id = item.data(Qt.ItemDataRole.UserRole)
            if extension_id: selected[extension_id] = item.checkState() == Qt.CheckState.Checked
        self.enabled_native = {extension_id for extension_id, enabled in selected.items() if enabled}
        for info in self.native_manager.extensions():
            if hasattr(info, 'isInstalled') and not info.isInstalled(): continue
            extension_id = info.id()
            should_enable = extension_id in self.enabled_native
            if info.isEnabled() != should_enable:
                self.native_manager.setExtensionEnabled(info, should_enable)

    def uninstall_selected_native_extension(self):
        if self.native_manager is None: return
        item = self.native_list.currentItem()
        extension_id = item.data(Qt.ItemDataRole.UserRole) if item else None
        if not extension_id: return
        info = next((x for x in self.native_manager.extensions() if x.id() == extension_id), None)
        if info is None: return
        if QMessageBox.question(self, 'Удалить расширение?', f'Удалить {info.name()} из профиля NYX?') != QMessageBox.StandardButton.Yes:
            return
        self.enabled_native.discard(extension_id)
        self.native_manager.uninstallExtension(info)

    def _native_uninstall_finished(self, _info):
        self.refresh_native_extensions()

    def _install_package(self, path: str):
        if self.native_manager is None:
            QMessageBox.warning(self, 'Расширения NYX', 'Для нативных расширений требуется Qt WebEngine 6.10 или новее.')
            return
        try:
            self.native_manager.installExtension(path)
            self.youbusta_btn.setEnabled(False)
            self.youbusta_btn.setText('Установка…')
        except Exception as exc:
            QMessageBox.critical(self, 'Установка расширения', str(exc))
            self.youbusta_btn.setEnabled(True); self.youbusta_btn.setText('Установить YouBusta'); self.install_zip_btn.setEnabled(True)

    def _native_install_finished(self, info):
        try:
            error = info.error()
            if error:
                QMessageBox.warning(self, 'Установка расширения', f'{info.name() or "Расширение"}: {error}')
            elif self._expect_youbusta and info.id() != self.YOUBUSTA_ID:
                self.native_manager.uninstallExtension(info)
                QMessageBox.critical(self, 'YouBusta', 'Пакет не прошёл проверку идентификатора официального расширения. Он удалён.')
            elif info.isInstalled():
                self.native_manager.setExtensionEnabled(info, True)
                self.enabled_native.add(info.id())
                QMessageBox.information(self, 'Расширения NYX', f'{info.name()} установлено и включено.')
        except Exception as exc:
            QMessageBox.warning(self, 'Расширения NYX', str(exc))
        self._expect_youbusta = False
        self.youbusta_btn.setEnabled(True); self.youbusta_btn.setText('Установить YouBusta')
        self.install_zip_btn.setEnabled(True)
        self.refresh_native_extensions()

    def install_youbusta(self):
        if self.native_manager is None: return
        if self.private_profile:
            QMessageBox.information(self, 'YouBusta', 'Расширения нельзя устанавливать в окне инкогнито.')
            return
        self._expect_youbusta = True
        self.youbusta_btn.setEnabled(False); self.install_zip_btn.setEnabled(False); self.youbusta_btn.setText('Загрузка официального пакета…')
        user_agent = self.profile.httpUserAgent() if self.profile is not None else ''
        match = re.search(r'Chrome/([0-9.]+)', user_agent)
        chrome_version = match.group(1) if match else '140.0.0.0'
        if not user_agent:
            user_agent = f'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{chrome_version} Safari/537.36'
        request = QNetworkRequest(QUrl(self.YOUBUSTA_CRX_URL.format(version=chrome_version)))
        request.setHeader(QNetworkRequest.KnownHeaders.UserAgentHeader, user_agent)
        self._download_reply = self.network.get(request)
        self._download_reply.finished.connect(self._youbusta_download_finished)

    def _youbusta_download_finished(self):
        reply = self._download_reply
        self._download_reply = None
        try:
            if reply is None or reply.error():
                message = reply.errorString() if reply is not None else 'Нет ответа от сервера.'
                if reply is not None:
                    status = reply.attribute(QNetworkRequest.Attribute.HttpStatusCodeAttribute)
                    if status is not None: message += f' (HTTP {status})'
                raise RuntimeError('Не удалось получить CRX с сервера расширений: ' + message)
            data = bytes(reply.readAll())
            payload = extract_crx_zip(data)
            with zipfile.ZipFile(BytesIO(payload)) as archive:
                manifest = json.loads(archive.read('manifest.json').decode('utf-8'))
            if manifest.get('manifest_version') != 3:
                raise RuntimeError(f"Пакет использует Manifest V{manifest.get('manifest_version')}; NYX поддерживает установку Manifest V3.")
            permissions = list(manifest.get('permissions', [])) + list(manifest.get('host_permissions', []))
            permission_text = ', '.join(str(x) for x in permissions) if permissions else 'Не запрашивает явных разрешений.'
            answer = QMessageBox.question(self, 'Разрешения YouBusta',
                f"Расширение: {manifest.get('name', 'YouBusta')}\nВерсия: {manifest.get('version', 'не указана')}\n\nЗапрашиваемые разрешения:\n{permission_text}\n\nУстановить и включить расширение?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No, QMessageBox.StandardButton.No)
            if answer != QMessageBox.StandardButton.Yes:
                self._expect_youbusta = False
                self.youbusta_btn.setEnabled(True); self.youbusta_btn.setText('Установить YouBusta'); self.install_zip_btn.setEnabled(True)
                return
            # Qt WebEngine ExtensionManager expects an unpacked extension directory,
            # not a CRX or ZIP file. Extract defensively and pass the directory.
            folder = APP_DIR / 'extensions' / 'youbusta-official'
            if folder.exists():
                shutil.rmtree(folder)
            folder.mkdir(parents=True, exist_ok=True)
            with zipfile.ZipFile(BytesIO(payload)) as archive:
                for member in archive.infolist():
                    target = (folder / member.filename).resolve()
                    if folder.resolve() not in target.parents and target != folder.resolve():
                        raise RuntimeError('Архив содержит небезопасный путь.')
                archive.extractall(folder)
            extracted_manifest = folder / 'manifest.json'
            if not extracted_manifest.is_file():
                raise RuntimeError('После распаковки не найден manifest.json в корне пакета.')
            self.youbusta_btn.setText('Передача в менеджер…')
            self._install_package(str(folder))
        except Exception as exc:
            QMessageBox.warning(self, 'YouBusta — установка', f'Не удалось установить расширение: {exc}')
            self.youbusta_btn.setEnabled(True); self.youbusta_btn.setText('Установить YouBusta'); self.install_zip_btn.setEnabled(True)
        finally:
            if reply is not None: reply.deleteLater()

    def install_native_from_file(self):
        if self.native_manager is None: return
        self._expect_youbusta = False
        path, _ = QFileDialog.getOpenFileName(self, 'Установить расширение', '', 'Extension package (*.zip)')
        if not path:
            path = QFileDialog.getExistingDirectory(self, 'Выбрать папку с manifest.json')
        if path: self._install_package(path)

    def add_file(self):
        path, _ = QFileDialog.getOpenFileName(self, 'Добавить пользовательский скрипт', '', 'JavaScript (*.js)')
        if path:
            src = Path(path); dest = ADDONS_DIR / src.name
            if dest.exists(): QMessageBox.warning(self, 'NYX', 'Файл с таким именем уже существует.'); return
            shutil.copy2(src, dest); self.refresh()

    def selected_addons(self):
        return [self.list.item(i).text() for i in range(self.list.count())
                if self.list.item(i).checkState() == Qt.CheckState.Checked]

    def selected_native_extensions(self):
        return sorted(self.enabled_native)

    def accept(self):
        self.apply_native_extension_states()
        super().accept()

class PrivacyDialog(BaseDialog):
    def __init__(self, profile: QWebEngineProfile, parent=None):
        super().__init__(parent); self.setWindowTitle('NYX PRIVACY RADAR'); self.resize(520,360)
        layout=QVBoxLayout(self)
        layout.addWidget(QLabel('Список cookies активных сайтов. Содержимое cookies не показывается. Это базовая панель контроля, а не полноценный аудит трекеров.'))
        self.list=QListWidget(); layout.addWidget(self.list); self.profile=profile
        self.profile.cookieStore().cookieAdded.connect(self.add_cookie)
        self.profile.cookieStore().loadAllCookies()
        row=QHBoxLayout(); clear=QPushButton('Удалить все cookies'); cache=QPushButton('Очистить кэш'); row.addWidget(clear); row.addWidget(cache); layout.addLayout(row)
        clear.clicked.connect(self.clear_cookies); cache.clicked.connect(self.profile.clearHttpCache)
        buttons=QDialogButtonBox(QDialogButtonBox.StandardButton.Close); buttons.rejected.connect(self.reject); layout.addWidget(buttons)
    def add_cookie(self,cookie):
        name=bytes(cookie.name()).decode('utf-8','replace')
        domain=bytes(cookie.domain()).decode('utf-8','replace')
        label=f'{domain}  ·  {name}'
        if not any(self.list.item(i).text()==label for i in range(self.list.count())): self.list.addItem(label)
    def clear_cookies(self):
        if QMessageBox.question(self,'Удалить cookies','Входы на сайтах могут быть сброшены. Продолжить?')==QMessageBox.StandardButton.Yes:
            self.profile.cookieStore().deleteAllCookies(); self.list.clear()
