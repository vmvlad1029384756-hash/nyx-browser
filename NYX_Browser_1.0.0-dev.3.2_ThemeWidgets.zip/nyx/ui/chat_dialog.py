from __future__ import annotations
import base64
import json
from urllib.parse import urljoin, urlparse

import requests
from websocket import WebSocketApp
from PySide6.QtCore import QThread, Signal, Qt
from PySide6.QtGui import QTextCursor
from PySide6.QtWidgets import (QApplication, 
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, QPushButton,
    QTextBrowser, QTextEdit, QFileDialog, QMessageBox, QComboBox
)

class ChatSocketThread(QThread):
    received = Signal(dict)
    status = Signal(str)
    def __init__(self, ws_url: str, token: str, parent=None):
        super().__init__(parent)
        self.ws_url=ws_url; self.token=token; self.ws=None
    def run(self):
        sep='&' if '?' in self.ws_url else '?'
        url=self.ws_url+sep+'token='+self.token
        self.ws=WebSocketApp(url,
            on_open=lambda _ws:self.status.emit('Подключено к NYX Messenger'),
            on_message=self._on_message,
            on_error=lambda _ws,err:self.status.emit(f'Ошибка соединения: {err}'),
            on_close=lambda *_args:self.status.emit('Соединение закрыто'))
        self.ws.run_forever(ping_interval=25,ping_timeout=10)
    def _on_message(self,_ws,message):
        try:
            data=json.loads(message)
            if isinstance(data,dict): self.received.emit(data)
        except json.JSONDecodeError: pass
    def send_json(self,data:dict):
        if self.ws:
            try: self.ws.send(json.dumps(data,ensure_ascii=False))
            except Exception as exc: self.status.emit(f'Не удалось отправить: {exc}')
    def stop(self):
        if self.ws:
            try: self.ws.close()
            except Exception: pass

class ChatDialog(QDialog):
    def __init__(self, settings:dict, parent=None):
        super().__init__(parent)
        self.settings=settings; self.token=''; self.base=''; self.worker=None
        self.setWindowTitle('NYX MESSENGER'); self.resize(760,650)
        root=QVBoxLayout(self)
        form=QHBoxLayout()
        self.server=QLineEdit(settings.get('chat_server','')); self.server.setPlaceholderText('https://your-nyx-server.example')
        self.nickname=QLineEdit(settings.get('chat_nickname','')); self.nickname.setPlaceholderText('Твой ник')
        self.room=QLineEdit(); self.room.setPlaceholderText('Код комнаты')
        self.connect_btn=QPushButton('Подключиться')
        form.addWidget(self.server,3); form.addWidget(self.nickname,1); form.addWidget(self.room,1); form.addWidget(self.connect_btn)
        root.addLayout(form)
        _p=QApplication.instance().property('nyxPalette') or {}; self.theme_palette=_p
        self.status=QLabel('Введи адрес сервера, ник и общий код комнаты.'); self.status.setStyleSheet('color:'+str(_p.get('muted','#938ba8'))); root.addWidget(self.status)
        self.chat=QTextBrowser(); self.chat.setOpenExternalLinks=True; self.chat.setStyleSheet('background:'+_p.get('panel','#100e19')+';border:1px solid '+_p.get('border','#352b4d')+';border-radius:12px;padding:10px;color:'+_p.get('text','#f2efff'))
        root.addWidget(self.chat,1)
        bottom=QHBoxLayout()
        self.emoji=QComboBox(); self.emoji.addItem('Эмодзи ▾'); self.emoji.addItems(['🙂','😂','❤️','🔥','👍','😎','🎉','🤔','😭','🚀'])
        self.input=QTextEdit(); self.input.setPlaceholderText('Написать сообщение…'); self.input.setFixedHeight(75)
        self.photo_btn=QPushButton('Фото'); self.send_btn=QPushButton('Отправить')
        bottom.addWidget(self.emoji); bottom.addWidget(self.input,1); bottom.addWidget(self.photo_btn); bottom.addWidget(self.send_btn)
        root.addLayout(bottom)
        self.connect_btn.clicked.connect(self.connect_server); self.send_btn.clicked.connect(self.send_text); self.photo_btn.clicked.connect(self.send_photo)
        self.emoji.currentIndexChanged.connect(self.insert_emoji)
        self.input.setEnabled(False); self.photo_btn.setEnabled(False); self.send_btn.setEnabled(False)

    def insert_emoji(self, index):
        if index <= 0:
            return
        cursor = self.input.textCursor()
        cursor.insertText(self.emoji.itemText(index))
        self.input.setTextCursor(cursor)
        self.emoji.blockSignals(True)
        self.emoji.setCurrentIndex(0)
        self.emoji.blockSignals(False)

    def _request(self,method,path,**kwargs):
        return requests.request(method,urljoin(self.base+'/',path.lstrip('/')),timeout=12,**kwargs)

    def connect_server(self):
        base=self.server.text().strip().rstrip('/')
        nick=self.nickname.text().strip(); room=self.room.text().strip()
        if not base or not nick or not room:
            QMessageBox.warning(self,'NYX Messenger','Заполни адрес сервера, ник и код комнаты.'); return
        parsed=urlparse(base)
        if parsed.scheme not in ('http','https') or not parsed.netloc:
            QMessageBox.warning(self,'NYX Messenger','Адрес должен начинаться с http:// или https://'); return
        self.base=base
        try:
            response=self._request('POST','/api/join',json={'nickname':nick,'room_code':room})
            response.raise_for_status(); self.token=response.json()['token']
            history=self._request('GET','/api/history',params={'token':self.token}); history.raise_for_status()
        except Exception as exc:
            QMessageBox.critical(self,'Не удалось подключиться',f'{exc}\nПроверь сервер и код комнаты.'); return
        self.chat.clear()
        for message in history.json().get('messages',[]): self.render_message(message)
        ws_base=base.replace('https://','wss://').replace('http://','ws://')+'/ws'
        self.worker=ChatSocketThread(ws_base,self.token,self)
        self.worker.received.connect(self.render_message); self.worker.status.connect(self.status.setText); self.worker.start()
        self.input.setEnabled(True); self.photo_btn.setEnabled(True); self.send_btn.setEnabled(True); self.connect_btn.setEnabled(False)
        self.settings['chat_server']=base; self.settings['chat_nickname']=nick

    def render_message(self,data):
        nick=str(data.get('nickname','?'))[:40]
        text=str(data.get('text',''))[:4000]
        when=str(data.get('created_at',''))[:19].replace('T',' ')
        safe_nick=nick.replace('&','&amp;').replace('<','&lt;').replace('>','&gt;')
        safe_text=text.replace('&','&amp;').replace('<','&lt;').replace('>','&gt;').replace('\n','<br>')
        p=self.theme_palette
        html=f'<div style="margin:8px 0;padding:9px 12px;background:{p.get("surface","#1a1627")};border:1px solid {p.get("border","#352b4d")};border-radius:10px"><b style="color:{p.get("accent","#a78bfa")}">{safe_nick}</b> <small style="color:{p.get("muted","#938ba8")}">{when}</small><div style="margin-top:5px">{safe_text}</div>'
        image_url=data.get('image_url')
        if image_url:
            full=urljoin(self.base+'/',str(image_url).lstrip('/'))
            try:
                r=requests.get(full,timeout=8); r.raise_for_status()
                mime=r.headers.get('Content-Type','image/jpeg').split(';')[0]
                encoded=base64.b64encode(r.content).decode('ascii')
                html+=f'<div><img src="data:{mime};base64,{encoded}" style="max-width:260px;max-height:220px;border-radius:8px;margin-top:8px"></div>'
            except Exception:
                html+=f'<div><a href="{full}">Открыть фотографию</a></div>'
        html+='</div>'
        self.chat.append(html)
        self.chat.moveCursor(QTextCursor.MoveOperation.End)

    def send_text(self):
        text=self.input.toPlainText().strip()
        if not text or not self.worker: return
        self.worker.send_json({'type':'text','text':text}); self.input.clear()

    def send_photo(self):
        if not self.worker or not self.token: return
        path,_=QFileDialog.getOpenFileName(self,'Выбрать фотографию','','Images (*.png *.jpg *.jpeg *.gif *.webp)')
        if not path: return
        try:
            with open(path,'rb') as f: response=self._request('POST','/api/upload',headers={'Authorization':'Bearer '+self.token},files={'file':(path.split('/')[-1],f)})
            response.raise_for_status(); payload=response.json()
            self.worker.send_json({'type':'image','image_url':payload['url'],'text':'','image_name':payload.get('name','Фото')})
        except Exception as exc:
            QMessageBox.critical(self,'Ошибка отправки фото',str(exc))

    def closeEvent(self,event):
        if self.worker:
            self.worker.stop(); self.worker.wait(1500)
        super().closeEvent(event)
