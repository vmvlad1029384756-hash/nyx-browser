from __future__ import annotations
from PySide6.QtWidgets import (QDialog,QVBoxLayout,QHBoxLayout,QTableWidget,QTableWidgetItem,
    QPushButton,QInputDialog,QMessageBox,QLabel,QHeaderView,QLineEdit)
from nyx.core.password_vault import list_credentials, save_credential, delete_credential
from nyx.ui.dialogs import BaseDialog

class PasswordDialog(BaseDialog):
    def __init__(self, current_url: str = '', current_title: str = '', parent=None):
        super().__init__(parent); self.setWindowTitle('NYX · Менеджер паролей'); self.resize(680,430)
        self.current_url=current_url; self.current_title=current_title
        layout=QVBoxLayout(self)
        layout.addWidget(QLabel('Пароли хранятся в системном хранилище учётных данных Windows.'))
        self.table=QTableWidget(0,3); self.table.setHorizontalHeaderLabels(['Сайт','Логин','Изменён'])
        self.table.horizontalHeader().setSectionResizeMode(0,QHeaderView.ResizeMode.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(1,QHeaderView.ResizeMode.Stretch)
        self.table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        layout.addWidget(self.table)
        row=QHBoxLayout(); add=QPushButton('＋ Сохранить логин'); remove=QPushButton('Удалить'); close=QPushButton('Закрыть')
        add.clicked.connect(self.add_entry); remove.clicked.connect(self.remove_entry); close.clicked.connect(self.accept)
        row.addWidget(add); row.addWidget(remove); row.addStretch(1); row.addWidget(close); layout.addLayout(row)
        self.refresh()
    def refresh(self):
        rows=list_credentials(); self.table.setRowCount(len(rows))
        for i,r in enumerate(rows):
            for j,k in enumerate(('origin','username','updated_at')): self.table.setItem(i,j,QTableWidgetItem(r[k]))
    def add_entry(self):
        url=self.current_url
        if not url.startswith(('http://','https://')):
            url,ok=QInputDialog.getText(self,'Новый пароль','Адрес сайта (https://...)')
            if not ok:return
        username,ok=QInputDialog.getText(self,'Новый пароль','Логин / почта')
        if not ok or not username:return
        password,ok=QInputDialog.getText(self,'Новый пароль','Пароль',echo=QLineEdit.EchoMode.Password)
        if not ok or not password:return
        try: save_credential(url,username,password,self.current_title)
        except Exception as e: QMessageBox.critical(self,'Хранилище паролей',f'Не удалось сохранить пароль: {e}'); return
        self.refresh()
    def remove_entry(self):
        row=self.table.currentRow()
        if row<0:return
        origin=self.table.item(row,0).text(); username=self.table.item(row,1).text()
        if QMessageBox.question(self,'Удалить пароль',f'Удалить сохранённые данные для {origin}?')==QMessageBox.StandardButton.Yes:
            try: delete_credential(origin,username)
            except Exception as e: QMessageBox.warning(self,'Ошибка',str(e))
            self.refresh()
