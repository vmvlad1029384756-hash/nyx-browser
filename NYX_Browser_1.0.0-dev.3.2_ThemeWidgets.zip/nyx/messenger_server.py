"""Small private-room NYX Messenger server.

Run behind HTTPS/WSS in production. This starter server is not end-to-end encrypted.
"""
from __future__ import annotations
import base64, hashlib, hmac, json, os, re, sqlite3, time, uuid
from pathlib import Path
from typing import Any
from fastapi import FastAPI, HTTPException, WebSocket, WebSocketDisconnect, Header, UploadFile, File
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field

ROOT=Path(os.environ.get('NYX_MESSENGER_DATA','./nyx_messenger_data')).resolve(); ROOT.mkdir(parents=True,exist_ok=True)
MEDIA=ROOT/'media'; MEDIA.mkdir(exist_ok=True)
DB=ROOT/'messages.sqlite3'
ROOM_CODE=os.environ.get('NYX_ROOM_CODE','change-this-room-code')
SECRET=os.environ.get('NYX_SECRET','change-this-secret-before-public-use').encode('utf-8')
app=FastAPI(title='NYX Messenger Server',version='0.2.0')
rooms:dict[str,set[WebSocket]]={}

class JoinRequest(BaseModel):
    nickname:str=Field(min_length=1,max_length=32)
    room_code:str=Field(min_length=4,max_length=128)

def db():
    con=sqlite3.connect(DB); con.row_factory=sqlite3.Row; return con

def init_db():
    with db() as con:
        con.execute('''CREATE TABLE IF NOT EXISTS messages(id INTEGER PRIMARY KEY AUTOINCREMENT, room TEXT NOT NULL, nickname TEXT NOT NULL, text TEXT NOT NULL, image_url TEXT, created_at TEXT NOT NULL)''')

def token_make(nickname:str)->str:
    payload={'nickname':nickname,'room':'friends','exp':int(time.time())+60*60*24*14}
    raw=base64.urlsafe_b64encode(json.dumps(payload,separators=(',',':')).encode()).decode().rstrip('=')
    sig=hmac.new(SECRET,raw.encode(),hashlib.sha256).hexdigest()
    return raw+'.'+sig

def token_read(token:str)->dict[str,Any]:
    try:
        raw,sig=token.rsplit('.',1)
        good=hmac.compare_digest(sig,hmac.new(SECRET,raw.encode(),hashlib.sha256).hexdigest())
        payload=json.loads(base64.urlsafe_b64decode(raw+'='*((4-len(raw)%4)%4)))
        if not good or int(payload.get('exp',0))<time.time(): raise ValueError('token expired')
        return payload
    except Exception as exc: raise HTTPException(status_code=401,detail='Invalid or expired token') from exc

def bearer(header:str|None)->dict[str,Any]:
    if not header or not header.lower().startswith('bearer '): raise HTTPException(status_code=401,detail='Bearer token required')
    return token_read(header.split(' ',1)[1])

@app.on_event('startup')
def startup():
    init_db()
    if ROOM_CODE=='change-this-room-code' or SECRET==b'change-this-secret-before-public-use':
        print('WARNING: Set NYX_ROOM_CODE and NYX_SECRET before exposing this server to the internet.')

@app.post('/api/join')
def join(data:JoinRequest):
    if not hmac.compare_digest(data.room_code,ROOM_CODE): raise HTTPException(status_code=403,detail='Wrong room code')
    nick=re.sub(r'[^\w .-]','',data.nickname).strip()[:32] or 'Guest'
    return {'token':token_make(nick),'nickname':nick}

@app.get('/api/history')
def history(token:str):
    claims=token_read(token)
    with db() as con:
        rows=con.execute('SELECT nickname,text,image_url,created_at FROM messages WHERE room=? ORDER BY id DESC LIMIT 80',(claims['room'],)).fetchall()
    return {'messages':[dict(r) for r in reversed(rows)]}

@app.post('/api/upload')
async def upload(file:UploadFile=File(...),authorization:str|None=Header(default=None)):
    bearer(authorization)
    data=await file.read(5*1024*1024+1)
    if len(data)>5*1024*1024: raise HTTPException(status_code=413,detail='Image too large (5 MB max)')
    signatures=[(b'\x89PNG\r\n\x1a\n','.png'),(b'\xff\xd8\xff','.jpg'),(b'GIF8','.gif'),(b'RIFF','.webp')]
    ext=None
    for sig,suffix in signatures:
        if data.startswith(sig): ext=suffix; break
    if ext is None: raise HTTPException(status_code=415,detail='Only PNG, JPG, GIF and WEBP images are accepted')
    name=uuid.uuid4().hex+ext
    (MEDIA/name).write_bytes(data)
    return {'url':'/media/'+name,'name':file.filename or name}

@app.get('/media/{filename}')
def media(filename:str):
    if Path(filename).name!=filename or not re.fullmatch(r'[0-9a-f]{32}\.(png|jpg|gif|webp)',filename): raise HTTPException(status_code=404)
    path=MEDIA/filename
    if not path.exists(): raise HTTPException(status_code=404)
    return FileResponse(path)

@app.websocket('/ws')
async def websocket_endpoint(ws:WebSocket,token:str):
    try: claims=token_read(token)
    except HTTPException:
        await ws.close(code=1008); return
    room=claims['room']; nick=claims['nickname']
    await ws.accept(); rooms.setdefault(room,set()).add(ws)
    try:
        while True:
            data=await ws.receive_json()
            kind=data.get('type')
            text=str(data.get('text','')).strip()[:4000]
            image_url=data.get('image_url') if kind=='image' else None
            if kind not in ('text','image') or (kind=='text' and not text): continue
            if image_url and not (isinstance(image_url,str) and image_url.startswith('/media/')): continue
            from datetime import datetime,timezone
            created=datetime.now(timezone.utc).isoformat(timespec='seconds')
            payload={'nickname':nick,'text':text,'image_url':image_url,'created_at':created}
            with db() as con:
                con.execute('INSERT INTO messages(room,nickname,text,image_url,created_at) VALUES(?,?,?,?,?)',(room,nick,text,image_url,created))
            dead=[]
            for peer in list(rooms.get(room,set())):
                try: await peer.send_json(payload)
                except Exception: dead.append(peer)
            for peer in dead: rooms.get(room,set()).discard(peer)
    except WebSocketDisconnect:
        pass
    finally:
        rooms.get(room,set()).discard(ws)
