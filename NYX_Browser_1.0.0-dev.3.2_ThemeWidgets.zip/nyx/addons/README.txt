NYX ADD-ONS (lightweight user scripts)

Put trusted .js files in this folder, then open NYX > Extensions and enable them.
These are injected user scripts, not Google Chrome extensions. They do not support
Chrome Manifest V2/V3 APIs, chrome.storage, chrome.tabs, service workers or the
Chrome Web Store package format.

Optional userscript header example:
// ==UserScript==
// @name My NYX tweak
// @match https://example.com/*
// @run-at document-end
// ==/UserScript==

Do not install scripts from unknown sources: enabled scripts can read and modify
pages where they run.
