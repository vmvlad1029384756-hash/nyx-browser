// ==UserScript==
// @name NYX Example — title marker
// @match https://example.com/*
// @exclude https://example.com/private/*
// ==/UserScript==
(() => {
  document.title = 'NYX · ' + document.title;
})();
