from __future__ import annotations

import json
from PySide6.QtWebEngineCore import QWebEngineScript

DEFAULT_PALETTE = {
    "accent": "#a98bff", "ink": "#160e2b", "background": "#090811",
    "text": "#f5f2ff", "soft": "#cbb9ff",
}

def _build_script(palette: dict | None = None) -> str:
    colors = dict(DEFAULT_PALETTE)
    if isinstance(palette, dict):
        for key in colors:
            value = palette.get(key)
            if isinstance(value, str) and len(value) == 7 and value.startswith("#"):
                try:
                    int(value[1:], 16)
                    colors[key] = value
                except ValueError:
                    pass
    encoded = json.dumps(colors, ensure_ascii=True)
    return r'''(() => {
      const palette = __PALETTE__;
      const id = 'nyx-dark-engine-style';
      let style = document.getElementById(id);
      if (!style) { style = document.createElement('style'); style.id = id; (document.head || document.documentElement).appendChild(style); }
      const css = `
        html { color-scheme: dark !important; }
        input, textarea, select, button { color-scheme: dark !important; }
        ::selection, *::selection, input::selection, textarea::selection, [contenteditable="true"]::selection {
          background: ${palette.accent} !important; color: ${palette.ink} !important;
        }
        a:not([role="button"]):not(.button):not(button) { color: ${palette.accent} !important; }
        :focus-visible { outline-color: ${palette.accent} !important; }
      `;
      style.textContent = css;
      document.documentElement.style.setProperty('--nyx-accent', palette.accent);
      document.documentElement.style.setProperty('--nyx-accent-contrast', palette.ink);
      window.__NYX_APPLY_ACCENT__ = next => {
        if (!next || !/^#[0-9a-f]{6}$/i.test(next.accent || '')) return;
        palette.accent = next.accent; palette.ink = next.ink || palette.ink;
        style.textContent = `html{color-scheme:dark!important}input,textarea,select,button{color-scheme:dark!important}::selection,*::selection,input::selection,textarea::selection,[contenteditable="true"]::selection{background:${palette.accent}!important;color:${palette.ink}!important}a:not([role="button"]):not(.button):not(button){color:${palette.accent}!important}:focus-visible{outline-color:${palette.accent}!important}`;
        document.documentElement.style.setProperty('--nyx-accent', palette.accent);
      };
      const ignored = new Set(['IMG','VIDEO','CANVAS','SVG','PATH','IFRAME']);
      const processed = new WeakSet();
      function luminanceFromRgb(rgb) {
        const m = rgb.match(/[0-9.]+/g); if (!m || m.length < 3) return 0;
        const c = m.slice(0,3).map(Number).map(v => { v /= 255; return v <= 0.04045 ? v/12.92 : Math.pow((v+0.055)/1.055,2.4); });
        return 0.2126*c[0] + 0.7152*c[1] + 0.0722*c[2];
      }
      function processElement(el) {
        if (!(el instanceof HTMLElement) || ignored.has(el.tagName) || processed.has(el)) return;
        processed.add(el); const cs = getComputedStyle(el); const bg = cs.backgroundColor;
        if (bg && bg !== 'rgba(0, 0, 0, 0)' && bg !== 'transparent' && luminanceFromRgb(bg) > 0.72) el.style.setProperty('background-color', '#171920', 'important');
        const color = cs.color; if (color && luminanceFromRgb(color) < 0.18) el.style.setProperty('color', '#e7e9ee', 'important');
      }
      function scan(root) { if (root instanceof HTMLElement) processElement(root); if (root && root.querySelectorAll) root.querySelectorAll('*').forEach(processElement); }
      const start = () => {
        scan(document.documentElement);
        const observer = new MutationObserver(records => records.forEach(record => record.addedNodes.forEach(node => { if (node.nodeType === Node.ELEMENT_NODE) scan(node); })));
        observer.observe(document.documentElement, { childList: true, subtree: true });
      };
      if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start, { once: true }); else start();
    })();''' .replace('__PALETTE__', encoded)

def install_dark_engine(profile, palette: dict | None = None):
    scripts = profile.scripts()
    script = QWebEngineScript()
    script.setName("NYX Dark Engine")
    script.setInjectionPoint(QWebEngineScript.InjectionPoint.DocumentReady)
    script.setWorldId(QWebEngineScript.ScriptWorldId.MainWorld)
    script.setRunsOnSubFrames(False)
    script.setSourceCode(_build_script(palette))
    scripts.insert(script)
