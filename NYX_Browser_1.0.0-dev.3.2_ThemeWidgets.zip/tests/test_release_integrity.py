from pathlib import Path
import ast
import json
import unittest

ROOT = Path(__file__).resolve().parents[1]

class ReleaseIntegrityTests(unittest.TestCase):
    def test_all_python_sources_parse(self):
        for path in (ROOT / 'nyx').rglob('*.py'):
            ast.parse(path.read_text(encoding='utf-8'), filename=str(path))

    def test_manifest_is_valid_json(self):
        json.loads((ROOT / 'mobile-pwa' / 'manifest.webmanifest').read_text(encoding='utf-8'))

    def test_default_profile_path_is_unchanged(self):
        storage = (ROOT / 'nyx' / 'core' / 'storage.py').read_text(encoding='utf-8')
        self.assertIn("'NYX Browser'", storage)
        self.assertIn('LOCALAPPDATA', storage)

    def test_default_theme_is_violet_and_sidebar_is_configurable(self):
        storage = (ROOT / 'nyx' / 'core' / 'storage.py').read_text(encoding='utf-8')
        self.assertIn("'theme': 'NYX Violet'", storage)
        self.assertIn("'sidebar_side': 'left'", storage)

    def test_upgrade_snapshot_is_one_time_and_sqlite_consistent(self):
        import os
        import subprocess
        import sys
        import tempfile
        code = r'''from pathlib import Path
from nyx.core.storage import APP_DIR, save_settings, init_db, add_bookmark, list_bookmarks
from nyx.core.migrations import create_pre_v1_snapshot
save_settings({'theme': 'Premium Green', 'keep': 'yes'})
init_db()
add_bookmark('Test', 'https://example.test')
backup = create_pre_v1_snapshot()
assert backup and (backup / 'settings.json').exists() and (backup / 'nyx.db').exists()
assert create_pre_v1_snapshot() is None
assert list_bookmarks()[0]['url'] == 'https://example.test'
'''
        with tempfile.TemporaryDirectory() as temp:
            env = dict(os.environ, LOCALAPPDATA=temp, PYTHONPATH=str(ROOT))
            result = subprocess.run([sys.executable, '-c', code], env=env, capture_output=True, text=True)
            self.assertEqual(result.returncode, 0, result.stderr)

    def test_duplicate_ai_tab_regression_fixed(self):
        source = (ROOT / 'nyx' / 'ui' / 'main_window.py').read_text(encoding='utf-8')
        body = source.split('    def open_ai_mode(self):', 1)[1].split('    def open_games(self):', 1)[0]
        self.assertEqual(body.count('self.new_tab('), 1)


    def test_new_tab_theme_uses_violet_tokens_and_preserves_content_selection(self):
        home = (ROOT / 'nyx' / 'pages' / 'home.html').read_text(encoding='utf-8')
        self.assertIn('--green:var(--accent)', home)
        self.assertIn('--bg:#090811', home)
        self.assertIn('--accent2:#7654df', home)
        self.assertIn('color-mix(in srgb,var(--green)', home)
        self.assertNotIn('*{box-sizing:border-box;user-select:none', home)

    def test_theme_accent_is_not_hard_coded_green_on_websites_or_dark_lab(self):
        engine = (ROOT / 'nyx' / 'engine' / 'dark_engine.py').read_text(encoding='utf-8')
        window = (ROOT / 'nyx' / 'ui' / 'main_window.py').read_text(encoding='utf-8')
        self.assertNotIn('#65e6a0', engine)
        dark_lab = window.split('    def apply_dark_override(self,view):', 1)[1].split('    def open_privacy', 1)[0]
        self.assertNotIn('#65e6a0', dark_lab)
        self.assertIn('${palette.accent}', engine)
        self.assertIn('apply_theme_accent_to_view', window)
        self.assertIn('self.refresh_addons()', window.split('    def apply_theme(self):', 1)[1].split('    def apply_theme_accent_to_view', 1)[0])

    def test_new_productivity_widgets_are_registered_and_implemented(self):
        home = (ROOT / 'nyx' / 'pages' / 'home.html').read_text(encoding='utf-8')
        for widget in ('pomodoro', 'budget', 'percent'):
            self.assertIn("['" + widget + "'", home)
            self.assertIn("item.type==='" + widget + "'", home)

    def test_address_toolbar_has_only_downloads_and_extensions_actions(self):
        source = (ROOT / 'nyx' / 'ui' / 'main_window.py').read_text(encoding='utf-8')
        self.assertIn("self.downloads_btn=self._button('↓'", source)
        self.assertIn("self.extensions_btn=self._button('◈'", source)
        self.assertIn("setObjectName('toolbarActionButton')", source)
        self.assertNotIn("self.history_btn=self._button('◷'", source)
        self.assertNotIn("self.password_btn=self._button('🔐'", source)

    def test_youbusta_native_extension_installer_is_present(self):
        source = (ROOT / 'nyx' / 'ui' / 'dialogs.py').read_text(encoding='utf-8')
        requirements = (ROOT / 'requirements.txt').read_text(encoding='utf-8')
        self.assertIn('jddgbeighonaipjikdnfdpiefhoomlae', source)
        self.assertIn('extensionManager()', source)
        self.assertIn('PySide6>=6.10', requirements)

    def test_crx3_payload_is_validated(self):
        import io
        import zipfile
        from nyx.core.crx import extract_crx_zip
        buffer = io.BytesIO()
        with zipfile.ZipFile(buffer, 'w') as archive:
            archive.writestr('manifest.json', '{"manifest_version":3,"name":"Test"}')
        payload = buffer.getvalue()
        crx = b'Cr24' + (3).to_bytes(4, 'little') + (0).to_bytes(4, 'little') + payload
        self.assertEqual(extract_crx_zip(crx), payload)
        crx2 = b'Cr24' + (2).to_bytes(4, 'little') + (3).to_bytes(4, 'little') + (4).to_bytes(4, 'little') + b'key' + b'sign' + payload
        self.assertEqual(extract_crx_zip(crx2), payload)
        with self.assertRaises(ValueError):
            extract_crx_zip(b'not-a-crx')


    def test_proxy_switcher_import_formats(self):
        from nyx.core.proxy_profiles import parse_proxy_line
        plain = parse_proxy_line('127.0.0.1:8080')
        auth = parse_proxy_line('127.0.0.1:8080:demo:secret')
        url_auth = parse_proxy_line('socks5://demo:secret@proxy.example:1080')
        self.assertEqual((plain['host'], plain['port'], plain['type']), ('127.0.0.1', 8080, 'HTTP'))
        self.assertEqual((auth['username'], auth['password']), ('demo', 'secret'))
        self.assertEqual((url_auth['host'], url_auth['port'], url_auth['type']), ('proxy.example', 1080, 'SOCKS5'))
        self.assertIsNone(parse_proxy_line('# comment'))
        self.assertIsNone(parse_proxy_line('not a proxy'))


    def test_custom_theme_only_overrides_when_custom_theme_selected(self):
        source = (ROOT / 'nyx' / 'ui' / 'main_window.py').read_text(encoding='utf-8')
        self.assertIn("if theme != 'Пользовательская': custom = {}", source)
        self.assertIn("theme == 'Пользовательская' and custom.get('apply_to_home', True)", source)


    def test_arcade_uses_live_theme_tokens(self):
        games = (ROOT / 'nyx' / 'pages' / 'games.html').read_text(encoding='utf-8')
        self.assertIn('--bg:#090811', games)
        self.assertIn('window.applyNyxTheme=function()', games)
        self.assertIn('getAccent()', games)
        self.assertNotIn("'#65e6a0'", games)

    def test_youbusta_passes_unpacked_directory_to_qt_extension_manager(self):
        source = (ROOT / "nyx" / "ui" / "dialogs.py").read_text(encoding="utf-8")
        self.assertIn("archive.extractall(folder)", source)
        self.assertIn("self._install_package(str(folder))", source)
        self.assertNotIn("self._install_package(str(package))", source)

    def test_incognito_has_visible_toolbar_entry_and_window_shortcut(self):
        source = (ROOT / "nyx" / "ui" / "main_window.py").read_text(encoding="utf-8")
        self.assertIn("self.incognito_btn=self._button", source)
        self.assertIn("('Ctrl+Shift+N',self.open_incognito_window)", source)

    def test_shortcuts_are_real_links_and_mobile_pwa_does_not_disable_touch(self):
        home = (ROOT / "nyx" / "pages" / "home.html").read_text(encoding="utf-8")
        mobile = (ROOT / "mobile-pwa" / "index.html").read_text(encoding="utf-8")
        self.assertIn("document.createElement('a');main.className='shortcut-main'", home)
        self.assertIn("document.createElement('a');main.className='shortcut-main'", mobile)
        self.assertIn("(pointer:coarse)", mobile)

if __name__ == '__main__':
    unittest.main()
