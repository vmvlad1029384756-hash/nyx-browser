# PyInstaller build recipe for NYX Browser 1.0 (Windows x64).
from pathlib import Path
from PyInstaller.utils.hooks import collect_all, collect_submodules

ROOT = Path(SPECPATH)
datas = []
binaries = []
hiddenimports = []

for package in (
    'keyring',
    'requests',
    'websocket',
):
    pkg_datas, pkg_binaries, pkg_hidden = collect_all(package)
    datas += pkg_datas
    binaries += pkg_binaries
    hiddenimports += pkg_hidden

hiddenimports += collect_submodules('keyring.backends')
hiddenimports += ['PySide6.QtWebEngineCore', 'PySide6.QtWebEngineWidgets', 'PySide6.QtWebChannel']
datas += [
    (str(ROOT / 'nyx' / 'pages'), 'nyx/pages'),
    (str(ROOT / 'nyx' / 'addons'), 'nyx/addons'),
    (str(ROOT / 'nyx' / 'assets'), 'nyx/assets'),
    (str(ROOT / 'VERSION.txt'), '.'),
]

a = Analysis(
    [str(ROOT / 'nyx' / '__main__.py')],
    pathex=[str(ROOT)],
    binaries=binaries,
    datas=datas,
    hiddenimports=hiddenimports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=['tkinter', 'matplotlib', 'numpy', 'pandas'],
    noarchive=False,
    optimize=1,
)
pyz = PYZ(a.pure)
exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name='NYX Browser',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=False,
    console=False,
    icon=str(ROOT / 'nyx' / 'assets' / 'nyx.ico'),
    disable_windowed_traceback=False,
    argv_emulation=False,
    codesign_identity=None,
    entitlements_file=None,
)
coll = COLLECT(
    exe,
    a.binaries,
    a.datas,
    strip=False,
    upx=False,
    upx_exclude=[],
    name='NYX Browser',
)
