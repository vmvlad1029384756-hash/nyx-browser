@echo off
setlocal EnableExtensions
cd /d "%~dp0"
if not "%CD%"=="%~dp0" echo [NYX] Working folder: "%CD%"
set "NYX_PY=3.13"
set "BASE_PY="
set "VENV_PY=%CD%\.venv\Scripts\python.exe"

echo [NYX 1.0] Checking Python %NYX_PY% x64...
call :resolve_python
if defined BASE_PY goto :python_ready

echo [NYX] Python %NYX_PY% x64 is not available. Installing it with Python Install Manager...
py install %NYX_PY%
if errorlevel 1 goto :python_install_failed
call :resolve_python
if not defined BASE_PY goto :python_install_failed

:python_ready
echo [NYX] Python runtime: "%BASE_PY%"
"%BASE_PY%" -c "import sys, struct; assert sys.version_info[:2] == (3,13) and struct.calcsize('P') == 8, (sys.version, struct.calcsize('P')*8)"
if errorlevel 1 goto :python_install_failed

echo [NYX] Python %NYX_PY% x64 is ready.
if exist "%VENV_PY%" goto :check_venv
if exist ".venv" (
  echo [NYX] Removing an incomplete virtual environment...
  rmdir /s /q ".venv"
)
goto :create_venv

:check_venv
"%VENV_PY%" -c "import sys, struct; assert sys.version_info[:2] == (3,13) and struct.calcsize('P') == 8" >nul 2>&1
if not errorlevel 1 goto :venv_ready
echo [NYX] Existing .venv uses another Python version. Recreating it...
rmdir /s /q ".venv"

:create_venv
echo [NYX] Creating an isolated environment with the resolved Python executable...
"%BASE_PY%" -m venv "%CD%\.venv"
if errorlevel 1 goto :venv_failed
if not exist "%VENV_PY%" goto :venv_failed
"%VENV_PY%" -c "import sys, struct; assert sys.version_info[:2] == (3,13) and struct.calcsize('P') == 8, (sys.version, struct.calcsize('P')*8)"
if errorlevel 1 goto :venv_failed

:venv_ready
echo [NYX] Installing dependencies into the isolated environment...
set "REQ_FILE=%~dp0requirements.txt"
if not exist "%REQ_FILE%" (
  echo [NYX] requirements.txt is missing from the extracted folder. Recreating the standard dependency list...
  >"%REQ_FILE%" echo PySide6^>=6.10^,^<7
  >>"%REQ_FILE%" echo PySide6-WebEngine^>=6.10^,^<7
  >>"%REQ_FILE%" echo requests^>=2.32^,^<3
  >>"%REQ_FILE%" echo websocket-client^>=1.9.2^,^<2
  >>"%REQ_FILE%" echo fastapi^>=0.162.3^,^<1
  >>"%REQ_FILE%" echo uvicorn^>=0.37^,^<1
  >>"%REQ_FILE%" echo websockets^>=17.4^,^<18
  >>"%REQ_FILE%" echo python-multipart^>=0.0.20^,^<1
  >>"%REQ_FILE%" echo keyring^>=25.6^,^<27
)
if not exist "%REQ_FILE%" (
  echo [ERROR] Cannot create requirements.txt in: "%~dp0"
  goto :failed
)
echo [NYX] Dependency file: "%REQ_FILE%"
"%VENV_PY%" -m pip install --upgrade pip
if errorlevel 1 goto :failed
"%VENV_PY%" -m pip install --no-cache-dir -r "%REQ_FILE%"
if errorlevel 1 goto :failed
echo [NYX] Starting NYX Browser 1.0.0-dev.3...
"%VENV_PY%" -m nyx
if errorlevel 1 goto :failed
exit /b 0

:resolve_python
set "BASE_PY="
for /f "delims=" %%I in ('py -3.13 -c "import sys; print(sys.executable)" 2^>nul') do set "BASE_PY=%%I"
if not defined BASE_PY exit /b 1
if not exist "%BASE_PY%" set "BASE_PY="
if not defined BASE_PY exit /b 1
"%BASE_PY%" -c "import sys, struct; assert sys.version_info[:2] == (3,13) and struct.calcsize('P') == 8" >nul 2>&1
if errorlevel 1 set "BASE_PY="
exit /b 0

:python_install_failed
echo.
echo [ERROR] Could not locate a working Python %NYX_PY% x64 runtime.
echo Run this command in Command Prompt and check its output: py -3.13 -c "import sys; print(sys.executable); print(sys.version)"
echo If Python 3.13 is missing, install Python 3.13 x64 from:
echo https://www.python.org/downloads/windows/
echo Python 3.15 can remain installed. No user browser data was changed.
pause
exit /b 1

:venv_failed
echo.
echo [ERROR] Python was found, but it could not create a valid .venv.
echo Runtime used: "%BASE_PY%"
echo Try this command manually from this folder:
echo "%BASE_PY%" -m venv .venv
pause
exit /b 1

:failed
echo.
echo [NYX] Startup failed. The error is shown above.
pause
exit /b 1
