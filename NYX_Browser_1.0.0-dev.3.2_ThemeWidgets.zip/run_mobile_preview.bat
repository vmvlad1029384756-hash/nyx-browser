@echo off
cd /d "%~dp0"
echo NYX Mobile PWA preview server
echo Connect a phone to the same Wi-Fi and open http://PC-IP:8000/
py -m http.server 8000 --bind 0.0.0.0 --directory mobile-pwa
pause
