# Native NYX Android — next stage

The `mobile-pwa` folder is a responsive installable companion, not the full native browser. The current Windows app uses PySide6 + Qt WebEngine Widgets. Qt WebEngine documents Windows, Linux and macOS as its supported target platforms, not Android. Qt for Python Android packaging exists but requires a Linux/macOS build host, Android-specific wheels and a separate build/deployment process.

A real full Android browser should be a new Kotlin/Java client using Android System WebView or another supported Android engine. Share the home-page data model, widget logic, games, messaging APIs and settings, then implement native tabs, downloads, permissions, proxy support, private mode and lifecycle behavior.

No APK is included. Minimum Android API level must be chosen after testing; support for literally every old phone cannot be guaranteed.
