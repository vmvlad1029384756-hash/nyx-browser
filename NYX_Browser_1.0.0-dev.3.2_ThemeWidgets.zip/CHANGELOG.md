# NYX Browser 1.0.0-dev.3

## Fixes in this build
- Reworked sidebar into a slim-edge, hover-revealed GX-inspired overlay drawer. It no longer occupies a permanent 58 px strip over websites.
- Added a visible Incognito window action to the navigation toolbar and NYX menu; Ctrl+Shift+N is a window-level shortcut.
- Fixed YouBusta installation handoff: CRX is validated, safely unpacked, and the unpacked directory is passed to Qt WebEngine ExtensionManager (the previous build incorrectly passed a ZIP file).
- Unified start-page accents and text selection with the active theme accent instead of a separate green token.
- Changed start-page shortcuts to real anchors for reliable keyboard, mouse, and touch navigation.
- Improved small-screen dashboard layout and media playback defaults.

## Limitations
- Qt WebEngine cannot guarantee playback on sites requiring proprietary DRM, unsupported codecs, anti-bot clearance, or site-side browser allowlisting. VK Video and the named adult sites still require real-world testing on the target Windows installation.
- This is a desktop Windows browser build. The mobile PWA is an adaptive start-page/companion surface, not a full native Android/iOS browser engine.
- GUI/video/extension behavior has not been run on the user's Windows device in this environment.
# NYX Browser 1.0.0-dev.2 — Stage 2

## Visual system
- Desktop chrome aligned to the published NYX website: Inter typography, near-black layered surfaces, violet gradient accents and subtle borders.
- One semantic theme palette now controls the title bar, tabs, address bar, menus, sidebar, dialogs, status bar, new-tab clock glow, search focus, widgets and Arcade.
- Added a distinct Custom theme choice so a previously saved custom color cannot leak into a selected preset theme.
- Added secondary accent editing for gradient controls.
- Improved hover and motion details; removed global text-selection blocking from the new-tab page.

## Browser chrome and settings
- Removed redundant right-side address-toolbar actions; only Downloads and Extensions remain there.
- Rebuilt the sidebar as an overlay drawer so expansion no longer changes page geometry.
- Added settings for animation, hover expansion, online suggestions and status-bar visibility.
- Settings pages are scrollable and include a custom theme editor.

## Extensions and proxy
- Added Qt WebEngine Manifest V3 extension management: install, enable, disable and uninstall.
- Added an installer for the official YouBusta / ЮБуст package from the Chrome Web Store update service, including CRX validation and extension-ID verification.
- Added a separate HTTP/SOCKS5 Proxy Switcher with import/export, profile removal and common Simple Proxy Switcher text formats.
- Native extension enablement is saved per browser profile and restored on startup.

## Verification
- 13 automated regression tests pass.
- Python source compilation passes.
- Inline JavaScript syntax checks pass for desktop pages and PWA pages.
- GUI launch, actual YouBusta playback, video codecs, Google sign-in and Windows installer still require manual Windows QA; they are not claimed as verified in this archive.


## Stage 2.1 — Windows Python launcher fix

- Fixed a Windows Python Install Manager/launcher edge case: the launcher is now used only to resolve the installed Python 3.13 executable path.
- Virtual environments are created by invoking that exact `python.exe` directly, rather than asking the launcher to resolve the runtime a second time.
- Added direct runtime validation and clearer diagnostics if venv creation still fails.
- Applied the same correction to `build_windows.bat`.


## 1.0.0-dev.3.1 — Requirements hotfix
- Resolve the dependency manifest by absolute path beside `run.bat`.
- If `requirements.txt` is missing after extraction, recreate the known dependency list and install from that absolute path.
- Print the resolved manifest location for easier diagnostics.


## 1.0.0-dev.3.2 — Theme consistency and dashboard widgets
- Removed hard-coded green link and selection colors from the Dark Engine; website selection, links and focus accents now follow the active NYX theme.
- Theme changes rebuild the WebEngine style injector and update already-open pages.
- Dark Lab selection styling now follows the active theme instead of forcing green.
- Added Pomodoro cycles, a persistent income/expense tracker, and an offline percentage calculator to the start-page widget library.
- Preserved existing dashboard items and saved layout data.
