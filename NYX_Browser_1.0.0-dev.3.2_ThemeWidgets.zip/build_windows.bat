@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "NYX_PY=3.13"
set "BASE_PY="
set "VENV_PY=%CD%\.venv\Scripts\python.exe"

echo [NYX 1.0] Preparing Windows x64 build environment...
call :resolve_python
if defined BASE_PY goto :python_ready
py install %NYX_PY%
if errorlevel 1 goto :python_install_failed
call :resolve_python
if not defined BASE_PY goto :python_install_failed

:python_ready
echo [NYX] Using Python: "%BASE_PY%"
if exist "%VENV_PY%" goto :check_venv
if exist ".venv" rmdir /s /q ".venv"
goto :create_venv

:check_venv
"%VENV_PY%" -c "import sys, struct; assert sys.version_info[:2] == (3,13) and struct.calcsize('P') == 8" >nul 2>&1
if not errorlevel 1 goto :venv_ready
echo [NYX] Recreating incompatible build environment...
rmdir /s /q ".venv"

:create_venv
echo [NYX] Creating isolated build environment...
"%BASE_PY%" -m venv "%CD%\.venv"
if errorlevel 1 goto :venv_failed
if not exist "%VENV_PY%" goto :venv_failed
"%VENV_PY%" -c "import sys, struct; assert sys.version_info[:2] == (3,13) and struct.calcsize('P') == 8"
if errorlevel 1 goto :venv_failed

:venv_ready
"%VENV_PY%" -m pip install --upgrade pip
if errorlevel 1 goto :failed
"%VENV_PY%" -m pip install --no-cache-dir -r requirements-build.txt
if errorlevel 1 goto :failed
"%VENV_PY%" -m PyInstaller --noconfirm --clean NYX_Browser.spec
if errorlevel 1 goto :failed
echo.
echo Build complete: dist\NYX Browser\NYX Browser.exe
echo This is an unpacked build; run the Windows QA checklist before distributing.
pause
exit /b 0

:resolve_python
set "BASE_PY="
for /f "delims=" %%I in ('py -3.13 -c "import sys; print(sys.executable)" 2^>nul') do set "BASE_PY=%%I"
if not defined BASE_PY exit /b 1
if not exist "%BASE_PY%" set "BASE_PY="
if not defined BASE_PY exit /b 1
"%BASE_PY%" -c "import sys, struct; assert sys.version_info[:2] == (3,13) and struct.calcsize('P') == 8" >nul 2>&1
if errorlevel 1 set "BASE_PY="
exit /b 0

:python_install_failed
echo [ERROR] Could not locate a working Python 3.13 x64 runtime.
echo Check: py -3.13 -c "import sys; print(sys.executable); print(sys.version)"
echo Python 3.13 x64: https://www.python.org/downloads/windows/
pause
exit /b 1

:venv_failed
echo [ERROR] Python was found, but virtual environment creation failed.
echo Runtime used: "%BASE_PY%"
echo Try manually: "%BASE_PY%" -m venv .venv
pause
exit /b 1

:failed
echo [NYX] Build failed. See the error above.
pause
exit /b 1
