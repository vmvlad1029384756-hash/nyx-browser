# NYX Browser 1.0 — Windows QA checklist

Run on a clean Windows 10/11 x64 machine and on a machine with an existing 0.3.0 profile. Mark each item only after a real manual test.

## Install and upgrade
- [ ] Install from the x64 installer without administrator elevation.
- [ ] Upgrade over an existing installation without deleting `%LOCALAPPDATA%\NYX Browser`.
- [ ] Confirm a `backups\pre-v1.0-*` snapshot contains `settings.json` and `nyx.db` when those files existed.
- [ ] Confirm Chromium profile, cookies, cache, bookmarks, history and sessions remain available.
- [ ] Confirm saved passwords remain accessible through Windows Credential Manager.
- [ ] Uninstall the application and confirm user data is retained.

## Window and navigation
- [ ] Window drag, maximize, restore, minimize and all resize edges work.
- [ ] Closing the final tab opens a new tab without closing the application.
- [ ] Tab drag/reorder, new tab, close tab and session restore work.
- [ ] Back, forward, reload, home and address-bar search work.
- [ ] Search suggestions show local suggestions and online suggestions; private windows send no suggestion requests.
- [ ] Address suggestions do not steal keyboard input or close unexpectedly.

## Sidebar and themes
- [ ] Sidebar expands as an overlay on hover and collapses after pointer exit without moving the page or changing its width.
- [ ] Switching themes recolors every native control, dialog, clock glow, start-page search, action dock and widget accent without leftover emerald highlights.
- [ ] Downloads and Extensions are the only right-side address-toolbar action buttons.
- [ ] YouBusta downloads from the official Chrome Web Store endpoint, installs, enables and persists in the profile; YouTube video/audio/fullscreen are tested.
- [ ] Manifest V3 extension import, enable/disable and restart persistence work.
- [ ] Pin keeps it expanded; unpin restores hover behavior.
- [ ] Left/right placement persists after restart.
- [ ] All sidebar actions open the correct destination.
- [ ] Violet, Emerald, Crimson, Azure, AMOLED Black, Midnight and Custom themes recolor the native UI, dialogs, new tab and Arcade.
- [ ] A previously saved custom green theme does not leak into Violet, Crimson or Azure when a preset is selected.
- [ ] Custom theme editor settings remain functional.

## Browser features
- [ ] Bookmarks can be added, edited, deleted, imported and exported.
- [ ] History can be searched and cleared; private browsing does not record history.
- [ ] Downloads complete, can be opened, and are recorded; private downloads are not persisted.
- [ ] Password save, list, delete and manual autofill work with Windows Credential Manager.
- [ ] Site permissions can be allowed, denied, remembered and revoked.
- [ ] Ad blocking can be switched on/off without breaking normal navigation.
- [ ] User scripts install, enable, disable and remove correctly.
- [ ] Translation opens the correct page and preserves the source URL.
- [ ] Zoom in/out/reset persists as intended.
- [ ] Fullscreen video and Picture-in-Picture work on supported sites.
- [ ] Reader mode, notes, split view, workspaces, backup/restore and NYX Arcade work.

## Compatibility (must be tested on target Windows hardware)
- [ ] YouTube playback, audio, fullscreen and Google sign-in.
- [ ] VK Video playback and audio.
- [ ] H.264/AAC streams and common HTML5 media formats.
- [ ] Pornhub and Porno666 loading/playback where legally available and not blocked by network/site policy.
- [ ] Proxy Switcher imports/exports `host:port`, `host:port:login:password` and HTTP/SOCKS5 URL formats without writing passwords to settings files.
- [ ] YouBusta / ЮБуст is tested against its required Chrome APIs; installation alone is not counted as functional playback.
- [ ] Hardware acceleration, GPU reset and renderer-crash recovery.

## Release gate
- [ ] No critical crash or data-loss issue remains.
- [ ] Installer and portable build are scanned and signed if signing is available.
- [ ] Release notes list only features verified on the release candidate.


## Theme regression checks (dev.3.2)
- Switch to NYX Crimson and confirm the native selection highlight in the address bar is crimson.
- On the start page, confirm search selection, shortcuts, widgets and the Arcade link use crimson accents rather than green.
- Open multiple ordinary websites and select text in paragraphs, links, inputs and editable fields; selection must use the active theme accent.
- Switch themes while pages remain open; verify their selection/link accent updates without restarting NYX.
- Repeat with NYX Violet, NYX Emerald and NYX Azure to ensure each theme keeps its own accent.
- Add Pomodoro, Budget Tracker and Percentage Calculator widgets; verify values persist after closing and reopening the start page.
