@echo off
cd /d "%~dp0"
echo NYX Messenger server startup
set /p NYX_ROOM_CODE=Enter a private room code (share only with your friend):
set /p NYX_SECRET=Enter a long random server secret (at least 32 characters):
if "%NYX_ROOM_CODE%"=="" goto missing
if "%NYX_SECRET%"=="" goto missing
set NYX_MESSENGER_DATA=./nyx_messenger_data
py -m uvicorn nyx.messenger_server:app --host 0.0.0.0 --port 8765
pause
goto end
:missing
echo Room code and server secret are required.
pause
:end
